
import { Department } from '../types';

const CTA_SEAL_URL = 'https://tibet.net/wp-content/uploads/2021/01/CTA_Logo-_Trans.png';

export const departmentsData: Department[] = [
    {
        nameKey: 'dept_religion',
        phone: '+91 (1892) 222-685',
        logoUrl: CTA_SEAL_URL,
        imageUrl: "https://picsum.photos/400/250?random=12",
        duties: [
            "Dedicated to the preservation and promotion of Tibet's profound spiritual traditions and rich cultural heritage. This involves providing guidance and support for the flourishing of all schools of Tibetan Buddhism and the ancient Bön tradition.",
            "Manages the administration of over 300 monasteries and nunneries in India, Nepal, and Bhutan, ensuring they have the resources for both religious study and the welfare of their monastic members.",
            "Supports research and publication of rare philosophical texts, and organizes religious conferences and teachings by His Holiness the Dalai Lama and other eminent scholars to benefit the global community."
        ],
        duties_ti: [
            "བོད་ཀྱི་ཐུན་མོང་མ་ཡིན་པའི་བླ་སྲོག་གི་སྲོལ་རྒྱུན་དང་རིག་གནས་ཀྱི་ཤུལ་བཞག་ཕུན་སུམ་ཚོགས་པ་སྲུང་སྐྱོབ་དང་དར་སྤེལ་གཏོང་རྒྱུར་འབད་བརྩོན་བྱེད་ཀྱི་ཡོད། འདིའི་ནང་བོད་བརྒྱུད་ནང་བསྟན་གྱི་ཆོས་བརྒྱུད་ཡོངས་དང་གནའ་བོའི་བོན་གྱི་སྲོལ་རྒྱུན་དར་རྒྱས་ཡོང་བར་ལམ་སྟོན་དང་རྒྱབ་སྐྱོར་བྱེད་རྒྱུ་ཚུད་ཡོད།",
            "རྒྱ་གར། བལ་ཡུལ། འབྲུག་བཅས་སུ་ཡོད་པའི་དགོན་པ་དང་བཙུན་དགོན་ ༣༠༠ ལྷག་གི་འཛིན་སྐྱོང་ལ་ལྟ་རྟོག་བྱས་ནས། ཆོས་ཀྱི་སློབ་གཉེར་དང་དགེ་འདུན་པའི་བདེ་དོན་གཉིས་ཀར་མཐུན་རྐྱེན་ཡོད་པ་འགན་ལེན་བྱེད།",
            "ལྟ་གྲུབ་ཀྱི་གསུང་རབ་དཀོན་པོ་རྣམས་ཞིབ་འཇུག་དང་དཔེ་སྐྲུན་བྱེད་པར་རྒྱབ་སྐྱོར་དང་། སྤྱི་ཚོགས་ཡོངས་ལ་ཕན་པའི་ཆེད་དུ་༸གོང་ས་མཆོག་དང་མཁས་དབང་གཞན་གྱི་ཆོས་ཀྱི་བགྲོ་གླེང་དང་གསུང་ཆོས་གོ་སྒྲིག་བྱེད།"
        ],
        duties_hi: [
            "तिब्बत की गहन आध्यात्मिक परंपराओं और समृद्ध सांस्कृतिक विरासत के संरक्षण और संवर्धन के लिए समर्पित। इसमें तिब्बती बौद्ध धर्म के सभी स्कूलों और प्राचीन बॉन परंपरा के उत्कर्ष के लिए मार्गदर्शन और समर्थन प्रदान करना शामिल है।",
            "भारत, नेपाल और भूटान में 300 से अधिक मठों और ननरीज़ के प्रशासन का प्रबंधन करता है, यह सुनिश्चित करता है कि उनके पास धार्मिक अध्ययन और उनके मठवासी सदस्यों के कल्याण दोनों के लिए संसाधन हों।",
            "दुर्लभ दार्शनिक ग्रंथों के अनुसंधान और प्रकाशन का समर्थन करता है, और वैश्विक समुदाय को लाभ पहुंचाने के लिए परम पावन दलाई लामा और अन्य प्रख्यात विद्वानों द्वारा धार्मिक सम्मेलनों और शिक्षाओं का आयोजन करता है।"
        ]
    }
];