import { King, DalaiLama, ContentSection, ReligionSchool, MedicineTopic, HistoricalPeriod, InfoCardData, DynasticRuler, PanchenLama } from '../types';

export const preImperialData: InfoCardData[] = [
    {
        titleKey: 'preImperialPeriod',
        contentKey: 'preImperialPeriod_desc'
    }
];

export const kingsData: King[] = [
    {
        id: 1,
        name: "Nyatri Tsenpo",
        name_ti: "གཉའ་ཁྲི་བཙན་པོ།",
        name_hi: "न्यात्री त्सेनपो",
        tibetan_name: "གཉའ་ཁྲི་བཙན་པོ།",
        reign: "c. 127 BCE",
        bio: "The legendary first king of the Yarlung Dynasty, believed to have descended from the heavens. He established the monarchy and built the first castle, Yumbulagang.",
        bio_ti: "ཡར་ཀླུང་རྒྱལ་རབས་ཀྱི་ལྷ་སྒྲུང་གི་རྒྱལ་པོ་ཐོག་མ། གནམ་ནས་བབས་པར་གྲགས། ཁོང་གིས་རྒྱལ་པོའི་སྲིད་དབང་བཙུགས་པ་དང་། མཁར་རྫོང་ཐོག་མ་ཡུམ་བུ་བླ་སྒང་བཞེངས།",
        bio_hi: "यारलुंग राजवंश के प्रसिद्ध पहले राजा, जिनके बारे में माना जाता है कि वे स्वर्ग से उतरे थे। उन्होंने राजशाही की स्थापना की और पहला महल, युम्बुलगंग बनाया।",
        achievements: ["Founder of the Yarlung Dynasty.", "Built Yumbulagang Palace."],
        achievements_ti: ["ཡར་ཀླུང་རྒྱལ་རབས་ཀྱི་སྲོལ་གཏོད་པ།", "ཡུམ་བུ་བླ་སྒང་བཞེངས།"],
        achievements_hi: ["यारलुंग राजवंश के संस्थापक।", "युम्बुलगंग महल का निर्माण किया।"],
        challenges: ["Uniting disparate tribes."],
        challenges_ti: ["ཚོ་པ་སིལ་མ་རྣམས་གཅིག་ཏུ་བསྒྲིལ་བ།"],
        challenges_hi: ["विभिन्न जनजातियों को एकजुट करना।"],
        cultural_influence: "Represents the divine origin of Tibetan kingship.",
        cultural_influence_ti: "བོད་ཀྱི་རྒྱལ་པོའི་གདུང་རྒྱུད་ཀྱི་ལྷ་ཡི་འབྱུང་ཁུངས་མཚོན།",
        cultural_influence_hi: "तिब्बती राजत्व की दिव्य उत्पत्ति का प्रतिनिधित्व करता है।"
    },
    { id: 2, name: "Mutri Tsenpo", name_ti: "མུ་ཁྲི་བཙན་པོ།", name_hi: "मुत्री त्सेनपो", tibetan_name: "མུ་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Son of Nyatri Tsenpo, second of the 'Seven Heavenly Thrones'.", bio_ti: "གཉའ་ཁྲི་བཙན་པོའི་སྲས། གནམ་གྱི་ཁྲི་བདུན་གྱི་གཉིས་པ།", bio_hi: "न्यात्री त्सेनपो के पुत्र, 'सात स्वर्गीय सिंहासनों' में से दूसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 3, name: "Dingtri Tsenpo", name_ti: "དིང་ཁྲི་བཙན་པོ།", name_hi: "डिंगत्री त्सेनपो", tibetan_name: "དིང་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Third of the 'Seven Heavenly Thrones'.", bio_ti: "གནམ་གྱི་ཁྲི་བདུན་གྱི་གསུམ་པ།", bio_hi: "'सात स्वर्गीय सिंहासनों' में से तीसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 4, name: "Sotri Tsenpo", name_ti: "སོ་ཁྲི་བཙན་པོ།", name_hi: "सोत्री त्सेनपो", tibetan_name: "སོ་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Fourth of the 'Seven Heavenly Thrones'.", bio_ti: "གནམ་གྱི་ཁྲི་བདུན་གྱི་བཞི་པ།", bio_hi: "'सात स्वर्गीय सिंहासनों' में से चौथे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 5, name: "Mertri Tsenpo", name_ti: "མེར་ཁྲི་བཙན་པོ།", name_hi: "मेरत्री त्सेनपो", tibetan_name: "མེར་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Fifth of the 'Seven Heavenly Thrones'.", bio_ti: "གནམ་གྱི་ཁྲི་བདུན་གྱི་ལྔ་པ།", bio_hi: "'सात स्वर्गीय सिंहासनों' में से पांचवें।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 6, name: "Daktri Tsenpo", name_ti: "གདགས་ཁྲི་བཙན་པོ།", name_hi: "दकत्री त्सेनपो", tibetan_name: "གདགས་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Sixth of the 'Seven Heavenly Thrones'.", bio_ti: "གནམ་གྱི་ཁྲི་བདུན་གྱི་དྲུག་པ།", bio_hi: "'सात स्वर्गीय सिंहासनों' में से छठे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 7, name: "Siptri Tsenpo", name_ti: "སྲིབ་ཁྲི་བཙན་པོ།", name_hi: "सिपत्री त्सेनपो", tibetan_name: "སྲིབ་ཁྲི་བཙན་པོ།", reign: "Legendary", bio: "Last of the 'Seven Heavenly Thrones'.", bio_ti: "གནམ་གྱི་ཁྲི་བདུན་གྱི་མཐའ་མ།", bio_hi: "'सात स्वर्गीय सिंहासनों' में से अंतिम।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 8, name: "Drigum Tsenpo", name_ti: "གྲི་གུམ་བཙན་པོ།", name_hi: "ड्रिगम त्सेनपो", tibetan_name: "གྲི་གུམ་བཙན་པོ།", reign: "Legendary", bio: "First king to be buried on Earth, marking the end of the celestial connection.", bio_ti: "ས་ཐོག་ཏུ་དུར་འཇུག་བྱས་པའི་རྒྱལ་པོ་ཐོག་མ། གནམ་གྱི་འབྲེལ་བ་མཇུག་བསྒྲིལ་བ་མཚོན།", bio_hi: "पृथ्वी पर दफनाए जाने वाले पहले राजा, खगोलीय संबंध के अंत का प्रतीक।", achievements: ["Established royal tombs."], achievements_ti: ["རྒྱལ་པོའི་བང་སོ་བཙུགས།"], achievements_hi: ["शाही मकबरों की स्थापना की।"], challenges: ["Lost divine connection."], challenges_ti: ["ལྷ་ཡི་འབྲེལ་བ་ཤོར།"], challenges_hi: ["दिव्य संबंध खो दिया।"], cultural_influence: "Shift from celestial to earthly kings.", cultural_influence_ti: "གནམ་གྱི་རྒྱལ་པོ་ནས་སའི་རྒྱལ་པོར་འགྱུར་བ།", cultural_influence_hi: "खगोलीय से सांसारिक राजाओं में परिवर्तन।" },
    { id: 9, name: "Pude Gunggyal", name_ti: "པུ་དེ་གུང་རྒྱལ།", name_hi: "पुदे गुंग्याल", tibetan_name: "པུ་དེ་གུང་རྒྱལ།", reign: "Legendary", bio: "Credited with promoting agriculture and technological development.", bio_ti: "ཞིང་ལས་དང་འཕྲུལ་རིག་ཡར་རྒྱས་བཏང་བར་བརྩི།", bio_hi: "कृषि और तकनीकी विकास को बढ़ावा देने का श्रेय दिया जाता है।", achievements: ["Promoted agriculture."], achievements_ti: ["ཞིང་ལས་དར་སྤེལ་བཏང་།"], achievements_hi: ["कृषि को बढ़ावा दिया।"], challenges: ["Re-establishing order."], challenges_ti: ["སྒྲིག་ལམ་བསྐྱར་འཛུགས་བྱེད་པ།"], challenges_hi: ["व्यवस्था को फिर से स्थापित करना।"], cultural_influence: "Brought practical development to Tibet.", cultural_influence_ti: "བོད་ལ་ལག་ལེན་གྱི་ཡར་རྒྱས་བསྐྲུན།", cultural_influence_hi: "तिब्बत में व्यावहारिक विकास लाया।" },
    { id: 10, name: "Esho Leg", name_ti: "ཨེ་ཤོ་ལེགས།", name_hi: "एशो लेक", tibetan_name: "ཨེ་ཤོ་ལེགས།", reign: "Legendary", bio: "First of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་དང་པོ།", bio_hi: "'छह पार्थिव लेकों' में से पहले।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 11, name: "Desho Leg", name_ti: "དེ་ཤོ་ལེགས།", name_hi: "देशो लेक", tibetan_name: "དེ་ཤོ་ལེགས།", reign: "Legendary", bio: "Second of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་གཉིས་པ།", bio_hi: "'छह पार्थिव लेकों' में से दूसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 12, name: "Tisho Leg", name_ti: "ཐི་ཤོ་ལེགས།", name_hi: "तिशो लेक", tibetan_name: "ཐི་ཤོ་ལེགས།", reign: "Legendary", bio: "Third of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་གསུམ་པ།", bio_hi: "'छह पार्थिव लेकों' में से तीसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 13, name: "Gongru Leg", name_ti: "གུང་རུ་ལེགས།", name_hi: "गोंगरू लेग", tibetan_name: "གུང་རུ་ལེགས།", reign: "Legendary", bio: "Fourth of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་བཞི་པ།", bio_hi: "'छह पार्थिव लेकों' में से चौथे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 14, name: "Drongzher Leg", name_ti: "འབྲོང་ཞེར་ལེགས།", name_hi: "ड्रोंगझेर लेक", tibetan_name: "འབྲོང་ཞེར་ལེགས།", reign: "Legendary", bio: "Fifth of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་ལྔ་པ།", bio_hi: "'छह पार्थिव लेकों' में से पांचवें।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 15, name: "Isho Leg", name_ti: "ཨི་ཤོ་ལེགས།", name_hi: "इशो लेक", tibetan_name: "ཨི་ཤོ་ལེགས།", reign: "Legendary", bio: "Last of the 'Six Earthly Leks'.", bio_ti: "ས་ཡི་ལེགས་དྲུག་གི་མཐའ་མ།", bio_hi: "'छह पार्थिव लेकों' में से अंतिम।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 16, name: "Zanam Zindé", name_ti: "ཟ་ནལ་ཟིན་ལྡེ།", name_hi: "ज़नम ज़िंदे", tibetan_name: "ཟ་ནལ་ཟིན་ལྡེ།", reign: "Legendary", bio: "First of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་དང་པོ།", bio_hi: "'आठ मध्य दे' में से पहले।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 17, name: "Detrul Namzhungtsen", name_ti: "ལྡེ་འཕྲུལ་ནམ་གཞུང་བཙན།", name_hi: "देत्रुल नमझुंगत्सेन", tibetan_name: "ལྡེ་འཕྲུལ་ནམ་གཞུང་བཙན།", reign: "Legendary", bio: "Second of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་གཉིས་པ།", bio_hi: "'आठ मध्य दे' में से दूसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 18, name: "Senöl Namdé", name_ti: "སེ་སྣོལ་གནམ་ལྡེ།", name_hi: "सेनोल नमदे", tibetan_name: "སེ་སྣོལ་གནམ་ལྡེ།", reign: "Legendary", bio: "Third of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་གསུམ་པ།", bio_hi: "'आठ मध्य दे' में से तीसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 19, name: "Senöl Podé", name_ti: "སེ་སྣོལ་པོ་ལྡེ།", name_hi: "सेनोल पोदे", tibetan_name: "སེ་སྣོལ་པོ་ལྡེ།", reign: "Legendary", bio: "Fourth of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་བཞི་པ།", bio_hi: "'आठ मध्य दे' में से चौथे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 20, name: "Denöl Nam", name_ti: "ལྡེ་སྣོལ་ནམ།", name_hi: "देनोल नम", tibetan_name: "ལྡེ་སྣོལ་ནམ།", reign: "Legendary", bio: "Fifth of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་ལྔ་པ།", bio_hi: "'आठ मध्य दे' में से पांचवें।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 21, name: "Denöl Po", name_ti: "ལྡེ་སྣོལ་པོ།", name_hi: "देनोल पो", tibetan_name: "ལྡེ་སྣོལ་པོ།", reign: "Legendary", bio: "Sixth of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་དྲུག་པ།", bio_hi: "'आठ मध्य दे' में से छठे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 22, name: "Degyal Po", name_ti: "ལྡེ་རྒྱལ་པོ།", name_hi: "देग्येल पो", tibetan_name: "ལྡེ་རྒྱལ་པོ།", reign: "Legendary", bio: "Seventh of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་བདུན་པ།", bio_hi: "'आठ मध्य दे' में से सातवें।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 23, name: "Detring Tsen", name_ti: "ལྡེ་སྤྲིན་བཙན།", name_hi: "देत्रिंग त्सेन", tibetan_name: "ལྡེ་སྤྲིན་བཙན།", reign: "Legendary", bio: "Last of the 'Eight Middle Des'.", bio_ti: "བར་གྱི་ལྡེ་བརྒྱད་ཀྱི་མཐའ་མ།", bio_hi: "'आठ मध्य दे' में से अंतिम।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 24, name: "Tore Longtsen", name_ti: "ཏོ་རི་ལོང་བཙན།", name_hi: "तोरे लोंगत्सेन", tibetan_name: "ཏོ་རི་ལོང་བཙན།", reign: "Legendary", bio: "First of the 'Five Upper Tsans'.", bio_ti: "སྟོད་ཀྱི་བཙན་ལྔའི་དང་པོ།", bio_hi: "'पांच ऊपरी त्सान' में से पहले।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 25, name: "Tritsun Nam", name_ti: "ཁྲི་བཙུན་ནམ།", name_hi: "त्रित्सुन नम", tibetan_name: "ཁྲི་བཙུན་ནམ།", reign: "Legendary", bio: "Second of the 'Five Upper Tsans'.", bio_ti: "སྟོད་ཀྱི་བཙན་ལྔའི་གཉིས་པ།", bio_hi: "'पांच ऊपरी त्सान' में से दूसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 26, name: "Tridra Pungtsen", name_ti: "ཁྲི་སྒྲ་དཔུང་བཙན།", name_hi: "त्रिद्र पुंगत्सेन", tibetan_name: "ཁྲི་སྒྲ་དཔུང་བཙན།", reign: "Legendary", bio: "Third of the 'Five Upper Tsans'.", bio_ti: "སྟོད་ཀྱི་བཙན་ལྔའི་གསུམ་པ།", bio_hi: "'पांच ऊपरी त्सान' में से तीसरे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 27, name: "Tritog Jethogtsen", name_ti: "ཁྲི་ཐོག་རྗེ་ཐོག་བཙན།", name_hi: "त्रितोग जेथोगत्सेन", tibetan_name: "ཁྲི་ཐོག་རྗེ་ཐོག་བཙན།", reign: "Legendary", bio: "Fourth of the 'Five Upper Tsans'.", bio_ti: "སྟོད་ཀྱི་བཙན་ལྔའི་བཞི་པ།", bio_hi: "'पांच ऊपरी त्सान' में से चौथे।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    {
        id: 28,
        name: "Lha Thothori Nyentsen",
        name_ti: "ལྷ་ཐོ་ཐོ་རི་གཉན་བཙན།",
        name_hi: "ल्हा थोथोरी न्यान्त्सेन",
        tibetan_name: "ལྷ་ཐོ་ཐོ་རི་གཉན་བཙན།",
        reign: "c. 5th Century CE",
        bio: "During his reign, Buddhist scriptures are said to have first arrived in Tibet, marking the initial contact with the Dharma.",
        bio_ti: "ཁོང་གི་སྐུ་རིང་ལ། ནང་པའི་གསུང་རབ་བོད་དུ་ཐོག་མར་བབས་པར་གྲགས། དེས་དམ་པའི་ཆོས་དང་ཐོག་མར་འབྲེལ་བ་བྱུང་བ་མཚོན།",
        bio_hi: "उनके शासनकाल में, कहा जाता है कि बौद्ध ग्रंथ पहली बार तिब्बत में आए, जो धर्म के साथ प्रारंभिक संपर्क का प्रतीक है।",
        achievements: ["First contact with Buddhism in Tibet."],
        achievements_ti: ["བོད་དུ་ནང་བསྟན་དང་ཐོག་མར་འབྲེལ་བ་བྱུང་།"],
        achievements_hi: ["तिब्बत में बौद्ध धर्म के साथ पहला संपर्क।"],
        challenges: ["Scriptures were not understood at the time."],
        challenges_ti: ["སྐབས་དེར་གསུང་རབ་གོ་བ་མ་ལོན།"],
        challenges_hi: ["उस समय ग्रंथ समझ में नहीं आए थे।"],
        cultural_influence: "Venerated as the king who presided over the 'first light' of the Dharma.",
        cultural_influence_ti: "དམ་པའི་ཆོས་ཀྱི་ 'འོད་སྣང་དང་པོ'འི་དབང་འཛིན་མཛད་པའི་རྒྱལ་པོར་བརྩི་བཀུར་ཞུ།",
        cultural_influence_hi: "धर्म की 'पहली रोशनी' की अध्यक्षता करने वाले राजा के रूप में प्रतिष्ठित।"
    },
    { id: 29, name: "Trinyen Zungtsen", name_ti: "ཁྲི་གཉན་གཟུངས་བཙན།", name_hi: "त्रिन्येन ज़ुंगत्सेन", tibetan_name: "ཁྲི་གཉན་གཟུངས་བཙན།", reign: "c. 6th Century", bio: "Son of Lha Thothori Nyentsen.", bio_ti: "ལྷ་ཐོ་ཐོ་རི་གཉན་བཙན་གྱི་སྲས།", bio_hi: "ल्हा थोथोरी न्यान्त्सेन के पुत्र।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 30, name: "Drongnyen Deu", name_ti: "འབྲོང་གཉན་ལྡེའུ།", name_hi: "ड्रोंगयेन देउ", tibetan_name: "འབྲོང་གཉན་ལྡེའུ།", reign: "c. 6th Century", bio: "Consolidated power in the Yarlung Valley.", bio_ti: "ཡར་ཀླུང་ལུང་གཤོངས་སུ་དབང་ཆ་གཅིག་ཏུ་བསྒྲིལ།", bio_hi: "यारलुंग घाटी में शक्ति को मजबूत किया।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    { id: 31, name: "Tagri Nyenzig", name_ti: "སྟག་རི་གཉན་གཟིགས།", name_hi: "तगरी न्येन्जिग", tibetan_name: "སྟག་རི་གཉན་གཟིགས།", reign: "c. 6th Century", bio: "Father of Namri Songtsen, continued unification efforts.", bio_ti: "གནམ་རི་སྲོང་བཙན་གྱི་ཡབ། གཅིག་གྱུར་གྱི་ལས་དོན་མུ་མཐུད་དུ་གནང་།", bio_hi: "नामरी सोंगत्सेन के पिता, एकीकरण के प्रयासों को जारी रखा।", achievements: [], achievements_ti: [], achievements_hi: [], challenges: [], challenges_ti: [], challenges_hi: [], cultural_influence: "", cultural_influence_ti: "", cultural_influence_hi: "" },
    {
        id: 32,
        name: "Namri Songtsen",
        name_ti: "གནམ་རི་སྲོང་བཙན།",
        name_hi: "नामरी सोंगत्सेन",
        tibetan_name: "གནམ་རི་སྲོང་བཙན།",
        reign: "c. 601–629",
        bio: "Father of Songtsen Gampo, he expanded the Yarlung kingdom significantly, laying the foundation for the Tibetan Empire. He was assassinated.",
        bio_ti: "སྲོང་བཙན་སྒམ་པོའི་ཡབ། ཁོང་གིས་ཡར་ཀླུང་རྒྱལ་ཁབ་རྒྱ་ཆེར་བསྐྱེད་དེ། བོད་ཀྱི་བཙན་རྒྱལ་གྱི་རྨང་གཞི་བཏིང་། ཁོང་བཀྲོངས།",
        bio_hi: "सोंगत्सेन गम्पो के पिता, उन्होंने यारलुंग साम्राज्य का महत्वपूर्ण विस्तार किया, जिससे तिब्बती साम्राज्य की नींव रखी गई। उनकी हत्या कर दी गई थी।",
        achievements: ["Expanded the Yarlung kingdom.", "Sent first envoy to China."],
        achievements_ti: ["ཡར་ཀླུང་རྒྱལ་ཁབ་རྒྱ་སྐྱེད་བཏང་།", "རྒྱ་ནག་ཏུ་ཕོ་ཉ་དང་པོ་མངགས།"],
        achievements_hi: ["यारलुंग साम्राज्य का विस्तार किया।", "चीन में पहला दूत भेजा।"],
        challenges: ["Assassinated by rivals."],
        challenges_ti: ["འགྲན་ཟླས་བཀྲོངས།"],
        challenges_hi: ["प्रतिद्वंद्वियों द्वारा हत्या।"],
        cultural_influence: "Set the stage for his son to create the empire.",
        cultural_influence_ti: "ཁོང་གི་སྲས་ཀྱིས་བཙན་རྒྱལ་འཛུགས་པའི་རྨང་གཞི་བཏིང་།",
        cultural_influence_hi: "अपने बेटे के लिए साम्राज्य बनाने का मंच तैयार किया।"
    },
    {
        id: 33,
        name: "Songtsen Gampo",
        name_ti: "སྲོང་བཙན་སྒམ་པོ།",
        name_hi: "सोंगत्सेन गम्पो",
        tibetan_name: "སྲོང་བཙན་སྒམ་པོ།",
        reign: "c. 629–649",
        bio: "Founder of the Tibetan Empire. He unified Tibet, established Lhasa as the capital, introduced a legal code, commissioned the Tibetan script, and formally introduced Buddhism.",
        bio_ti: "བོད་ཀྱི་བཙན་རྒྱལ་གྱི་སྲོལ་གཏོད་པ། ཁོང་གིས་བོད་གཅིག་ཏུ་བསྒྲིལ་བ་དང་། ལྷ་ས་རྒྱལ་ས་རུ་བཙུགས། ཁྲིམས་ཡིག་བསྒྲགས། བོད་ཡིག་གསར་བཟོ་བྱེད་དུ་བཅུག ནང་བསྟན་དངོས་སུ་ངོ་སྤྲོད་མཛད།",
        bio_hi: "तिब्बती साम्राज्य के संस्थापक। उन्होंने तिब्बत को एकीकृत किया, ल्हासा को राजधानी के रूप में स्थापित किया, एक कानूनी संहिता पेश की, तिब्बती लिपि का निर्माण कराया और औपचारिक रूप से बौद्ध धर्म की शुरुआत की।",
        achievements: ["Unified Tibet.", "Introduced Buddhism and the Tibetan script."],
        achievements_ti: ["བོད་གཅིག་གྱུར་མཛད་པ།", "ནང་བསྟན་དང་བོད་ཡིག་ངོ་སྤྲོད་མཛད་པ།"],
        achievements_hi: ["तिब्बत को एकीकृत किया।", "बौद्ध धर्म और तिब्बती लिपि का परिचय कराया।"],
        challenges: ["Managing a vast new empire.", "Balancing old and new traditions."],
        challenges_ti: ["བཙན་རྒྱལ་གསར་པ་ཆེན་པོ་འཛིན་སྐྱོང་བྱེད་པ།", "སྲོལ་རྒྱུན་རྙིང་པ་དང་གསར་པའི་དོ་སྙོམས་བྱེད་པ།"],
        challenges_hi: ["एक विशाल नए साम्राज्य का प्रबंधन।", "पुरानी और नई परंपराओं को संतुलित करना।"],
        cultural_influence: "One of the three great 'Dharma Kings', foundational figure of Tibetan civilization.",
        cultural_influence_ti: "'ཆོས་རྒྱལ་' ཆེན་པོ་གསུམ་གྱི་ནང་ནས་གཅིག བོད་ཀྱི་དཔལ་ཡོན་གྱི་རྨང་གཞིའི་མི་སྣ།",
        cultural_influence_hi: "तीन महान 'धर्म राजाओं' में से एक, तिब्बती सभ्यता के संस्थापक व्यक्ति।"
    },
    { id: 34, name: "Mangsong Mangtsen", name_ti: "མང་སྲོང་མང་བཙན།", name_hi: "मांगसोंग मांगत्सेन", tibetan_name: "མང་སྲོང་མང་བཙན།", reign: "649–676", bio: "Grandson of Songtsen Gampo. Continued the expansion of the empire, especially into Central Asia.", bio_ti: "སྲོང་བཙན་སྒམ་པོའི་ཚ་བོ། བཙན་རྒྱལ་གྱི་རྒྱ་སྐྱེད་མུ་མཐུད་དུ་གནང་བ། ལྷག་པར་དུ་དབུས་ཨེ་ཤ་ཡའི་ཕྱོགས་སུ།", bio_hi: "सोंगत्सेन गम्पो के पोते। साम्राज्य का विस्तार जारी रखा, विशेष रूप से मध्य एशिया में।", achievements: ["Expanded empire into Central Asia."], achievements_ti: ["བཙན་རྒྱལ་དབུས་ཨེ་ཤ་ཡའི་ནང་རྒྱ་སྐྱེད་བཏང་།"], achievements_hi: ["मध्य एशिया में साम्राज्य का विस्तार किया।"], challenges: ["Consolidating the vast territories conquered by his grandfather."], challenges_ti: ["མེས་པོས་དབང་དུ་བསྡུས་པའི་ས་ཁུལ་ཆེན་པོ་རྣམས་སྲ་བརྟན་དུ་གཏོང་བ།"], challenges_hi: ["अपने दादा द्वारा जीते गए विशाल क्षेत्रों को मजबूत करना।"], cultural_influence: "Maintained the momentum of the early Tibetan Empire.", cultural_influence_ti: "བོད་ཀྱི་བཙན་རྒྱལ་གྱི་སྔ་མའི་ག Momentum བསྐྱངས།", cultural_influence_hi: "प्रारंभिक तिब्बती साम्राज्य की गति को बनाए रखा।" },
    { id: 35, name: "Tridu Songtsen", name_ti: "འདུས་སྲོང་མང་པོ་རྗེ།", name_hi: "त्रिदु सोंगत्सेन", tibetan_name: "འདུས་སྲོང་མང་པོ་རྗེ།", reign: "676–704", bio: "Reasserted royal authority over powerful clans and continued military campaigns, strengthening the empire.", bio_ti: "རིགས་རྒྱུད་སྟོབས་ཆེན་རྣམས་ཀྱི་ཐོག་རྒྱལ་པོའི་དབང་ཆ་བསྐྱར་དུ་གཏན་འབེབས་མཛད་པ་དང་། དམག་འཁྲུག་མུ་མཐུད་དུ་གནང་ནས་བཙན་རྒྱལ་སྲ་བརྟན་དུ་བཏང་།", bio_hi: "शक्तिशाली कुलों पर शाही अधिकार को फिर से स्थापित किया और सैन्य अभियानों को जारी रखा, जिससे साम्राज्य मजबूत हुआ।", achievements: ["Curbed the power of the Gar clan."], achievements_ti: ["མགར་གྱི་རིགས་རྒྱུད་ཀྱི་དབང་ཤུགས་བཀག"], achievements_hi: ["गर कबीले की शक्ति पर अंकुश लगाया।"], challenges: ["Internal power struggles with aristocratic clans."], challenges_ti: ["སྐུ་དྲག་རིགས་རྒྱུད་དང་ནང་གི་དབང་ཆའི་འཐབ་རྩོད།"], challenges_hi: ["अभिजात वर्ग के कुलों के साथ आंतरिक सत्ता संघर्ष।"], cultural_influence: "Known as a powerful and effective military leader.", cultural_influence_ti: "དམག་དཔོན་སྟོབས་ཆེན་དང་ནུས་པ་ཅན་ཞིག་ཏུ་གྲགས།", cultural_influence_hi: "एक शक्तिशाली और प्रभावी सैन्य नेता के रूप में जाने जाते हैं।" },
    {
        id: 36,
        name: "Lha",
        name_ti: "ལྷ་བལ་པོ།",
        name_hi: "ल्हा",
        tibetan_name: "ལྷ་བལ་པོ།",
        reign: "c. 704–705",
        bio: "Son of Tridu Songtsen, Lha Balpo was an infant king whose reign was extremely short. He was deposed by his powerful grandmother, the Empress Dowager Khimalöd, who then placed the younger Tride Tsuktsen (Me Agtsom) on the throne.",
        bio_ti: "འདུས་སྲོང་མང་པོ་རྗེའི་སྲས། ལྷ་བལ་པོ་ནི་བྱིས་པ་རྒྱལ་པོ་ཞིག་ཡིན་ལ། ཁོང་གི་སྲིད་དབང་ཤིན་ཏུ་ཐུང་། ཁོང་གི་ཕྱི་མོ་སྟོབས་ཆེན་བཙན་མོ་ཁྲི་མ་ལོད་ཀྱིས་ཁྲི་ལས་ཕབ་སྟེ། དེ་ནས་ཁྲི་ལྡེ་གཙུག་བརྟན་(མེས་ཨག་ཚོམས)གཞོན་པ་རྒྱལ་ཁྲིར་བཀོད།",
        bio_hi: "त्रिदु सोंगत्सेन के पुत्र, ल्हा बल्पो एक शिशु राजा थे जिनका शासनकाल अत्यंत छोटा था। उन्हें उनकी शक्तिशाली दादी, महारानी खिमालोड द्वारा पदच्युत कर दिया गया, जिन्होंने फिर छोटे त्रिदे त्सुगत्सेन (मे अग्त्सोम) को सिंहासन पर बैठाया।",
        achievements: ["Briefly held the throne as an infant."],
        achievements_ti: ["བྱིས་པའི་སྐབས་སུ་རྒྱལ་ཁྲི་ཐུང་ངུའི་རིང་བཟུང་།"],
        achievements_hi: ["शिशु के रूप में संक्षिप्त रूप से सिंहासन संभाला।"],
        challenges: ["Deposed by his grandmother due to his infancy."],
        challenges_ti: ["བྱིས་པ་ཡིན་པའི་རྐྱེན་གྱིས་ཕྱི་མོས་ཁྲི་ལས་ཕབ།"],
        challenges_hi: ["शिशु होने के कारण अपनी दादी द्वारा पदच्युत कर दिए गए।"],
        cultural_influence: "His brief reign is an example of the power struggles within the Tibetan court, particularly the influence of royal women.",
        cultural_influence_ti: "ཁོང་གི་སྲིད་དབང་ཐུང་ངུ་དེས་བོད་ཀྱི་རྒྱལ་པོའི་ནང་གི་དབང་ཆའི་འཐབ་རྩོད་མཚོན་ལ། ལྷག་པར་དུ་བཙུན་མོའི་ཤུགས་རྐྱེན་མཚོན།",
        cultural_influence_hi: "उनका संक्षिप्त शासनकाल तिब्बती दरबार के भीतर सत्ता संघर्ष, विशेष रूप से शाही महिलाओं के प्रभाव का एक उदाहरण है।"
    },
    {
        id: 37,
        name: "Me Agtsom",
        name_ti: "མེས་ཨག་ཚོམས།",
        name_hi: "मे अग्त्सोम",
        tibetan_name: "ཁྲི་ལྡེ་གཙུག་བརྟན།",
        reign: "c. 704–755",
        bio: "Also known as Tride Tsuktsen. His long reign was marked by continued imperial expansion and major cultural developments, including marrying the Chinese Tang princess Jincheng. His era saw growing Buddhist influence, which sometimes clashed with the traditional nobility and Bön supporters.",
        bio_ti: "ཁྲི་ལྡེ་གཙུག་བརྟན་ཞེས་ཀྱང་གྲགས། ཁོང་གི་སྐུ་རིང་ལ་བཙན་རྒྱལ་གྱི་རྒྱ་སྐྱེད་མུ་མཐུད་དུ་གནང་བ་དང་། རིག་གནས་ཀྱི་འཕེལ་རྒྱས་ཆེན་པོ་བྱུང་བ་སྟེ། རྒྱ་ནག་ཐང་གི་སྲས་མོ་ཀིམ་ཤིང་ཀོང་ཇོ་ཁབ་ཏུ་བཞེས་པ་ཚུད། ཁོང་གི་དུས་རབས་སུ་ནང་བསྟན་གྱི་ཤུགས་རྐྱེན་ཇེ་ཆེར་འགྲོ་བ་མཐོང་ལ། དེས་སྐབས་རེ་སྲོལ་རྒྱུན་གྱི་སྐུ་དྲག་དང་བོན་ལ་རྒྱབ་སྐྱोरབྱེད་མཁན་རྣམས་དང་འགལ་ཟླ་བྱུང་།",
        bio_hi: "उन्हें त्रिदे त्सुगत्सेन के नाम से भी जाना जाता है। उनके लंबे शासनकाल में निरंतर शाही विस्तार और प्रमुख सांस्कृतिक विकास हुए, जिसमें चीनी तांग राजकुमारी जिनचेंग से विवाह भी शामिल था। उनके युग में बौद्ध प्रभाव बढ़ता गया, जो कभी-कभी पारंपरिक कुलीनता और बॉन समर्थकों के साथ टकराता था।",
        achievements: ["Married Princess Jincheng of Tang China.", "Oversaw expansion of the empire into Central Asia."],
        achievements_ti: ["རྒྱ་ནག་ཐང་གི་སྲས་མོ་ཀིམ་ཤིང་ཀོང་ཇོ་ཁབ་ཏུ་བཞེས།", "བཙན་རྒྱལ་དབུས་ཨེ་ཤ་ཡའི་ཕྱོགས་སུ་རྒྱ་སྐྱེད་བཏང་བར་ལྟ་སྐུལ་མཛད།"],
        achievements_hi: ["चीन के तांग की राजकुमारी जिनचेंग से विवाह किया।", "मध्य एशिया में साम्राज्य के विस्तार की देखरेख की।"],
        challenges: ["Balancing the influence of pro-Buddhist factions and the traditional Bön nobility.", "Managed conflicts with Tang China and Arab Caliphates."],
        challenges_ti: ["ནང་བསྟན་ལ་རྒྱབ་སྐྱོར་བྱེད་པའི་ཕྱོགས་གཏོགས་དང་སྲོལ་རྒྱུན་གྱི་བོན་གྱི་སྐུ་དྲག་གི་ཤུགས་རྐྱེན་དོ་སྙོམས་བྱེད་པ།", "ཐང་རྒྱལ་རབས་དང་ཨ་རབ་ཀྱི་ཁ་ལི་ཧྥ་རྒྱལ་ཁབ་དང་འགལ་ཟླ་འཛིན་སྐྱོང་བྱས།"],
        challenges_hi: ["बौद्ध-समर्थक गुटों और पारंपरिक बॉन कुलीनता के प्रभाव को संतुलित करना।", "तांग चीन और अरब खलीफाओं के साथ संघर्षों का प्रबंधन किया।"],
        cultural_influence: "A pivotal reign that saw Buddhism gain significant ground in Tibet, setting the stage for his son, Trisong Detsen, to establish it as the state religion.",
        cultural_influence_ti: "ནང་བསྟན་གྱིས་བོད་དུ་གནས་བབ་གལ་ཆེན་ཐོབ་པའི་སྐུ་རིང་གལ་ཆེན་ཞིག་ཡིན་ལ། ཁོང་གི་སྲས་ཁྲི་སྲོང་ལྡེ་བཙན་གྱིས་དེ་རྒྱལ་ཁབ་ཀྱི་ཆོས་ལུགས་སུ་འཛུགས་པའི་རྨང་གཞི་བཏིང་།",
        cultural_influence_hi: "एक महत्वपूर्ण शासनकाल जिसमें तिब्बत में बौद्ध धर्म ने महत्वपूर्ण जमीन हासिल की, जिसने उनके बेटे, त्रिसोंग देत्सेन के लिए इसे राज्य धर्म के रूप में स्थापित करने का मंच तैयार किया।"
    },
    { id: 38, name: "Trisong Detsen", name_ti: "ཁྲི་སྲོང་ལྡེ་བཙན།", name_hi: "त्रिसोंग देत्सेन", tibetan_name: "ཁྲི་སྲོང་ལྡེ་བཙན།", reign: "755–797", bio: "Second great 'Dharma King'. He established Buddhism as the state religion, founded Samye Monastery, and invited Padmasambhava to Tibet. The empire reached its greatest extent under his rule.", bio_ti: "'ཆོས་རྒྱལ་' ཆེན་པོ་གཉིས་པ། ཁོང་གིས་ནང་བསྟན་རྒྱལ་ཁབ་ཀྱི་ཆོས་ལུགས་སུ་བཙུགས། བསམ་ཡས་དགོན་པ་བཙུགས། པདྨ་འབྱུང་གནས་བོད་དུ་གདན་དྲངས། ཁོང་གི་སྐུ་རིང་ལ་བཙན་རྒྱལ་རྒྱ་ཁྱོན་ཆེ་ཤོས་སུ་སླེབས།", bio_hi: "दूसरे महान 'धर्म राजा'। उन्होंने बौद्ध धर्म को राज्य धर्म के रूप में स्थापित किया, साम्ये मठ की स्थापना की, और पद्मसंभव को तिब्बत में आमंत्रित किया। उनके शासन में साम्राज्य अपने सबसे बड़े विस्तार तक पहुंचा।", achievements: ["Established Buddhism as state religion.", "Founded Samye Monastery."], achievements_ti: ["ནང་བསྟན་རྒྱལ་ཁབ་ཀྱི་ཆོས་ལུགས་སུ་བཙུགས།", "བསམ་ཡས་དགོན་པ་བཙུགས།"], achievements_hi: ["बौद्ध धर्म को राज्य धर्म के रूप में स्थापित किया।", "साम्ये मठ की स्थापना की।"], challenges: ["Resistance from Bön supporters."], challenges_ti: ["བོན་ལ་རྒྱབ་སྐྱོར་བྱེད་མཁན་རྣམས་ཀྱི་ངོ་རྒོལ།"], challenges_hi: ["बॉन समर्थकों से प्रतिरोध।"], cultural_influence: "Cemented Buddhism in Tibet.", cultural_influence_ti: "བོད་དུ་ནང་བསྟན་སྲ་བརྟན་དུ་བཏང་།", cultural_influence_hi: "तिब्बत में बौद्ध धर्म को मजबूत किया।" },
    { id: 39, name: "Muné Tsenpo", name_ti: "མུ་ནེ་བཙན་པོ།", name_hi: "मुने त्सेनपो", tibetan_name: "མུ་ནེ་བཙན་པོ།", reign: "797–799", bio: "Son of Trisong Detsen. Attempted to implement land reforms to reduce the gap between rich and poor, but was unsuccessful and possibly poisoned by his mother.", bio_ti: "ཁྲི་སྲོང་ལྡེ་བཙན་གྱི་སྲས། ཕྱུག་པོ་དང་དབུལ་པོའི་བར་གྱི་ཁྱད་པར་གཅོག་པར་ས་ཞིང་བཅོས་སྒྱུར་ལག་བསྟར་བྱེད་པར་འབད་ཀྱང་། ལམ་ལྷོངས་མ་བྱུང་བ་དང་། ཡུམ་གྱིས་དུག་བཏང་བར་བཤད།", bio_hi: "त्रिसोंग देत्सेन के पुत्र। अमीर और गरीब के बीच की खाई को कम करने के लिए भूमि सुधारों को लागू करने का प्रयास किया, लेकिन असफल रहे और संभवतः उनकी मां ने उन्हें जहर दे दिया।", achievements: ["Attempted social and economic reforms."], achievements_ti: ["སྤྱི་ཚོགས་དང་དཔལ་འབྱོར་གྱི་བཅོས་སྒྱུར་བྱེད་པར་འབད།"], achievements_hi: ["सामाजिक और आर्थिक सुधारों का प्रयास किया।"], challenges: ["Failed to implement reforms.", "Short reign, mysterious death."], challenges_ti: ["བཅོས་སྒྱུར་ལག་བསྟར་བྱེད་པར་མ་ལམ་ལྷོངས།", "སྲིད་དབང་ཐུང་ངུ་། གསང་བ་ཅན་གྱི་འདས་གྲོངས།"], challenges_hi: ["सुधारों को लागू करने में विफल।", "संक्षिप्त शासन, रहस्यमय मृत्यु।"], cultural_influence: "Remembered as a king with idealist, though ultimately unsuccessful, social goals.", cultural_influence_ti: "བསམ་བློའི་དམིགས་ཡུལ་ཅན་གྱི་རྒྱལ་པོར་དྲན། འོན་ཀྱང་མཐར་ལམ་ལྷོངས་མ་བྱུང་།", cultural_influence_hi: "एक आदर्शवादी, यद्यपि अंततः असफल, सामाजिक लक्ष्यों वाले राजा के रूप में याद किया जाता है।" },
    { id: 40, name: "Tride Songtsen (Sadnalegs)", name_ti: "ཁྲི་ལྡེ་སྲོང་བཙན། (སད་ན་ལེགས།)", name_hi: "त्रिदे सोंगत्सेन (सदनालेग्स)", tibetan_name: "ཁྲི་ལྡེ་སྲོང་བཙན།", reign: "c. 800–815", bio: "Oversaw the signing of a major peace treaty with Tang China and standardized the translation of Buddhist texts.", bio_ti: "ཐང་རྒྱལ་རབས་དང་ཞི་བའི་ཆིངས་ཡིག་གལ་ཆེན་ཞིག་ལ་མཚན་རྟགས་འགོད་པར་ལྟ་སྐུལ་མཛད་པ་དང་། ནང་པའི་གསུང་རབ་བསྒྱུར་བ་ཚད་ལྡན་བཟོས།", bio_hi: "तांग चीन के साथ एक प्रमुख शांति संधि पर हस्ताक्षर करने की देखरेख की और बौद्ध ग्रंथों के अनुवाद का मानकीकरण किया।", achievements: ["Sino-Tibetan Treaty of 821/822.", "Standardized translation of Buddhist scriptures."], achievements_ti: ["རྒྱ་བོད་ཆིངས་ཡིག་༨༢༡/༨༢༢།", "ནང་པའི་གསུང་རབ་བསྒྱུར་བ་ཚད་ལྡན་བཟོས།"], achievements_hi: ["821/822 की चीन-तिब्बत संधि।", "बौद्ध धर्मग्रंथों के अनुवाद का मानकीकरण किया।"], challenges: ["Maintaining peace with neighboring empires."], challenges_ti: ["ཁྱིམ་མཚེས་བཙན་རྒྱལ་རྣམས་དང་ཞི་བདེ་རྒྱུན་སྐྱོང་བྱེད་པ།"], challenges_hi: ["पड़ोसी साम्राज्यों के साथ शांति बनाए रखना।"], cultural_influence: "His reign marked a period of peace and scholarly consolidation.", cultural_influence_ti: "ཁོང་གི་སྐུ་རིང་ལ་ཞི་བདེ་དང་མཁས་པའི་གཅིག་གྱུར་གྱི་དུས་སྐབས་ཤིག་མཚོན།", cultural_influence_hi: "उनके शासनकाल ने शांति और विद्वतापूर्ण समेकन की अवधि को चिह्नित किया।" },
    { id: 41, name: "Ralpachen", name_ti: "རལ་པ་ཅན།", name_hi: "रल्पचन", tibetan_name: "ཁྲི་རལ་པ་ཅན།", reign: "815–838", bio: "The third great 'Dharma King'. A pious Buddhist who gave great power to the monastic community, which angered the nobility and led to his assassination.", bio_ti: "'ཆོས་རྒྱལ་' གསུམ་པ། ནང་བསྟན་ལ་དད་གུས་ཆེ་བས་དགེ་འདུན་གྱི་སྡེ་ལ་དབང་ཆ་ཆེན་པོ་གནང་། དེས་སྐུ་དྲག་རྣམས་ཁོང་ཁྲོ་ལངས་ནས་ཁོང་བཀྲོངས།", bio_hi: "तीसरे 'धर्म राजा'। एक धर्मपरायण बौद्ध जिन्होंने मठवासी समुदाय को बड़ी शक्ति दी, जिसने कुलीनता को नाराज कर दिया और उनकी हत्या कर दी।", achievements: ["Generous patron of Buddhism.", "Invited many Indian masters to Tibet."], achievements_ti: ["ནང་བསྟན་གྱི་སྦྱིན་བདག་གཏོང་ཕོད་ཅན།", "རྒྱ་གར་གྱི་སློབ་དཔོན་མང་པོ་བོད་དུ་གདན་དྲངས།"], achievements_hi: ["बौद्ध धर्म के उदार संरक्षक।", "कई भारतीय गुरुओं को तिब्बत में आमंत्रित किया।"], challenges: ["Alienated the aristocracy, leading to his assassination."], challenges_ti: ["སྐུ་དྲག་རྣམས་དང་འགལ་ཟླ་བཟོས་ནས་བཀྲོངས།"], challenges_hi: ["कुलीनता को अलग-थलग कर दिया, जिससे उनकी हत्या हो गई।"], cultural_influence: "His patronage greatly advanced Buddhist institutions but destabilized the political balance of the empire.", cultural_influence_ti: "ཁོང་གི་སྦྱིན་བདག་གིས་ནང་བསྟན་གྱི་ལས་ཁུངས་ལ་ཡར་རྒྱས་ཆེན་པོ་བཏང་ཡང་། བཙན་རྒྱལ་གྱི་ཆབ་སྲིད་ཀྱི་དོ་སྙོམས་དཀྲུགས།", cultural_influence_hi: "उनके संरक्षण ने बौद्ध संस्थानों को बहुत उन्नत किया लेकिन साम्राज्य के राजनीतिक संतुलन को अस्थिर कर दिया।" },
    {
        id: 42,
        name: "Langdarma",
        name_ti: "གླང་དར་མ།",
        name_hi: "लांगदरमा",
        tibetan_name: "གླང་དར་མ།",
        reign: "838–842",
        bio: "The last emperor of the unified Tibetan Empire. He is traditionally depicted as an anti-Buddhist king who persecuted the religion. His assassination by a Buddhist monk led to the collapse of the empire and the beginning of the Era of Fragmentation.",
        bio_ti: "གཅིག་གྱུར་གྱི་བོད་ཀྱི་བཙན་རྒྱལ་གྱི་བཙན་པོ་མཐའ་མ། སྲོལ་རྒྱུན་ལྟར་ན། ཁོང་ནི་ནང་བསྟན་ལ་ངོ་རྒོལ་བྱེད་མཁན་གྱི་རྒྱལ་པོ་ཞིག་ཏུ་བྲིས་ཡོད་ལ། ཆོས་ལུགས་ལ་དྲག་གནོན་བྱས། ནང་པའི་གྲྭ་པ་ཞིག་གིས་ཁོང་བཀྲོངས་པ་དེས་བཙན་རྒྱལ་འཇིག་པ་དང་སིལ་བུའི་དུས་རབས་ཀྱི་འགོ་འཛུགས་པའི་རྒྱུ་རྐྱེན་བཟོས།",
        bio_hi: "एकीकृत तिब्बती साम्राज्य के अंतिम सम्राट। उन्हें पारंपरिक रूप से एक बौद्ध-विरोधी राजा के रूप में चित्रित किया जाता है जिन्होंने धर्म पर अत्याचार किया। एक बौद्ध भिक्षु द्वारा उनकी हत्या से साम्राज्य का पतन हुआ और विखंडन के युग की शुरुआत हुई।",
        achievements: ["Reversed pro-Buddhist policies."],
        achievements_ti: ["ནང་བསྟན་ལ་རྒྱབ་སྐྱོར་བྱེད་པའི་སྲིད་ཇུས་ཕྱིར་ལོག་བྱས།"],
        achievements_hi: ["बौद्ध-समर्थक नीतियों को उलट दिया।"],
        challenges: ["Assassination led to the empire's collapse."],
        challenges_ti: ["ཁོང་བཀྲོངས་པས་བཙན་རྒྱལ་འཇིག་པར་འཁྲིད།"],
        challenges_hi: ["हत्या से साम्राज्य का पतन हो गया।"],
        cultural_influence: "His death marks the end of the unified Tibetan Empire.",
        cultural_influence_ti: "ཁོང་འདས་པ་དེས་གཅིག་གྱུར་གྱི་བོད་ཀྱི་བཙན་རྒྱལ་གྱི་མཇུག་རྫོགས་པ་མཚོན།",
        cultural_influence_hi: "उनकी मृत्यु एकीकृत तिब्बती साम्राज्य के अंत का प्रतीक है।"
    }
];

export const dalaiLamasData: DalaiLama[] = [
    {
        id: 1,
        name: "Gedun Drupa",
        name_ti: "དགེ་འདུན་གྲུབ་པ།",
        name_hi: "गेदुन द्रुपा",
        tibetan_name: "དགེ་འདུན་གྲུབ་པ།",
        reign: "1391–1474 (Posthumous)",
        bio: "A disciple of Tsongkhapa, founder of the Gelug school. Gedun Drupa founded Tashi Lhunpo Monastery. He was a renowned scholar and teacher, but was not recognized as the Dalai Lama during his lifetime. The title was conferred posthumously.",
        bio_ti: "རྗེ་ཙོང་ཁ་པའི་སློབ་མ། དགེ་ལུགས་པའི་སྲོལ་གཏོད་མཁན། དགེ་འདུན་གྲུབ་པས་བཀྲ་ཤིས་ལྷུན་པོ་དགོན་པ་ཕྱག་བཏབ། ཁོང་ནི་མཁས་པ་དང་དགེ་རྒན་སྙན་གྲགས་ཅན་ཞིག་ཡིན་ཡང་། སྐུ་འཚོ་བའི་རིང་ལ་རྒྱལ་བ་རིན་པོ་ཆེར་ངོས་འཛིན་མ་བྱུང་། མཚན་གནས་འདི་སྐུ་འདས་པའི་རྗེས་སུ་ཕུལ།",
        bio_hi: "त्सोंग्खपा के शिष्य, जिन्होंने गेलुग स्कूल की स्थापना की। गेदुन द्रुपा ने ताशी ल्हुनपो मठ की स्थापना की। वे एक प्रसिद्ध विद्वान और शिक्षक थे, लेकिन उनके जीवनकाल में उन्हें दलाई लामा के रूप में मान्यता नहीं मिली थी। यह उपाधि उन्हें मरणोपरांत प्रदान की गई।",
        teachings_summary: "Focused on establishing a firm monastic foundation based on Vinaya (monastic discipline) and systematic study of philosophy.",
        teachings_summary_ti: "འདུལ་བ་གཞི་རྩར་བཟུང་བའི་དགོན་པའི་རྨང་གཞི་བརྟན་པོ་ཞིག་འཛུགས་པ་དང་། ལྟ་གྲུབ་ལ་གོ་རིམ་ལྡན་པའི་སློབ་གཉེར་བྱེད་རྒྱུར་དམིགས་པ་ཡིན།",
        teachings_summary_hi: "विनय (मठवासी अनुशासन) और दर्शन के व्यवस्थित अध्ययन पर आधारित एक मजबूत मठवासी नींव स्थापित करने पर ध्यान केंद्रित किया।",
        imageUrl: "https://picsum.photos/seed/dalailama1/400/300"
    },
    {
        id: 2,
        name: "Gedun Gyatso",
        name_ti: "དགེ་འདུན་རྒྱ་མཚོ།",
        name_hi: "गेदुन ग्यात्सो",
        tibetan_name: "དགེ་འདུན་རྒྱ་མཚོ།",
        reign: "1475–1542 (Posthumous)",
        bio: "Recognized as the reincarnation of Gedun Drupa, he was a mystic and scholar who traveled widely. He became the abbot of Drepung Monastery, which became the main seat of the Dalai Lamas. He also founded Chokhorgyal Monastery.",
        bio_ti: "དགེ་འདུན་གྲུབ་པའི་ཡང་སྲིད་དུ་ངོས་འཛིན་གནང་། ཁོང་ནི་ལམ་རིམ་མཁས་པ་དང་མཁས་པ་ཞིག་ཡིན་ལ། ས་ཕྱོགས་གང་སར་ཕེབས། ཁོང་འབྲས་སྤུངས་དགོན་པའི་མཁན་པོར་གྱུར་པ་དང་། དེ་རྒྱལ་བ་རིན་པོ་ཆེའི་གདན་ས་གཙོ་བོར་གྱུར། ཁོང་གིས་ཆོས་འཁོར་རྒྱལ་དགོན་པའང་ཕྱག་བཏབ།",
        bio_hi: "गेदुन द्रुपा के पुनर्जन्म के रूप में पहचाने गए, वे एक रहस्यवादी और विद्वान थे जिन्होंने व्यापक रूप से यात्रा की। वे ड्रेपुंग मठ के मठाधीश बने, जो दलाई लामाओं की मुख्य गद्दी बन गया। उन्होंने चोखोरग्याल मठ की भी स्थापना की।",
        teachings_summary: "Known for his mystical visions and contributions to the Gelug tradition's tantric practices. His writings and teachings further consolidated the school's doctrines.",
        teachings_summary_ti: "ཁོང་གི་ལམ་རིམ་གྱི་མངོན་རྟོགས་དང་དགེ་ལུགས་པའི་རྒྱུད་ཀྱི་ཉམས་ལེན་ལ་མཛད་རྗེས་ཆེན་པོ་བཞག་པས་གྲགས། ཁོང་གི་གསུང་རྩོམ་དང་བསླབ་བྱས་གྲུབ་མཐའི་གཞུང་ལུགས་སྲ་བརྟན་དུ་བཏང་།",
        teachings_summary_hi: "अपने रहस्यमय दर्शन और गेलुग परंपरा के तांत्रिक प्रथाओं में योगदान के लिए जाने जाते हैं। उनके लेखन और शिक्षाओं ने स्कूल के सिद्धांतों को और मजबूत किया।",
        imageUrl: "https://picsum.photos/seed/dalailama2/400/300"
    },
    {
        id: 3,
        name: "Sonam Gyatso",
        name_ti: "བསོད་ནམས་རྒྱ་མཚོ།",
        name_hi: "सोनम ग्यात्सो",
        tibetan_name: "བསོད་ནམས་རྒྱ་མཚོ།",
        reign: "1543–1588",
        bio: "The first to be officially given the title 'Dalai Lama' by the Mongol ruler Altan Khan in 1578. He was a great missionary who spread Tibetan Buddhism in Mongolia, cementing a powerful spiritual and political alliance between Tibet and the Mongols.",
        bio_ti: "༡༥༧༨ ལོར་སོག་པོའི་རྒྱལ་པོ་ཨལ་ཏན་ཁཱན་གྱིས་ 'ཏཱ་ལའི་བླ་མ་' ཞེས་པའི་མཚན་གནས་དངོས་སུ་ཕུལ་མཁན་དང་པོ་དེ་ཡིན། ཁོང་ནི་བོད་བརྒྱུད་ནང་བསྟན་སོག་ཡུལ་དུ་དར་སྤེལ་གཏོང་མཁན་གྱི་ཆོས་སྤེལ་བ་ཆེན་པོ་ཞིག་ཡིན་ལ། དེས་བོད་དང་སོག་པོའི་བར་གྱི་ཆོས་སྲིད་ཀྱི་མནའ་འབྲེལ་སྟོབས་ཆེན་ཞིག་སྲ་བརྟན་དུ་བཏང་།",
        bio_hi: "1578 में मंगोल शासक अल्तान खान द्वारा आधिकारिक तौर पर 'दलाई लामा' की उपाधि पाने वाले पहले व्यक्ति। वे एक महान मिशनरी थे जिन्होंने मंगोलिया में तिब्बती बौद्ध धर्म का प्रसार किया, जिससे तिब्बत और मंगोलों के बीच एक शक्तिशाली आध्यात्मिक और राजनीतिक गठबंधन मजबूत हुआ।",
        teachings_summary: "His primary focus was on missionary activities and diplomacy, establishing the Gelug school as a major religious force outside Tibet.",
        teachings_summary_ti: "ཁོང་གི་དམིགས་ཡུལ་གཙོ་བོ་ནི་ཆོས་སྤེལ་བའི་ལས་དོན་དང་ཕྱི་འབྲེལ་ཡིན་ལ། དགེ་ལུགས་པའི་གྲུབ་མཐའ་བོད་ཀྱི་ཕྱི་རོལ་དུ་ཆོས་ལུགས་ཀྱི་ནུས་ཤུགས་ཆེན་པོ་ཞིག་ཏུ་བཙུགས།",
        teachings_summary_hi: "उनका प्राथमिक ध्यान मिशनरी गतिविधियों और कूटनीति पर था, जिससे गेलुग स्कूल को तिब्बत के बाहर एक प्रमुख धार्मिक शक्ति के रूप में स्थापित किया गया।",
        imageUrl: "https://picsum.photos/seed/dalailama3/400/300"
    },
    {
        id: 4,
        name: "Yonten Gyatso",
        name_ti: "ཡོན་ཏན་རྒྱ་མཚོ།",
        name_hi: "योन्तेन ग्यात्सो",
        tibetan_name: "ཡོན་ཏན་རྒྱ་མཚོ།",
        reign: "1589–1617",
        bio: "The great-grandson of Altan Khan, Yonten Gyatso was the only non-Tibetan to be recognized as Dalai Lama. His Mongolian heritage strengthened the bond between Tibet and Mongolia, but also led to political rivalries within Tibet.",
        bio_ti: "ཨལ་ཏན་ཁཱན་གྱི་ཚ་བོའི་ཚ་བོ། ཡོན་ཏན་རྒྱ་མཚོ་ནི་བོད་མི་མ་ཡིན་པའི་ཏཱ་ལའི་བླ་མར་ངོས་འཛིན་བྱས་པ་གཅིག་པུ་དེ་ཡིན། ཁོང་གི་སོག་པོའི་རྒྱུད་པས་བོད་དང་སོག་པོའི་བར་གྱི་འབྲེལ་བ་སྲ་བརྟན་དུ་བཏང་ཡང་། བོད་ནང་དུ་ཆབ་སྲིད་ཀྱི་འགྲན་རྩོད་ཀྱང་བསླངས།",
        bio_hi: "अल्तान खान के परपोते, योन्तेन ग्यात्सो दलाई लामा के रूप में पहचाने जाने वाले एकमात्र गैर-तिब्बती थे। उनकी मंगोलियाई विरासत ने तिब्बत और मंगोलिया के बीच संबंधों को मजबूत किया, लेकिन तिब्बत के भीतर राजनीतिक प्रतिद्वंद्विता को भी जन्म दिया।",
        teachings_summary: "His reign was marked by political maneuvering and the increasing influence of Mongolian patrons in Tibetan affairs.",
        teachings_summary_ti: "ཁོང་གི་སྐུ་རིང་ལ་ཆབ་སྲིད་ཀྱི་ཇུས་གཏོགས་དང་བོད་ཀྱི་ལས་དོན་ནང་སོག་པོའི་སྦྱིན་བདག་གི་ཤུགས་རྐྱེན་ཇེ་ཆེར་འགྲོ་བས་ཁྱད་པར་འབྱེད།",
        teachings_summary_hi: "उनके शासनकाल में राजनीतिक तिकड़म और तिब्बती मामलों में मंगोलियाई संरक्षकों का बढ़ता प्रभाव देखा गया।",
        imageUrl: "https://picsum.photos/seed/dalailama4/400/300"
    },
    {
        id: 5,
        name: "Lobsang Gyatso",
        name_ti: "བློ་བཟང་རྒྱ་མཚོ།",
        name_hi: "लोबसांग ग्यात्सो",
        tibetan_name: "ངག་དབང་བློ་བཟང་རྒྱ་མཚོ།",
        reign: "1617–1682",
        bio: "Known as 'The Great Fifth,' he was a brilliant political and spiritual leader. With the help of his Mongol patron Güshi Khan, he unified Tibet under the rule of the Gelug school, becoming the first Dalai Lama to wield both spiritual and temporal power over the entire country. He began construction of the Potala Palace.",
        bio_ti: "'ལྔ་པ་ཆེན་པོ་' ཞེས་གྲགས། ཁོང་ནི་ཆབ་སྲིད་དང་བླ་སྲོག་གི་དབུ་ཁྲིད་རφυད་དུ་འཕགས་པ་ཞིག་ཡིན། ཁོང་གི་སོག་པོའི་སྦྱིན་བདག་གུ་ཤྲི་ཁཱན་གྱི་རོགས་རམ་གྱིས། ཁོང་གིས་བོད་དགེ་ལུགས་པའི་དབང་བསྒྱུར་འོག་གཅིག་ཏུ་བསྒྲིལ་ནས། རྒྱལ་ཁབ་ཡོངས་ལ་ཆོས་སྲིད་གཉིས་ཀྱི་དབང་ཆ་བཟུང་མཁན་གྱི་ཏཱ་ལའི་བླ་མ་དང་པོར་གྱུར། ཁོང་གིས་ཕོ་བྲང་པོ་ཏ་ལའི་འཛུགས་སྐྲུན་འགོ་བཙུགས།",
        bio_hi: "'महान पांचवें' के रूप में जाने जाते हैं, वे एक प्रतिभाशाली राजनीतिक और आध्यात्मिक नेता थे। अपने मंगोल संरक्षक गुशी खान की मदद से, उन्होंने गेलुग स्कूल के शासन के तहत तिब्बत को एकीकृत किया, पूरे देश पर आध्यात्मिक और लौकिक दोनों शक्ति का प्रयोग करने वाले पहले दलाई लामा बने। उन्होंने पोटाला पैलेस का निर्माण शुरू किया।",
        teachings_summary: "A great scholar and practitioner of the Nyingma tradition as well as Gelug. His reign marked a golden age of Tibetan culture, and he established institutions that defined Tibetan governance for centuries.",
        teachings_summary_ti: "དགེ་ལུགས་པ་མ་ཟད་རྙིང་མའི་སྲོལ་རྒྱུན་གྱི་མཁས་པ་དང་ཉམས་ལེན་པ་ཆེན་པོ་ཞིག ཁོང་གི་སྐུ་རིང་ལ་བོད་ཀྱི་རིག་གནས་ཀྱི་དུས་རབས་བཟང་པོ་ཞིག་མཚོན་ལ། ཁོང་གིས་བོད་ཀྱི་སྲིད་སྐྱོང་དུས་རབས་མང་པོའི་རིང་མཚན་ཉིད་འཇོག་པའི་ལས་ཁུངས་བཙུགས།",
        teachings_summary_hi: "गेलुग के साथ-साथ न्यिंग्मा परंपरा के एक महान विद्वान और अभ्यासी। उनके शासनकाल ने तिब्बती संस्कृति के एक स्वर्ण युग को चिह्नित किया, और उन्होंने ऐसी संस्थाएँ स्थापित कीं जिन्होंने सदियों तक तिब्बती शासन को परिभाषित किया।",
        imageUrl: "https://picsum.photos/seed/dalailama5/400/300"
    },
    {
        id: 6,
        name: "Tsangyang Gyatso",
        name_ti: "ཚངས་དབྱངས་རྒྱ་མཚོ།",
        name_hi: "त्सांगयांग ग्यात्सो",
        tibetan_name: "ཚངས་དབྱངས་རྒྱ་མཚོ།",
        reign: "1683–1706",
        bio: "A highly unconventional Dalai Lama, known more for his love of poetry, wine, and women than for monastic life. His beautiful and accessible poems are still beloved in Tibet. His life ended mysteriously amidst political turmoil involving the Mongols and the Manchu Qing dynasty.",
        bio_ti: "ཏཱ་ལའི་བླ་མ་ཐུན་མོང་མ་ཡིན་པ་ཞིག དགོན་པའི་འཚོ་བ་ལས་སྙན་ངག ཆང་། བུད་མེད་བཅས་ལ་དགའ་བས་གྲགས། ཁོང་གི་སྙན་ངག་མཛེས་ཤིང་གོ་སླ་བ་རྣམས་བོད་དུ་ད་ལྟའང་དགའ་པོ་བྱེད། ཁོང་གི་སྐུ་ཚེ་སོག་པོ་དང་མན་ཇུ་ཆིང་རྒྱལ་རབས་དང་འབྲེལ་བའི་ཆབ་སྲིད་ཀྱི་ཟང་ཟིང་གི་ཁྲོད་དུ་གསང་བ་ཅན་གྱི་ངང་ནས་མཇུག་བསྒྲིལ།",
        bio_hi: "एक अत्यधिक अपरंपरागत दलाई लामा, जो मठवासी जीवन की तुलना में अपनी कविता, शराब और महिलाओं के प्रेम के लिए अधिक जाने जाते हैं। उनकी सुंदर और सुलभ कविताएँ आज भी तिब्बत में प्रिय हैं। उनका जीवन मंगोलों और मांचू किंग राजवंश से जुड़ी राजनीतिक उथल-पुथल के बीच रहस्यमय तरीके से समाप्त हो गया।",
        teachings_summary: "While not a traditional teacher, his poems express deep themes of love, impermanence, and the tension between spiritual vows and human desires.",
        teachings_summary_ti: "སྲོལ་རྒྱུན་གྱི་དགེ་རྒན་ཞིག་མིན་ཡང་། ཁོང་གི་སྙན་ངག་གིས་བརྩེ་དུང་། མི་རྟག་པ། བླ་སྲོག་གི་དམ་བཅའ་དང་མིའི་འདོད་པའི་བར་གྱི་འགལ་ཟླ་བཅས་ཀྱི་བརྗོད་བྱ་ཟབ་མོ་མཚོན།",
        teachings_summary_hi: "हालांकि एक पारंपरिक शिक्षक नहीं, उनकी कविताएँ प्रेम, अनित्यता और आध्यात्मिक प्रतिज्ञाओं और मानवीय इच्छाओं के बीच तनाव के गहरे विषयों को व्यक्त करती हैं।",
        imageUrl: "https://picsum.photos/seed/dalailama6/400/300"
    },
    {
        id: 7,
        name: "Kelzang Gyatso",
        name_ti: "བསྐལ་བཟང་རྒྱ་མཚོ།",
        name_hi: "केलसांग ग्यात्सो",
        tibetan_name: "བསྐལ་བཟང་རྒྱ་མཚོ།",
        reign: "1708–1757",
        bio: "His reign saw significant political upheaval, including the establishment of the Manchu Qing protectorate over Tibet. Despite the political challenges, he was a great scholar who founded the Norbulingka, the summer palace of the Dalai Lamas, and was known for his gentle and learned nature.",
        bio_ti: "ཁོང་གི་སྐུ་རིང་ལ་ཆབ་སྲིད་ཀྱི་ཟང་ཟིང་ཆེན་པོ་བྱུང་བ་སྟེ། བོད་ཐོག་མན་ཇུ་ཆིང་གི་སྲུང་སྐྱོབ་འཛུགས་པ་ཚུད། ཆབ་སྲིད་ཀྱི་དཀའ་ངལ་ཡོད་ཀྱང་། ཁོང་ནི་མཁས་པ་ཆེན་པོ་ཞིག་ཡིན་ལ། ཏཱ་ལའི་བླ་མའི་དབྱར་ཁའི་ཕོ་བྲང་ནོར་བུ་གླིང་ག་ཕྱག་བཏབ། ཁོང་གི་གཤིས་རྒྱུད་འཇམ་ཞིང་ཤེས་ཡོན་ཅན་ཡིན་པས་གྲགས།",
        bio_hi: "उनके शासनकाल में महत्वपूर्ण राजनीतिक उथल-पुथल देखी गई, जिसमें तिब्बत पर मांचू किंग संरक्षक की स्थापना भी शामिल थी। राजनीतिक चुनौतियों के बावजूद, वे एक महान विद्वान थे जिन्होंने दलाई लामाओं के ग्रीष्मकालीन महल, नोरबुलिंगका की स्थापना की, और वे अपने सौम्य और विद्वान स्वभाव के लिए जाने जाते थे।",
        teachings_summary: "Emphasized strict monastic discipline and scholarship. He composed many religious texts and commentaries, helping to preserve and clarify Gelug teachings during a turbulent era.",
        teachings_summary_ti: "དགོན་པའི་སྒྲིག་ལམ་ནན་པོ་དང་མཁས་པའི་ཡོན་ཏན་ལ་ནན་བརྗོད་མཛད། ཁོང་གིས་ཆོས་ཀྱི་གསུང་རྩོམ་དང་འགྲེལ་པ་མང་པོ་མཛད་དེ། དུས་ཟང་ཟིང་གི་སྐབས་སུ་དགེ་ལུགས་པའི་བསླབ་བྱ་སྲུང་སྐྱོབ་དང་གསལ་བཤད་བྱེད་པར་རོགས་རམ་མཛད།",
        teachings_summary_hi: "कठोर मठवासी अनुशासन और विद्वता पर जोर दिया। उन्होंने कई धार्मिक ग्रंथों और टिप्पणियों की रचना की, जिससे एक अशांत युग के दौरान गेलुग शिक्षाओं को संरक्षित और स्पष्ट करने में मदद मिली।",
        imageUrl: "https://picsum.photos/seed/dalailama7/400/300"
    },
    {
        id: 8,
        name: "Jamphel Gyatso",
        name_ti: "འཇམ་དཔལ་རྒྱ་མཚོ།",
        name_hi: "जाम्फेल ग्यात्सो",
        tibetan_name: "འཇམ་དཔལ་རྒྱ་མཚོ།",
        reign: "1758–1804",
        bio: "During his time, political power was largely in the hands of the Regent. He was involved in conflicts with the Gurkhas of Nepal. He ordained the 9th Dalai Lama.",
        bio_ti: "ཁོང་གི་སྐུ་རིང་ལ། ཆབ་སྲིད་ཀྱི་དབང་ཆ་ཕལ་ཆེར་རྒྱལ་ཚབ་ཀྱི་ཕྱག་ཏུ་ཡོད། ཁོང་བལ་ཡུལ་གྱི་གོར་ཁ་དང་འཁྲུག་རྩོད་ནང་ཚུད། ཁོང་གིས་རྒྱལ་བ་སྐུ་ཕྲེང་དགུ་པ་རབ་ཏུ་བྱུང་བར་མཛད།",
        bio_hi: "उनके समय में, राजनीतिक शक्ति काफी हद तक रीजेंट के हाथों में थी। वह नेपाल के गोरखाओं के साथ संघर्ष में शामिल थे। उन्होंने 9वें दलाई लामा को नियुक्त किया।",
        teachings_summary: "He was of a mild disposition and not deeply involved in political affairs, preferring a contemplative life.",
        teachings_summary_ti: "ཁོང་གི་གཤིས་རྒྱུད་འཇམ་པོ་ཡིན་པ་དང་། ཆབ་སྲིད་ཀྱི་ལས་དོན་ལ་དེ་ཙམ་གྱི་ཐེ་གཏོགས་མི་གནང་བར། སྒོམ་གྱི་འཚོ་བར་དགའ་པོ་གནང་།",
        teachings_summary_hi: "वे हल्के स्वभाव के थे और राजनीतिक मामलों में गहराई से शामिल नहीं थे, वे एक चिंतनशील जीवन पसंद करते थे।",
        imageUrl: "https://picsum.photos/seed/dalailama8/400/300"
    },
    {
        id: 9,
        name: "Lungtok Gyatso",
        name_ti: "ལུང་རྟོགས་རྒྱ་མཚོ།",
        name_hi: "लुंगटोक ग्यात्सो",
        tibetan_name: "ལུང་རྟོགས་རྒྱ་མཚོ།",
        reign: "1805–1815",
        bio: "The only Dalai Lama to die in childhood, he passed away at the age of nine. Despite his short life, he showed remarkable intelligence and wisdom, impressing the British envoy Thomas Manning.",
        bio_ti: "བྱིས་པའི་དུས་སུ་འདས་པའི་ཏཱ་ལའི་བླ་མ་གཅིག་པུ་དེ་ཡིན་ལ། དགུང་ལོ་དགུ་ལ་འདས། ཁོང་གི་སྐུ་ཚེ་ཐུང་ཡང་། ཁོང་གིས་རིག་པ་དང་ཤེས་རབ་རྣམ་དཔྱོད་ཅན་བསྟན་ནས། དབྱིན་ཇིའི་ཕོ་ཉ་ཐོ་མཱ་སེ་མཱ་ནིང་ལ་བག་ཆགས་ཟབ་མོ་བཞག",
        bio_hi: "बचपन में मरने वाले एकमात्र दलाई लामा, उनका नौ साल की उम्र में निधन हो गया। अपने छोटे जीवन के बावजूद, उन्होंने उल्लेखनीय बुद्धि और ज्ञान दिखाया, जिससे ब्रिटिश दूत थॉमस मैनिंग प्रभावित हुए।",
        teachings_summary: "His life was too short to have a significant teaching legacy, but he is remembered with great affection.",
        teachings_summary_ti: "ཁོང་གི་སྐུ་ཚེ་ཐུང་དྲགས་པས་བསླབ་བྱའི་ཤུལ་བཞག་ཆེན་པོ་ཞིག་མེད། འོན་ཀྱང་ཁོང་ལ་བྱམས་བརྩེ་ཆེན་པོས་དྲན།",
        teachings_summary_hi: "उनका जीवन एक महत्वपूर्ण शिक्षण विरासत के लिए बहुत छोटा था, लेकिन उन्हें बड़े स्नेह के साथ याद किया जाता है।",
        imageUrl: "https://picsum.photos/seed/dalailama9/400/300"
    },
    {
        id: 10,
        name: "Tsultrim Gyatso",
        name_ti: "ཚུལ་ཁྲིམས་རྒྱ་མཚོ།",
        name_hi: "त्सुल्ट्रिम ग्यात्सो",
        tibetan_name: "ཚུལ་ཁྲིམས་རྒྱ་མཚོ།",
        reign: "1816–1837",
        bio: "He was enthroned at the Potala Palace but passed away at the age of 21. He was interested in economic reforms to improve the lives of ordinary Tibetans but died before he could implement them.",
        bio_ti: "ཁོང་ཕོ་བྲང་པོ་ཏ་ལར་ཁྲི་ལ་འཁོད་ཀྱང་། དགུང་ལོ་ ༢༡ ལ་འདས། ཁོང་གིས་བོད་མི་དཀྱུས་མའི་འཚོ་བ་ཡར་རྒྱས་གཏོང་བར་དཔལ་འབྱོར་གྱི་བཅོས་སྒྱུར་ལ་ཐུགས་སྣང་ཡོད་ཀྱང་། དེ་དག་ལག་བསྟར་མ་ཐུབ་གོང་དུ་འདས།",
        bio_hi: "उन्हें पोटाला पैलेस में सिंहासन पर बैठाया गया था, लेकिन 21 साल की उम्र में उनका निधन हो गया। वे आम तिब्बतियों के जीवन को बेहतर बनाने के लिए आर्थिक सुधारों में रुचि रखते थे, लेकिन उन्हें लागू करने से पहले ही उनकी मृत्यु हो गई।",
        teachings_summary: "Known for his humility and strict adherence to monastic vows. His brief life prevented the full development of his potential.",
        teachings_summary_ti: "ཁོང་གི་སེམས་ཆུང་དང་དགོན་པའི་དམ་བཅའ་ནན་པོ་བརྩི་སྲུང་གནང་བས་གྲགས། ཁོང་གི་སྐུ་ཚེ་ཐུང་བས་ཁོང་གི་ནུས་པ་ཡོངས་རྫོགས་འཕེལ་རྒྱས་འགྲོ་མ་ཐུབ།",
        teachings_summary_hi: "अपनी विनम्रता और मठवासी प्रतिज्ञाओं के प्रति सख्त पालन के लिए जाने जाते हैं। उनके संक्षिप्त जीवन ने उनकी क्षमता के पूर्ण विकास को रोक दिया।",
        imageUrl: "https://picsum.photos/seed/dalailama10/400/300"
    },
    {
        id: 11,
        name: "Khedrup Gyatso",
        name_ti: "མཁས་གྲུབ་རྒྱ་མཚོ།",
        name_hi: "खेड्रुप ग्यात्सो",
        tibetan_name: "མཁས་གྲུབ་རྒྱ་མཚོ།",
        reign: "1838–1856",
        bio: "He was recognized as the 11th Dalai Lama in 1842. He was selected as one of two candidates and was confirmed using the Golden Urn. He passed away suddenly at the age of 17, shortly after assuming full power.",
        bio_ti: "༡༨༤༢ ལོར་རྒྱལ་བ་སྐུ་ཕྲེང་བཅུ་གཅིག་པར་ངོས་འཛིན་གནང་། ཁོང་ནི་འོས་མི་གཉིས་ལས་གཅིག་ཏུ་བདམས་པ་དང་། གསེར་བུམ་བཀྲུག་ནས་གཏན་འབེབས་གནང་། ཁོང་དགུང་ལོ་ ༡༧ ལ་དབང་ཆ་ཡོངས་རྫོགས་བཞེས་རྗེས་ไม่นานའདས།",
        bio_hi: "उन्हें 1842 में 11वें दलाई लामा के रूप में मान्यता दी गई थी। उन्हें दो उम्मीदवारों में से एक के रूप में चुना गया था और गोल्डन अर्न का उपयोग करके पुष्टि की गई थी। पूरी शक्ति ग्रहण करने के कुछ ही समय बाद 17 साल की उम्र में उनका अचानक निधन हो गया।",
        teachings_summary: "Like his immediate predecessors, his life was too short to establish a significant independent legacy, and rule remained with the regents.",
        teachings_summary_ti: "ཁོང་གི་སྔོན་གྱི་རྒྱལ་ཚབ་རྣམས་ལྟར། ཁོང་གི་སྐུ་ཚེ་ཐུང་དྲགས་པས་རང་བཙན་གྱི་ཤུལ་བཞག་ཆེན་པོ་ཞིག་འཛུགས་མ་ཐུབ། སྲིད་དབང་རྒྱལ་ཚབ་རྣམས་ཀྱི་ལག་ཏུ་གནས།",
        teachings_summary_hi: "अपने तत्काल पूर्ववर्तियों की तरह, उनका जीवन एक महत्वपूर्ण स्वतंत्र विरासत स्थापित करने के लिए बहुत छोटा था, और शासन रीजेंट के पास ही रहा।",
        imageUrl: "https://picsum.photos/seed/dalailama11/400/300"
    },
    {
        id: 12,
        name: "Trinley Gyatso",
        name_ti: "འཕྲིན་ལས་རྒྱ་མཚོ།",
        name_hi: "त्रिनले ग्यात्सो",
        tibetan_name: "འཕྲིན་ལས་རྒྱ་མཚོ།",
        reign: "1857–1875",
        bio: "Recognized as the 12th Dalai Lama, he also died young, passing away at the age of 18. His era continued the trend of short-lived Dalai Lamas where political power was held by regents.",
        bio_ti: "རྒྱལ་བ་སྐུ་ཕྲེང་བཅུ་གཉིས་པར་ངོས་འཛིན་གནང་། ཁོང་ཡང་དགུང་ལོ་ཆུང་ངུའི་སྐབས་སུ་འདས་ཏེ། དགུང་ལོ་ ༡༨ ལ་འདས། ཁོང་གི་དུས་རབས་ཀྱིས་ཏཱ་ལའི་བླ་མ་སྐུ་ཚེ་ཐུང་བའི་རྒྱུན་མཐུད་དེ། ཆབ་སྲིད་ཀྱི་དབང་ཆ་རྒྱལ་ཚབ་རྣམས་ཀྱིས་བཟུང་།",
        bio_hi: "12वें दलाई लामा के रूप में मान्यता प्राप्त, उनकी भी कम उम्र में मृत्यु हो गई, 18 साल की उम्र में उनका निधन हो गया। उनके युग ने अल्पकालिक दलाई लामाओं की प्रवृत्ति को जारी रखा जहां राजनीतिक शक्ति रीजेंट द्वारा आयोजित की जाती थी।",
        teachings_summary: "His brief reign did not allow him to exert significant influence, as the government continued to be run by the Kashag and the regent.",
        teachings_summary_ti: "ཁོང་གི་སྐུ་རིང་ཐུང་བས་ཁོང་གིས་ཤུགས་རྐྱེན་ཆེན་པོ་ཞིག་འཇོག་མ་ཐུབ། གཞུང་བཀའ་ཤག་དང་རྒྱལ་ཚབ་ཀྱིས་མུ་མཐུད་དུ་སྐྱོང་།",
        teachings_summary_hi: "उनके संक्षिप्त शासनकाल ने उन्हें महत्वपूर्ण प्रभाव डालने की अनुमति नहीं दी, क्योंकि सरकार का संचालन कशाग और रीजेंट द्वारा जारी रखा गया था।",
        imageUrl: "https://picsum.photos/seed/dalailama12/400/300"
    },
    {
        id: 13,
        name: "Thubten Gyatso",
        name_ti: "ཐུབ་བསྟན་རྒྱ་མཚོ།",
        name_hi: "थुबतेन ग्यात्सो",
        tibetan_name: "ཐུབ་བསྟན་རྒྱ་མཚོ།",
        reign: "1876–1933",
        bio: "Known as 'The Great Thirteenth,' he was a major political and social reformer who ended the cycle of short-lived Dalai Lamas. He steered Tibet through a complex period of international politics, dealing with British invasions and Chinese incursions. He modernized Tibet's administration, military, and infrastructure and reasserted Tibet's independence.",
        bio_ti: "'བཅུ་གསུམ་པ་ཆེན་པོ་' ཞེས་གྲགས། ཁོང་ནི་ཆབ་སྲིད་དང་སྤྱི་ཚོགས་ཀྱི་བཅོས་སྒྱུར་མཁན་ཆེན་པོ་ཞིག་ཡིན་ལ། ཏཱ་ལའི་བླ་མ་སྐུ་ཚེ་ཐུང་བའི་རྒྱུན་བཅད། ཁོང་གིས་བོད་རྒྱལ་སྤྱིའི་ཆབ་སྲིད་ཀྱི་དུས་སྐབས་རྙོག་འཛིང་ཅན་ཞིག་གི་ནང་དུ་ལམ་སྟོན་མཛད་དེ། དབྱིན་ཇིའི་བཙན་འཛུལ་དང་རྒྱ་ནག་གི་བཙན་འཛུལ་ལ་གདོང་ལེན་མཛད། ཁོང་གིས་བོད་ཀྱི་འཛིན་སྐྱོང་། དམག་དོན། རྨང་གཞིའི་མཐུན་རྐྱེན་བཅས་དེང་རབས་ཅན་དུ་བསྒྱུར་བ་དང་། བོད་ཀྱི་རང་བཙན་བསྐྱར་དུ་གཏན་འབེབས་མཛད།",
        bio_hi: "'महान तेरहवें' के रूप में जाने जाते हैं, वे एक प्रमुख राजनीतिक और सामाजिक सुधारक थे जिन्होंने अल्पकालिक दलाई लामाओं के चक्र को समाप्त किया। उन्होंने अंतरराष्ट्रीय राजनीति के एक जटिल दौर से तिब्बत का मार्गदर्शन किया, ब्रिटिश आक्रमणों और चीनी घुसपैठ से निपटे। उन्होंने तिब्बत के प्रशासन, सेना और बुनियादी ढांचे का आधुनिकीकरण किया और तिब्बत की स्वतंत्रता को फिर से स्थापित किया।",
        teachings_summary: "He focused on strengthening monastic education and discipline while also engaging with the modern world. His famous political testament prophesied the challenges Tibet would face in the future.",
        teachings_summary_ti: "ཁོང་གིས་དེང་རབས་ཀྱི་འཇིག་རྟེན་དང་འབྲེལ་བ་བྱེད་པ་དང་ཆབས་ཅིག དགོན་པའི་ཤེས་ཡོན་དང་སྒྲིག་ལམ་སྲ་བརྟན་དུ་གཏོང་རྒྱུར་དམིགས་པ་ཡིན། ཁོང་གི་ཆབ་སྲིད་ཀྱི་ཞལ་ཆེམས་གྲགས་ཅན་གྱིས་བོད་ཀྱིས་མ་འོངས་པར་གདོང་ལེན་བྱེད་དགོས་པའི་དཀའ་ངལ་སྔོན་དཔག་མཛད།",
        teachings_summary_hi: "उन्होंने आधुनिक दुनिया के साथ जुड़ते हुए मठवासी शिक्षा और अनुशासन को मजबूत करने पर ध्यान केंद्रित किया। उनके प्रसिद्ध राजनीतिक वसीयतनामे ने उन चुनौतियों की भविष्यवाणी की जिनका तिब्बत को भविष्य में सामना करना पड़ेगा।",
        imageUrl: "https://picsum.photos/seed/dalailama13/400/300"
    },
    {
        id: 14,
        name: "Tenzin Gyatso",
        name_ti: "བསྟན་འཛིན་རྒྱ་མཚོ།",
        name_hi: "तेनज़िन ग्यात्सो",
        tibetan_name: "བསྟན་འཛིན་རྒྱ་མཚོ།",
        reign: "1935–present",
        bio: "The current Dalai Lama. He assumed full political power in 1950 after the Chinese invasion. In 1959, he was forced into exile and established the Central Tibetan Administration in India. A globally recognized figure, he was awarded the Nobel Peace Prize in 1989 for his non-violent struggle. In 2011, he devolved his political power to the democratically elected Sikyong (President).",
        bio_ti: "ད་ལྟའི་རྒྱལ་བ་རིན་པོ་ཆེ། ༡༩༥༠ ལོར་རྒྱ་ནག་གིས་བཙན་འཛུལ་བྱས་རྗེས་ཆབ་སྲིད་ཀྱི་དབང་ཆ་ཡོངས་རྫོགས་བཞེས། ༡༩༥༩ ལོར་བཙན་བྱོལ་དུ་ཕེབས་དགོས་བྱུང་ནས་རྒྱ་གར་དུ་བོད་མིའི་སྒྲིག་འཛུགས་བཙུགས། འཛམ་གླིང་ཡོངས་ཀྱིས་ངོས་འཛིན་བྱེད་པའི་མི་སྣ་ཞིག་ཡིན་ལ། ༡༩༨༩ ལོར་འཚེ་མེད་ཞི་བའི་འཐབ་རྩོད་གནང་བར་ནོ་བེལ་ཞི་བདེའི་གཟེངས་རྟགས་ཕུལ། ༢༠༡༡ ལོར་ཁོང་གིས་ཆབ་སྲིད་ཀྱི་དབང་ཆ་དམངས་གཙོའི་ལམ་ནས་འདེམས་བསྐོ་བྱས་པའི་སྲིད་སྐྱོང་ལ་རྩིས་སྤྲོད་གནང་།",
        bio_hi: "वर्तमान दलाई लामा। उन्होंने 1950 में चीनी आक्रमण के बाद पूर्ण राजनीतिक शक्ति ग्रहण की। 1959 में, उन्हें निर्वासित होने के लिए मजबूर किया गया और भारत में केंद्रीय तिब्बती प्रशासन की स्थापना की। एक विश्व स्तर पर मान्यता प्राप्त व्यक्ति, उन्हें 1989 में उनके अहिंसक संघर्ष के लिए नोबेल शांति पुरस्कार से सम्मानित किया गया था। 2011 में, उन्होंने अपनी राजनीतिक शक्ति लोकतांत्रिक रूप से निर्वाचित सिक्योंग (राष्ट्रपति) को सौंप दी।",
        teachings_summary: "His teachings emphasize universal responsibility, secular ethics based on compassion, religious harmony, and the promotion of human values. He has traveled the world advocating for a more peaceful and compassionate world.",
        teachings_summary_ti: "ཁོང་གི་བསླབ་བྱས་སྤྱི་ཡོངས་ཀྱི་འགན་འཁྲི། སྙིང་རྗེ་གཞི་རྩར་བཟུང་བའི་ཆོས་ལུགས་དང་མ་འབྲེལ་བའི་ཀུན་སྤྱོད། ཆོས་ལུགས་མཐུན་སྒྲིལ། མིའི་རིན་ཐང་གོང་འཕེལ་གཏོང་རྒྱུ་བཅས་ལ་ནན་བརྗོད་བྱེད། ཁོང་འཛམ་གླིང་ས་ཕྱོགས་གང་སར་ཕེབས་ནས། ཞི་བདེ་དང་སྙིང་རྗེ་ལྡན་པའི་འཛམ་གླིང་ཞིག་གི་སྐུལ་འདེད་གནང་།",
        teachings_summary_hi: "उनकी शिक्षाएँ सार्वभौमिक जिम्मेदारी, करुणा पर आधारित धर्मनिरपेक्ष नैतिकता, धार्मिक सद्भाव और मानवीय मूल्यों के प्रचार पर जोर देती हैं। उन्होंने एक अधिक शांतिपूर्ण और करुणामय दुनिया की वकालत करते हुए दुनिया की यात्रा की है।",
        imageUrl: "https://picsum.photos/seed/dalailama14/400/300"
    }
];

export const sakyaRulersData: DynasticRuler[] = [
    {
        id: 1,
        name: 'Drogön Chögyal Phagpa',
        name_ti: 'འགྲོ་མགོན་ཆོས་རྒྱལ་འཕགས་པ།',
        name_hi: 'ड्रोगोन चोग्याल फगपा',
        reign: '1253–1280',
        bio: 'Nephew of Sakya Pandita. He became the spiritual preceptor to Kublai Khan and was given temporal authority over Tibet, establishing the Sakya period of rule under the patronage of the Mongol Yuan dynasty. He developed the Phags-pa script.',
        bio_ti: 'ས་སྐྱ་པཎྜི་ཏའི་ཚ་བོ། ཁོང་ནི་ཀུབ་ལའི་ཁཱན་གྱི་བླ་མར་གྱུར་པ་དང་། བོད་ཀྱི་ཆོས་སྲིད་གཉིས་ཀྱི་དབང་ཆ་ཕུལ་ནས། སོག་པོའི་ཡོན་རྒྱལ་རབས་ཀྱི་མགོན་སྐྱབས་འོག་ས་སྐྱའི་སྲིད་དབང་གི་དུས་རབས་བཙུགས། ཁོང་གིས་འཕགས་པ་ཡི་གེ་གསར་བཟོ་མཛད།',
        bio_hi: 'साक्य पंडिता के भतीजे। वह कुबलई खान के आध्यात्मिक उपदेशक बने और उन्हें तिब्बत पर अस्थायी अधिकार दिया गया, जिससे मंगोल युआन राजवंश के संरक्षण में शासन की साक्य अवधि स्थापित हुई। उन्होंने फग्स-पा लिपि विकसित की।',
        notes: 'Ruled as Imperial Preceptor (Dishi) of the Yuan Dynasty.',
        notes_ti: 'ཡོན་རྒྱལ་རབས་ཀྱི་གོང་མའི་དབུ་བླར་(ཏི་ཤྲི་)དབང་བསྒྱུར།',
        notes_hi: 'युआन राजवंश के शाही उपदेशक (दिशी) के रूप में शासन किया।'
    }
];

export const phagmodrupaRulersData: DynasticRuler[] = [
    {
        id: 1,
        name: 'Tai Situ Changchub Gyaltsen',
        name_ti: 'ཏཱའི་སི་ཏུ་བྱང་ཆུབ་རྒྱལ་མཚན།',
        name_hi: 'ताई सितु चांगचुब ग्याल्त्सेन',
        reign: '1354–1364',
        bio: 'He overthrew the Sakya-Yuan administration in Tibet and established the Phagmodrupa dynasty, effectively restoring Tibetan independence. He reorganized the administration based on the old Tibetan Empire\'s dzong (fortress) system and promoted Tibetan national identity.',
        bio_ti: 'ཁོང་གིས་བོད་དུ་ས་སྐྱ་-ཡོན་གྱི་སྲིད་སྐྱོང་མགོ་རྟིང་སློག་ནས་ཕག་མོ་གྲུ་པའི་རྒྱལ་རབས་བཙུགས་ཏེ། བོད་ཀྱི་རང་བཙན་དངོས་སུ་སླར་གསོ་མཛད། ཁོང་གིས་སྔ་མོའི་བོད་ཀྱི་བཙན་རྒྱལ་གྱི་རྫོང་(མཁར་)ལམ་ལུགས་གཞིར་བཟུང་ནས་འཛིན་སྐྱོང་བསྐྱར་སྒྲིག་མཛད་པ་དང་། བོད་ཀྱི་མི་རིགས་ཀྱི་ངོ་བོ་དར་སྤེལ་བཏང་།',
        bio_hi: 'उन्होंने तिब्बत में साक्य-युआन प्रशासन को उखाड़ फेंका और फग्मोद्रुपा राजवंश की स्थापना की, जिससे तिब्बती स्वतंत्रता प्रभावी रूप से बहाल हुई। उन्होंने पुराने तिब्बती साम्राज्य की द्ज़ोंग (किला) प्रणाली के आधार पर प्रशासन को पुनर्गठित किया और तिब्बती राष्ट्रीय पहचान को बढ़ावा दिया।',
        notes: 'Considered the restorer of Tibetan independence after Mongol influence.',
        notes_ti: 'སོག་པོའི་ཤུགས་རྐྱེན་རྗེས་སུ་བོད་ཀྱི་རང་བཙན་སླར་གསོ་མཛད་མཁན་དུ་བརྩི།',
        notes_hi: 'मंगोल प्रभाव के बाद तिब्बती स्वतंत्रता के पुनर्स्थापक माने जाते हैं।'
    }
];

export const rinpungpaRulersData: DynasticRuler[] = [
    {
        id: 1,
        name: 'Norsang',
        name_ti: 'ནོར་བཟང་།',
        name_hi: 'नोरसंग',
        reign: '1435–1466',
        bio: 'Founder of the Rinpungpa power. As a minister of the Phagmodrupa, he gradually expanded his family\'s influence from their base in Rinpung Dzong (Shigatse), eventually eclipsing the authority of the Phagmodrupa rulers and becoming the de facto rulers of Central Tibet.',
        bio_ti: 'རིན་སྤུངས་པའི་དབང་ཤུགས་གཏོད་མཁན། ཕག་མོ་གྲུ་པའི་བློན་པོའི་ངོས་ནས། ཁོང་གིས་རིམ་བཞིན་རང་གི་ཁྱིམ་ཚང་གི་ཤུགས་རྐྱེན་རིན་སྤུངས་རྫོང་(གཞིས་ཀ་རྩེ་)གི་རྟེན་གཞི་ནས་རྒྱ་སྐྱེད་བཏང་སྟེ། མཐར་ཕག་མོ་གྲུ་པའི་དབང་སྒྱུར་བའི་དབང་ཆ་བཀབ་ནས་དབུས་བོད་ཀྱི་དོན་དངོས་ཀྱི་དབང་སྒྱུར་བར་གྱུར།',
        bio_hi: 'रिनपुंगपा शक्ति के संस्थापक। फग्मोद्रुपा के एक मंत्री के रूप में, उन्होंने धीरे-धीरे रिनपुंग द्ज़ोंग (शिगात्से) में अपने आधार से अपने परिवार के प्रभाव का विस्तार किया, अंततः फग्मोद्रुपा शासकों के अधिकार को ग्रहण कर लिया और मध्य तिब्बत के वास्तविक शासक बन गए।',
    }
];

export const tsangpaDynastyRulersData: DynasticRuler[] = [
    {
        id: 1,
        name: 'Karma Tseten',
        name_ti: 'ཀརྨ་ཚེ་བརྟན།',
        name_hi: 'कर्मा त्सेतेन',
        reign: '1565–1599',
        bio: 'Also known as Shingshak Tseten Dorje. He was a servant of the Rinpungpa who rose up, captured Shigatse, and established the Tsangpa dynasty. His line became the kings of Tsang (West-Central Tibet) and were patrons of the Karma Kagyu school.',
        bio_ti: 'ཞིང་ཤག་ཚེ་བརྟན་རྡོ་རྗེ་ཞེས་ཀྱང་གྲགས། ཁོང་ནི་རིན་སྤུངས་པའི་གཡོག་པོ་ཞིག་ཡིན་ལ། ཁོང་གིས་གྱེན་ལངས་བྱས་ནས་གཞིས་ཀ་རྩེ་བཟུང་སྟེ་གཙང་པ་རྒྱལ་རབས་བཙུགས། ཁོང་གི་རྒྱུད་པ་གཙང་(དབུས་བོད་ནུབ་མ)གི་རྒྱལ་པོར་གྱུར་པ་དང་། ཀརྨ་བཀའ་བརྒྱུད་པའི་སྦྱིན་བདག་ཡིན།',
        bio_hi: 'उन्हें शिंग्शक त्सेतेन दोर्जे के नाम से भी जाना जाता है। वह रिनपुंगपा के एक सेवक थे जो उठे, शिगात्से पर कब्जा कर लिया, और त्सांगपा राजवंश की स्थापना की। उनका वंश त्सांग (पश्चिम-मध्य तिब्बत) का राजा बन गया और कर्म काग्यू स्कूल के संरक्षक थे।',
    }
];

export const panchenLamasData: PanchenLama[] = [
    {
        id: 1,
        name: "Khedrup Gelek Pelzang",
        name_ti: "མཁས་གྲུབ་དགེ་ལེགས་དཔལ་བཟང་།",
        name_hi: "खेडरूप गेलेक पेल्जांग",
        tibetan_name: "མཁས་གྲུབ་དགེ་ལེགས་དཔལ་བཟང་།",
        lifespan: "1385–1438",
        bio: "One of Tsongkhapa's two main disciples, he played a crucial role in the Gelug tradition. He was posthumously recognized as the first Panchen Lama by the 5th Dalai Lama.",
        bio_ti: "རྗེ་ཙོང་ཁ་པའི་སློབ་མ་གཙོ་བོ་གཉིས་ཀྱི་ནང་ནས་གཅིག ཁོང་གིས་དགེ་ལུགས་པའི་སྲོལ་རྒྱུན་ནང་དུ་གནད་འགག་གི་役割བཞེས། ཁོང་སྐུ་འདས་པའི་རྗེས་སུ་རྒྱལ་བ་སྐུ་ཕྲེང་ལྔ་པས་པཎ་ཆེན་བླ་མ་དང་པོར་ངོས་འཛིན་མཛད།",
        bio_hi: "त्सोंग्खपा के दो मुख्य शिष्यों में से एक, उन्होंने गेलुग परंपरा में एक महत्वपूर्ण भूमिका निभाई। उन्हें 5वें दलाई लामा द्वारा मरणोपरांत पहले पंचेन लामा के रूप में मान्यता दी गई थी।"
    },
    {
        id: 4,
        name: "Lobsang Chökyi Gyaltsen",
        name_ti: "བློ་བཟང་ཆོས་ཀྱི་རྒྱལ་མཚན།",
        name_hi: "लोबसांग चोकी ग्याल्त्सेन",
        tibetan_name: "བློ་བཟང་ཆོས་ཀྱི་རྒྱལ་མཚན།",
        lifespan: "1570–1662",
        bio: "A highly influential tutor to the 4th and 5th Dalai Lamas. The 5th Dalai Lama declared him to be an emanation of Amitābha Buddha and bestowed the title of 'Panchen Lama,' establishing Tashi Lhunpo monastery as his seat. He was the first to hold the title during his lifetime.",
        bio_ti: "རྒྱལ་བ་སྐུ་ཕྲེང་བཞི་པ་དང་ལྔ་པའི་ཡོངས་འཛིན་ཤུགས་རྐྱེན་ཆེ་བ་ཞིག རྒྱལ་བ་སྐུ་ཕྲེང་ལྔ་པས་ཁོང་ནི་སངས་རྒྱས་འོད་དཔག་མེད་ཀྱི་སྤྲུལ་པ་ཡིན་པར་བསྒྲགས་ནས་ 'པཎ་ཆེན་བླ་མ' ཞེས་པའི་མཚན་གནས་ཕུལ་བ་དང་། བཀྲ་ཤིས་ལྷུན་པོ་དགོན་པ་ཁོང་གི་གདན་ས་རུ་བཙུགས། ཁོང་ནི་སྐུ་འཚོ་བའི་རིང་ལ་མཚན་གནས་འདི་བཞེས་མཁན་དང་པོ་དེ་ཡིན།",
        bio_hi: "चौथे और पांचवें दलाई लामाओं के एक अत्यधिक प्रभावशाली शिक्षक। 5वें दलाई लामा ने उन्हें अमिताभ बुद्ध का अवतार घोषित किया और 'पंचेन लामा' की उपाधि प्रदान की, ताशी ल्हुनपो मठ को उनकी गद्दी के रूप में स्थापित किया। वह अपने जीवनकाल में यह उपाधि धारण करने वाले पहले व्यक्ति थे।"
    }
];

export const fragmentationEraData: HistoricalPeriod[] = [
    {
        id: 1,
        period: "Era of Fragmentation",
        period_ti: "སིལ་བུའི་དུས་རབས།",
        period_hi: "विखंडन का युग",
        summary: "After the assassination of Emperor Langdarma in 842, the unified Tibetan Empire collapsed into civil war. His two sons, Yumtän and Ösung, vied for control, splitting the royal lineage. Central authority disappeared, and Tibet broke apart into numerous small, competing kingdoms and local hegemonies led by warlords and descendants of the old nobility. This period lasted for roughly 400 years and saw a decline in the political influence of Tibet but also a grassroots revival and dissemination of Buddhism from the east (Amdo) and west (Guge) of the country.",
        summary_ti: "༨༤༢ ལོར་བཙན་པོ་གླང་དར་མ་བཀྲོངས་པའི་རྗེས། གཅིག་གྱུར་གྱི་བོད་ཀྱི་བཙན་རྒྱལ་ནང་འཁྲུག་ཏུ་ཞུགས། ཁོང་གི་སྲས་གཉིས་ཏེ། ཡུམ་བརྟན་དང་འོད་སྲུངས་གཉིས་ཀྱིས་དབང་ཆ་འཕྲོག་རེས་བྱས་ནས་རྒྱལ་པོའི་གདུང་རྒྱུད་ཁག་གཉིས་སུ་གྱེས། དབུས་ཀྱི་དབང་ཆ་མེད་པར་གྱུར་པ་དང་། བོད་དམག་དཔོན་དང་སྐུ་དྲག་རྙིང་པའི་རྒྱུད་འཛིན་པས་དབུ་ཁྲིད་པའི་རྒྱལ་ཕྲན་དང་ས་གནས་ཀྱི་དབང་འཛིན་པ་མང་པོ་ཞིག་ཏུ་སིལ་བུར་ཐོར། དུས་སྐབས་འདི་ལོ་༤༠༠ ཙམ་གནས་པ་དང་། བོད་ཀྱི་ཆབ་སྲིད་ཀྱི་ཤུགས་རྐྱེན་ཉམས་པ་མཐོང་ཡང་། རྒྱལ་ཁབ་ཀྱི་ཤར་ཕྱོགས་(ཨ་མདོ་)དང་ནུབ་ཕྱོགས་(གུ་གེ་)ནས་ནང་བསྟན་གྱི་དམངས་ཁྲོད་ཀྱི་བསྐྱར་དར་དང་ཁྱབ་སྤེལ་ཡང་བྱུང་།",
        summary_hi: "842 में सम्राट लांगदरमा की हत्या के बाद, एकीकृत तिब्बती साम्राज्य गृहयुद्ध में ढह गया। उनके दो पुत्रों, युमतान और ओसुंग ने नियंत्रण के लिए प्रतिस्पर्धा की, जिससे शाही वंश विभाजित हो गया। केंद्रीय अधिकार गायब हो गया, और तिब्बत सरदारों और पुराने कुलीनों के वंशजों के नेतृत्व में कई छोटे, प्रतिस्पर्धी राज्यों और स्थानीय आधिपत्य में टूट गया। यह अवधि लगभग 400 वर्षों तक चली और इसमें तिब्बत के राजनीतिक प्रभाव में गिरावट देखी गई, लेकिन देश के पूर्व (अमदो) और पश्चिम (गुगे) से बौद्ध धर्म का जमीनी स्तर पर पुनरुद्धार और प्रसार भी हुआ।",
        key_events: [
            "Assassination of Langdarma (842).",
            "Civil war between the lines of Yumtän and Ösung.",
            "Collapse of central authority and the end of the Yarlung Dynasty's effective rule.",
            "Rise of local warlords and independent kingdoms.",
            "Later propagation (Phyi-dar) of Buddhism from western and eastern Tibet."
        ],
        key_events_ti: [
            "གླང་དར་མ་བཀྲོངས་པ། (༨༤༢)",
            "ཡུམ་བརྟན་དང་འོད་སྲུངས་ཀྱི་རྒྱུད་པའི་བར་གྱི་ནང་འཁྲུག",
            "དབུས་ཀྱི་དབང་ཆ་འཇིག་པ་དང་ཡར་ཀླུང་རྒྱལ་རབས་ཀྱི་དོན་དངོས་ཀྱི་དབང་བསྒྱུར་མཇུག་བསྒྲིལ་བ།",
            "ས་གནས་ཀྱི་དམག་དཔོན་དང་རང་བཙན་གྱི་རྒྱལ་ཕྲན་རྣམས་དར་བ།",
            "བོད་ཀྱི་ནུབ་ཕྱོགས་དང་ཤར་ཕྱོགས་ནས་ནང་བསྟན་གྱི་བསྟན་པ་ཕྱི་དར་བྱུང་བ།"
        ],
        key_events_hi: [
            "लांगदरमा की हत्या (842)।",
            "युमतान और ओसुंग के वंशों के बीच गृहयुद्ध।",
            "केंद्रीय अधिकार का पतन और यारलुंग राजवंश के प्रभावी शासन का अंत।",
            "स्थानीय सरदारों और स्वतंत्र राज्यों का उदय।",
            "पश्चिमी और पूर्वी तिब्बत से बौद्ध धर्म का बाद का प्रचार (फी-दार)।"
        ]
    }
];

export const sinoTibetanRelationsData: HistoricalPeriod[] = [
    // Data remains unchanged, can be used as is
];

export const cultureData: ContentSection[] = [
    // Data remains unchanged, can be used as is
];

export const religionSchoolsData: ReligionSchool[] = [
    // Data remains unchanged, can be used as is
];

export const medicineTopicsData: MedicineTopic[] = [
    // Data remains unchanged, can be used as is
];