
import { MediaOutlet } from '../types';

export const mediaOutlets: MediaOutlet[] = [
    {
        name: 'Radio Free Asia – Tibetan (RFA Tibetan)',
        name_ti: 'རླུང་འཕྲིན་ཨེ་ཤེ་ཡ་རང་དབང་མ། – བོད་སྐད།',
        name_hi: 'रेडियो फ्री एशिया - तिब्बती (RFA तिब्बती)',
        url: 'https://www.rfa.org/english/tibet/',
        description: 'Independent U.S.-based broadcaster providing news, reports, and interviews.',
        description_ti: 'ཨ་རི་ལ་རྟེན་གཞི་བྱས་པའི་རང་དབང་ཅན་གྱི་རྒྱང་སྒྲོག་ཁང་ཞིག་ཡིན་ལ། གསར་འགྱུར། སྙན་ཐོ། བཅར་འདྲི་བཅས་མཁོ་སྤྲོད་བྱེད།',
        description_hi: 'स्वतंत्र यू.एस.-आधारित प्रसारक जो समाचार, रिपोर्ट और साक्षात्कार प्रदान करता है।',
        warning: 'The Tibetan service is scheduled to close by the end of May 2025.',
        warning_ti: 'བོད་སྐད་སྡེ་ཚན་འདི་༢༠༢༥ ལོའི་ཟླ་༥ པའི་མཇུག་ཏུ་སྒོ་རྒྱག་རྒྱུ་ཡིན་པར་བསྒྲགས།',
        warning_hi: 'तिब्बती सेवा मई 2025 के अंत तक बंद होने वाली है।',
    },
    {
        name: 'Voice of America – Tibetan (VOA Tibetan)',
        name_ti: 'ཨ་རིའི་རླུང་འཕྲིན། – བོད་སྐད།',
        name_hi: 'वॉयस ऑफ अमेरिका - तिब्बती (VOA तिब्बती)',
        url: 'https://www.voatibetan.com/',
        description: 'U.S. government-funded international broadcaster. Provides news and information to Tibetan-speaking audiences.',
        description_ti: 'ཨ་རི་གཞུང་གི་རོགས་སྐྱོར་བྱེད་པའི་རྒྱལ་སྤྱིའི་རྒྱང་སྒྲོག་ཁང་། བོད་སྐད་ཉན་མཁན་རྣམས་ལ་གསར་འགྱུར་དང་གནས་ཚུལ་མཁོ་སྤྲོད་བྱེད།',
        description_hi: 'अमेरिकी सरकार द्वारा वित्तपोषित अंतर्राष्ट्रीय प्रसारक। तिब्बती भाषी दर्शकों को समाचार और जानकारी प्रदान करता है।',
    },
    {
        name: 'Tibet Times (བོད་ཀྱི་དུས་བབ།)',
        name_ti: 'བོད་ཀྱི་དུས་བབ།',
        name_hi: 'तिब्बत टाइम्स (བོད་ཀྱི་དུས་བབ།)',
        url: 'https://www.tibettimes.net/',
        description: 'An independent Tibetan-language newspaper based in Dharamshala, India. Focuses on news related to Tibet and the Tibetan diaspora.',
        description_ti: 'རྒྱ་གར་རྡ་རམ་ས་ལར་རྟེན་གཞི་བྱས་པའི་རང་དབང་ཅན་གྱི་བོད་ཡིག་གསར་ཤོག བོད་དང་བཙན་བྱོལ་བོད་མི་དང་འབྲེལ་བའི་གསར་འགྱུར་ལ་དམིགས་པ་ཡིན།',
        description_hi: 'धर्मशाला, भारत में स्थित एक स्वतंत्र तिब्बती भाषा का समाचार पत्र। तिब्बत और तिब्बती प्रवासियों से संबंधित समाचारों पर ध्यान केंद्रित करता है।',
    },
    {
        name: 'Phayul.com',
        name_ti: 'ཕ་ཡུལ།',
        name_hi: 'फयुल.कॉम',
        url: 'https://www.phayul.com/',
        description: 'An English-language Tibetan news portal providing daily news and analysis on Tibet-related issues.',
        description_ti: 'བོད་དོན་དང་འབྲེལ་བའི་གནད་དོན་ཐོག་ཉིན་རེའི་གསར་འགྱུར་དང་དབྱེ་ཞིབ་མཁོ་སྤྲོད་བྱེད་པའི་དབྱིན་ཡིག་གི་བོད་ཀྱི་གསར་འགྱུར་དྲ་ཚིགས།',
        description_hi: 'तिब्बत से संबंधित मुद्दों पर दैनिक समाचार और विश्लेषण प्रदान करने वाला एक अंग्रेजी भाषा का तिब्बती समाचार पोर्टल।',
    }
];