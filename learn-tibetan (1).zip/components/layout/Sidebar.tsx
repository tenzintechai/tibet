import React from 'react';
import { NavLink } from 'react-router-dom';
import { translations } from '../../constants';
import { Language } from '../../types';

interface SidebarProps {
    isOpen: boolean;
    setOpen: (isOpen: boolean) => void;
    language: Language;
    setLanguage: (language: Language) => void;
    isBilingualMode: boolean;
    setBilingualMode: (isBilingual: boolean) => void;
}

const NavIcon: React.FC<{ path: string, children: React.ReactNode }> = ({ path, children }) => {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">{children}</svg>
    )
}

const sidebarItems = [
    { to: "/", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />, labelKey: 'home' },
    { to: "/history", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />, labelKey: 'history' },
    { to: "/culture", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />, labelKey: 'culture' },
    { to: "/religion", icon: <path d="M13.2,4.02A8,8,0,1,0,20,13.2a1,1,0,0,0-1-1H16.14a1,1,0,0,0-1,.76,4,4,0,1,1-4.9-4.9,1,1,0,0,0,.76-1V4.2a1,1,0,0,0-1-1Z" />, labelKey: 'religion' },
    { to: "/language", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.06 11.06l-6-6a2 2 0 010-2.83l6-6a2 2 0 012.83 0l6 6a2 2 0 010 2.83l-6 6a2 2 0 01-2.83 0z" />, labelKey: 'language' },
    { to: "/medicine", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-14v4m-2-2h4m6 10v4m-2-2h4M12 3v18" />, labelKey: 'medicine' },
    { to: "/news", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />, labelKey: 'news' },
    { to: "/government", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />, labelKey: 'government' },
    { to: "/kids", icon: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />, labelKey: 'kidsPlayroom' },
];

const LanguageButton: React.FC<{
    currentLanguage: Language;
    targetLanguage: Language;
    setLanguage: (language: Language) => void;
    isOpen: boolean;
    longName: string;
    shortName: string;
}> = ({ currentLanguage, targetLanguage, setLanguage, isOpen, longName, shortName }) => (
    <button
        onClick={() => setLanguage(targetLanguage)}
        className={`flex-1 p-1 text-sm font-semibold rounded-md transition-colors duration-200 ${
            currentLanguage === targetLanguage
                ? 'bg-white text-tibetan-blue shadow'
                : 'text-white hover:bg-white/10'
        }`}
        aria-pressed={currentLanguage === targetLanguage}
    >
        {isOpen ? longName : shortName}
    </button>
);


export const Sidebar: React.FC<SidebarProps> = ({ isOpen, setOpen, language, setLanguage, isBilingualMode, setBilingualMode }) => {
    const t = translations[language];

    const activeLinkStyle = {
        backgroundColor: '#A50104',
        color: '#FFFFFF',
    };

    return (
        <div className={`fixed top-0 left-0 h-full bg-tibetan-blue text-white flex flex-col transition-all duration-300 z-10 ${isOpen ? 'w-64' : 'w-16'}`}>
            <div className="flex items-center justify-between p-4 border-b border-white/20">
                {isOpen && <h1 className="text-xl font-bold text-tibetan-gold">Learn Tibetan</h1>}
                <button onClick={() => setOpen(!isOpen)} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                    <NavIcon path="">
                        {isOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
                    </NavIcon>
                </button>
            </div>
            <nav className="flex-1 mt-4 space-y-2 px-2">
                {sidebarItems.map(item => (
                     <NavLink
                        key={item.to}
                        to={item.to}
                        className="flex items-center p-2 rounded-md hover:bg-white/20 transition-colors"
                        style={({ isActive }) => isActive ? activeLinkStyle : {}}
                    >
                        <span className="shrink-0">{item.icon}</span>
                        {isOpen && <span className="ml-4 whitespace-nowrap">{t[item.labelKey as keyof typeof t]}</span>}
                    </NavLink>
                ))}
            </nav>
            <div className="p-2 border-t border-white/20">
                <div className="p-2">
                    <div className={`flex items-center ${isOpen ? 'justify-between' : 'justify-center'}`}>
                        {isOpen && <span className="text-sm font-semibold whitespace-nowrap">{t.bilingualMode}</span>}
                        <button
                            onClick={() => setBilingualMode(!isBilingualMode)}
                            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none ${
                                isBilingualMode ? 'bg-tibetan-red' : 'bg-gray-400'
                            }`}
                            aria-pressed={isBilingualMode}
                            aria-label="Toggle bilingual mode"
                        >
                            <span
                                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${
                                    isBilingualMode ? 'translate-x-6' : 'translate-x-1'
                                }`}
                            />
                        </button>
                    </div>
                </div>
                 <div className="grid grid-cols-3 gap-1 bg-black/20 rounded-md p-1">
                    <LanguageButton currentLanguage={language} targetLanguage={Language.EN} setLanguage={setLanguage} isOpen={isOpen} longName="English" shortName="EN" />
                    <LanguageButton currentLanguage={language} targetLanguage={Language.TI} setLanguage={setLanguage} isOpen={isOpen} longName="བོད་ཡིག" shortName="TI" />
                    <LanguageButton currentLanguage={language} targetLanguage={Language.HI} setLanguage={setLanguage} isOpen={isOpen} longName="हिन्दी" shortName="HI" />
                </div>
            </div>
        </div>
    );
};