import React, { useState } from 'react';
import { Language } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';
import { medicineTopicsData } from '../../data/content';
import { Button } from '../ui/Button';

interface MedicineViewProps {
    language: Language;
    isBilingualMode: boolean;
}

type ActiveView = 'medicine' | 'astrology';

const animalSigns = ['animal_rat', 'animal_ox', 'animal_tiger', 'animal_rabbit', 'animal_dragon', 'animal_snake', 'animal_horse', 'animal_sheep', 'animal_monkey', 'animal_rooster', 'animal_dog', 'animal_pig'];
const elements = ['element_iron', 'element_water', 'element_wood', 'element_fire', 'element_earth'];
const tibetanAnimals = ['བྱི་བ།', 'གླང་།', 'སྟག།', 'ཡོས།', 'འབྲུག།', 'སྦྲུལ།', 'རྟ།', 'ལུག།', 'སྤྲེའུ།', 'བྱ།', 'ཁྱི།', 'ཕག།'];
const tibetanElements = ['ལྕགས།', 'ཆུ།', 'ཤིང་།', 'མེ།', 'ས།'];


const AstrologyCalculator: React.FC<{ language: Language, isBilingualMode: boolean }> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const t_hi = translations[Language.HI];
    const [year, setYear] = useState('');
    const [result, setResult] = useState<{ animal: string, element: string, charKey: string, animal_ti: string, element_ti: string } | null>(null);

    const calculateZodiac = () => {
        const birthYear = parseInt(year, 10);
        if (isNaN(birthYear) || birthYear < 1900 || birthYear > 2099) {
            alert('Please enter a valid year between 1900 and 2099.');
            return;
        }

        const animalIndex = (birthYear - 1924) % 12;
        const correctedAnimalIndex = animalIndex < 0 ? animalIndex + 12 : animalIndex;
        
        const lastDigit = birthYear % 10;
        let elementIndex;
        if (lastDigit === 0 || lastDigit === 1) {
            elementIndex = 0; // Iron
        } else if (lastDigit === 2 || lastDigit === 3) {
            elementIndex = 1; // Water
        } else if (lastDigit === 4 || lastDigit === 5) {
            elementIndex = 2; // Wood
        } else if (lastDigit === 6 || lastDigit === 7) {
            elementIndex = 3; // Fire
        } else { // 8 or 9
            elementIndex = 4; // Earth
        }
        
        const animalKey = animalSigns[correctedAnimalIndex];
        const elementKey = elements[elementIndex];

        setResult({
            animal: t_en[animalKey as keyof typeof t_en],
            element: t_en[elementKey as keyof typeof t_en],
            charKey: `char_${animalKey.split('_')[1]}` as keyof typeof t,
            animal_ti: tibetanAnimals[correctedAnimalIndex],
            element_ti: tibetanElements[elementIndex]
        });
    };
    
    const allSignsTitles = {
        [Language.EN]: "The 12 Animal Signs",
        [Language.TI]: "ལོ་རྟགས་བཅུ་གཉིས།",
        [Language.HI]: "१२ पशु राशियाँ",
    };

    return (
        <Card>
            <h2 className="text-2xl font-bold text-tibetan-red">{t.zodiac_calculator_title}</h2>
            <p className="text-gray-600 mt-2 mb-4">{t.zodiac_calculator_desc}</p>
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <div className="w-full sm:w-auto">
                    <label htmlFor="birth-year" className="sr-only">{t.birth_year}</label>
                    <input
                        id="birth-year"
                        type="number"
                        value={year}
                        onChange={(e) => setYear(e.target.value)}
                        placeholder={t.birth_year as string}
                        className="p-2 border rounded-md w-full"
                    />
                </div>
                <Button onClick={calculateZodiac}>{t.calculate}</Button>
            </div>

            {result && (
                <Card className="mt-6 bg-parchment animate-fade-in">
                    <h3 className="text-xl font-bold text-tibetan-blue">{t.your_result}</h3>
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <p className="font-semibold">{t.animal_sign}:</p>
                             {isBilingualMode ? (
                                <>
                                    <p className="text-lg text-tibetan-red">{result.animal}</p>
                                    <p className="text-lg text-tibetan-red/80 font-serif">{result.animal_ti}</p>
                                </>
                            ) : (
                                <p className="text-lg text-tibetan-red">{language === Language.TI ? result.animal_ti : result.animal}</p>
                            )}
                        </div>
                        <div>
                            <p className="font-semibold">{t.element}:</p>
                             {isBilingualMode ? (
                                <>
                                    <p className="text-lg text-tibetan-red">{result.element}</p>
                                    <p className="text-lg text-tibetan-red/80 font-serif">{result.element_ti}</p>
                                </>
                            ) : (
                                <p className="text-lg text-tibetan-red">{language === Language.TI ? result.element_ti : result.element}</p>
                            )}
                        </div>
                    </div>
                     <div className="mt-4">
                        <p className="font-semibold">{t.characteristics}:</p>
                        {isBilingualMode ? (
                             <>
                                <p className="italic text-gray-700">{t_en[result.charKey as keyof typeof t_en]}</p>
                                <p className="italic text-gray-600 font-serif mt-1">{t_ti[result.charKey as keyof typeof t_ti]}</p>
                            </>
                        ) : (
                             <p className="italic text-gray-700">{t[result.charKey as keyof typeof t]}</p>
                        )}
                    </div>
                </Card>
            )}
            
            <div className="mt-8 pt-6 border-t border-gray-300">
                {isBilingualMode ? (
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-bold text-tibetan-blue">{allSignsTitles[Language.EN]}</h2>
                        <h3 className="text-2xl font-bold text-tibetan-blue/80 font-serif">{allSignsTitles[Language.TI]}</h3>
                    </div>
                ) : (
                    <h2 className="text-3xl font-bold text-tibetan-blue mb-6 text-center">{allSignsTitles[language]}</h2>
                )}

                <div className="space-y-6">
                    {animalSigns.map((signKey, index) => {
                        const charKey = `char_${signKey.split('_')[1]}` as keyof typeof t;
                        const animalNameEn = t_en[signKey as keyof typeof t_en];
                        const animalNameTi = tibetanAnimals[index];
                        const charEn = t_en[charKey as keyof typeof t_en];
                        const charTi = t_ti[charKey as keyof typeof t_ti];

                        const animalNameCurrentLang = t[signKey as keyof typeof t];
                        const charCurrentLang = t[charKey];

                        return (
                            <div key={signKey} className="border-t border-gray-200 pt-4 first:border-t-0 first:pt-0">
                                {isBilingualMode ? (
                                    <>
                                        <h3 className="text-xl font-semibold text-tibetan-red">{animalNameEn}</h3>
                                        <h4 className="text-lg font-semibold text-tibetan-red/80 font-serif">{animalNameTi}</h4>
                                        <p className="mt-2 text-gray-700">{charEn}</p>
                                        <p className="mt-1 text-gray-600 font-serif">{charTi}</p>
                                    </>
                                ) : (
                                    <>
                                        <h3 className="text-xl font-semibold text-tibetan-red">{animalNameCurrentLang}</h3>
                                        <p className="mt-2 text-gray-700">{charCurrentLang}</p>
                                    </>
                                )}
                            </div>
                        );
                    })}
                </div>
            </div>
        </Card>
    );
};

const MedicineContent: React.FC<{ language: Language, isBilingualMode: boolean }> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    
    return (
         <div className="space-y-8 animate-fade-in">
            <Card>
                <img src="https://picsum.photos/800/300?random=5" alt="Tibetan Herbs" className="w-full h-64 object-cover rounded-t-lg" />
                <div className="p-4">
                    {isBilingualMode ? (
                        <>
                            <h2 className="text-2xl font-bold text-tibetan-red">{t_en.medicine_intro_title}</h2>
                            <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.medicine_intro_title}</h3>
                            <p className="mt-2 text-lg text-gray-700">{t_en.medicine_intro_desc_1}</p>
                            <p className="mt-2 text-gray-600 font-serif">{t_ti.medicine_intro_desc_1}</p>
                            <p className="mt-4 text-gray-700">{t_en.medicine_intro_desc_2}</p>
                             <p className="mt-2 text-gray-600 font-serif">{t_ti.medicine_intro_desc_2}</p>
                            <p className="mt-4 text-gray-700">{t_en.medicine_intro_desc_3}</p>
                            <p className="mt-2 text-gray-600 font-serif">{t_ti.medicine_intro_desc_3}</p>
                        </>
                    ) : (
                        <>
                            <h2 className="text-2xl font-bold text-tibetan-red">{t.medicine_intro_title}</h2>
                            <p className="mt-2 text-lg text-gray-700">{t.medicine_intro_desc_1}</p>
                            <p className="mt-4 text-gray-700">{t.medicine_intro_desc_2}</p>
                            <p className="mt-4 text-gray-700">{t.medicine_intro_desc_3}</p>
                        </>
                    )}
                    <a href="https://www.men-tsee-khang.org/" target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline mt-4 inline-block font-semibold">
                        {t.visit_mentseekhang} &rarr;
                    </a>
                </div>
            </Card>

            <div>
                {isBilingualMode ? (
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-bold text-tibetan-blue">{t_en.core_concepts}</h2>
                        <h3 className="text-2xl font-bold text-tibetan-blue/80 font-serif">{t_ti.core_concepts}</h3>
                    </div>
                ) : (
                    <h2 className="text-3xl font-bold text-tibetan-blue mb-6 text-center">{t.core_concepts}</h2>
                )}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {medicineTopicsData.map((topic) => (
                        <Card key={topic.titleKey} className="flex flex-col">
                           <img src={topic.imageUrl} alt={t[topic.titleKey as keyof typeof t]} className="w-full h-48 object-cover rounded-t-lg" />
                           <div className="p-4 flex-1 flex flex-col">
                                {isBilingualMode ? (
                                    <>
                                        <h3 className="text-2xl font-bold text-tibetan-red">{t_en[topic.titleKey as keyof typeof t_en]}</h3>
                                        <h4 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti[topic.titleKey as keyof typeof t_ti]}</h4>
                                        <p className="mt-2 text-gray-700 whitespace-pre-line flex-1">{t_en[topic.contentKey as keyof typeof t_en]}</p>
                                        <p className="mt-1 text-gray-600 whitespace-pre-line font-serif flex-1">{t_ti[topic.contentKey as keyof typeof t_ti]}</p>
                                    </>
                                ) : (
                                    <>
                                        <h3 className="text-2xl font-bold text-tibetan-red">{t[topic.titleKey as keyof typeof t]}</h3>
                                        <p className="mt-2 text-gray-700 whitespace-pre-line flex-1">{t[topic.contentKey as keyof typeof t]}</p>
                                    </>
                                )}
                           </div>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
};

const AstrologyContent: React.FC<{ language: Language, isBilingualMode: boolean }> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    return (
        <div className="space-y-8 animate-fade-in">
            <Card>
                <img src="https://picsum.photos/800/300?random=10" alt="Tibetan Astrology Chart" className="w-full h-64 object-cover rounded-t-lg" />
                 <div className="p-4">
                    {isBilingualMode ? (
                        <>
                            <h2 className="text-2xl font-bold text-tibetan-red">{t_en.astrology_intro_title}</h2>
                            <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.astrology_intro_title}</h3>
                            <p className="mt-2 text-gray-700">{t_en.astrology_intro_desc}</p>
                            <p className="mt-2 text-gray-600 font-serif">{t_ti.astrology_intro_desc}</p>
                        </>
                    ) : (
                        <>
                           <h2 className="text-2xl font-bold text-tibetan-red">{t.astrology_intro_title}</h2>
                           <p className="mt-2 text-gray-700">{t.astrology_intro_desc}</p>
                        </>
                    )}
                 </div>
            </Card>
            <AstrologyCalculator language={language} isBilingualMode={isBilingualMode} />
        </div>
    );
};


export const MedicineView: React.FC<MedicineViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const [activeView, setActiveView] = useState<ActiveView>('medicine');

    return (
        <div className="space-y-8">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.medicine}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.medicine}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.medicine}</h1>
            )}
            
            <Card className="p-2">
                <div className="flex bg-gray-200 rounded-lg p-1 space-x-1">
                    <button onClick={() => setActiveView('medicine')} className={`flex-1 px-4 py-2 text-sm font-semibold rounded-md transition-colors ${activeView === 'medicine' ? 'bg-tibetan-red text-white' : 'text-gray-600 hover:bg-gray-300'}`}>
                        {t.medicine.split(' ')[0]}
                    </button>
                    <button onClick={() => setActiveView('astrology')} className={`flex-1 px-4 py-2 text-sm font-semibold rounded-md transition-colors ${activeView === 'astrology' ? 'bg-tibetan-red text-white' : 'text-gray-600 hover:bg-gray-300'}`}>
                        {t.astrology}
                    </button>
                </div>
            </Card>

            {activeView === 'medicine' ? 
                <MedicineContent language={language} isBilingualMode={isBilingualMode} /> : 
                <AstrologyContent language={language} isBilingualMode={isBilingualMode} />
            }
        </div>
    );
};