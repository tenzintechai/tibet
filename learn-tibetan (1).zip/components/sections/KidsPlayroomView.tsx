import React, { useState, useEffect, useCallback, useRef } from 'react';
import { FolkTale, Language, MathOperator, MathProblem, ShapeType } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { dalaiLamasData, kingsData } from '../../data/content';
import { folkTalesData } from '../../data/folktales';
import { QuizComponent } from '../features/QuizComponent';

type PlayroomView = 'menu' | 'quiz' | 'folktales' | 'memory_game' | 'math_games' | 'art_easel' | 'shape_explorer';
type QuizTopic = '5th_dalai_lama' | '14th_dalai_lama' | 'tibetan_kings';

interface KidsPlayroomProps {
    language: Language;
    isBilingualMode: boolean;
}

const getLocalizedFolkTale = (tale: FolkTale, field: 'title' | 'story' | 'moral', language: Language) => {
    switch (language) {
        case Language.TI: return tale[`${field}_ti`];
        case Language.HI: return tale[`${field}_hi`];
        default: return tale[field];
    }
};

const FolkTalesComponent: React.FC<{ language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ language, isBilingualMode, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const [openTaleId, setOpenTaleId] = useState<string | null>(null);

    const toggleTale = (id: string) => {
        setOpenTaleId(prevId => prevId === id ? null : id);
    };

    return (
        <Card>
            <button onClick={onBack} className="mb-4 text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
            {isBilingualMode ? (
                <>
                    <h2 className="text-2xl font-bold text-tibetan-red mb-2">{t_en.tibetanFolkTales}</h2>
                    <h3 className="text-xl font-bold text-tibetan-red/80 font-serif mb-4">{t_ti.tibetanFolkTales}</h3>
                </>
            ) : (
                <h2 className="text-2xl font-bold text-tibetan-red mb-4">{t.tibetanFolkTales}</h2>
            )}
            <div className="space-y-4">
                {folkTalesData.map(tale => (
                    <div key={tale.id} className="border rounded-lg overflow-hidden">
                        <button onClick={() => toggleTale(tale.id)} className="w-full text-left p-4 bg-gray-50 hover:bg-gray-100 focus:outline-none flex justify-between items-center">
                            {isBilingualMode ? (
                                <div>
                                    <h3 className="text-lg font-semibold text-tibetan-blue">{tale.title}</h3>
                                    <h4 className="text-md font-semibold text-tibetan-blue/80 font-serif">{tale.title_ti}</h4>
                                </div>
                            ) : (
                                <h3 className="text-lg font-semibold text-tibetan-blue">{getLocalizedFolkTale(tale, 'title', language)}</h3>
                            )}
                            <span className={`transform transition-transform duration-300 ${openTaleId === tale.id ? 'rotate-180' : ''}`}>
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                </svg>
                            </span>
                        </button>
                        {openTaleId === tale.id && (
                            <div className="p-4 bg-white animate-fade-in space-y-4">
                                {isBilingualMode ? (
                                    <div>
                                        <p className="text-gray-700 whitespace-pre-line">{tale.story}</p>
                                        <p className="text-gray-600 font-serif mt-2 whitespace-pre-line">{tale.story_ti}</p>
                                        <div className="mt-4 pt-2 border-t">
                                            <h4 className="font-semibold text-tibetan-blue">{t_en.moralOfTheStory}</h4>
                                            <p className="italic text-gray-700">{tale.moral}</p>
                                            <h4 className="font-semibold text-tibetan-blue/80 font-serif mt-2">{t_ti.moralOfTheStory}</h4>
                                            <p className="italic text-gray-600 font-serif">{tale.moral_ti}</p>
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <p className="text-gray-700 whitespace-pre-line">{getLocalizedFolkTale(tale, 'story', language)}</p>
                                        <div className="mt-4 pt-2 border-t">
                                            <h4 className="font-semibold text-tibetan-blue">{t.moralOfTheStory}</h4>
                                            <p className="italic text-gray-700">{getLocalizedFolkTale(tale, 'moral', language)}</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </Card>
    );
};

const QuizSelectionComponent: React.FC<{ language: Language; isBilingualMode: boolean; onStartQuiz: (topic: QuizTopic) => void; onBack: () => void; }> = ({ language, isBilingualMode, onStartQuiz, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    const quizzes: { topicKey: keyof typeof t; topicId: QuizTopic }[] = [
        { topicKey: 'quizOn5thDalaiLama', topicId: '5th_dalai_lama' },
        { topicKey: 'quizOn14thDalaiLama', topicId: '14th_dalai_lama' },
        { topicKey: 'quizOnTibetanKings', topicId: 'tibetan_kings' },
    ];

    return (
        <Card>
            <button onClick={onBack} className="mb-4 text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
            {isBilingualMode ? (
                 <>
                    <h2 className="text-2xl font-bold text-tibetan-red mb-2">{t_en.quizGames}</h2>
                    <h3 className="text-xl font-bold text-tibetan-red/80 font-serif mb-4">{t_ti.quizGames}</h3>
                </>
            ) : (
                <h2 className="text-2xl font-bold text-tibetan-red mb-4">{t.quizGames}</h2>
            )}
            <div className="space-y-3">
                {quizzes.map(quiz => (
                     <Button 
                        key={quiz.topicId} 
                        onClick={() => onStartQuiz(quiz.topicId)}
                        variant="secondary"
                        className="w-full text-left justify-start"
                    >
                        {isBilingualMode ? (
                            <>
                                {t_en[quiz.topicKey as keyof typeof t_en]}
                                <span className="block font-serif text-sm font-normal">{t_ti[quiz.topicKey as keyof typeof t_ti]}</span>
                            </>
                        ) : t[quiz.topicKey]}
                    </Button>
                ))}
            </div>
        </Card>
    );
};

const MemoryGameComponent: React.FC<{ language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ language, isBilingualMode, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const characters = ['ཀ', 'ཁ', 'ག', 'ང', 'ཅ', 'ཆ', 'ཇ', 'ཉ'];
    const [cards, setCards] = useState<({ char: string; id: number; isFlipped: boolean; isMatched: boolean; }[])>([]);
    const [flippedCards, setFlippedCards] = useState<number[]>([]);
    const [moves, setMoves] = useState(0);
    const [isGameWon, setIsGameWon] = useState(false);
    const [isChecking, setIsChecking] = useState(false);

    const initializeGame = useCallback(() => {
        const gameCards = [...characters, ...characters]
            .sort(() => Math.random() - 0.5)
            .map((char, index) => ({ char, id: index, isFlipped: false, isMatched: false }));
        setCards(gameCards);
        setFlippedCards([]);
        setMoves(0);
        setIsGameWon(false);
        setIsChecking(false);
    }, []);

    useEffect(() => {
        initializeGame();
    }, [initializeGame]);

    useEffect(() => {
        if (flippedCards.length === 2) {
            setIsChecking(true);
            const [firstId, secondId] = flippedCards;
            const firstCard = cards.find(c => c.id === firstId);
            const secondCard = cards.find(c => c.id === secondId);

            if (firstCard && secondCard && firstCard.char === secondCard.char) {
                setCards(prev => prev.map(card => card.char === firstCard.char ? { ...card, isMatched: true } : card));
                setFlippedCards([]);
                setIsChecking(false);
            } else {
                setTimeout(() => {
                    setCards(prev => prev.map(card => (card.id === firstId || card.id === secondId) ? { ...card, isFlipped: false } : card));
                    setFlippedCards([]);
                    setIsChecking(false);
                }, 1000);
            }
        }
    }, [flippedCards, cards]);

    useEffect(() => {
        if (cards.length > 0 && cards.every(c => c.isMatched)) {
            setIsGameWon(true);
        }
    }, [cards]);

    const handleCardClick = (id: number) => {
        const card = cards.find(c => c.id === id);
        if (isChecking || !card || card.isFlipped || card.isMatched) return;

        setCards(prev => prev.map(c => c.id === id ? { ...c, isFlipped: true } : c));
        setFlippedCards(prev => [...prev, id]);
        if (flippedCards.length === 0) {
            setMoves(m => m + 1);
        }
    };
    
    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                 <button onClick={onBack} className="text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
                 <div className="text-right">
                    {isBilingualMode ? (
                        <>
                            <h2 className="text-xl font-bold text-tibetan-red">{t_en.tibetanMemoryGame}</h2>
                            <h3 className="text-lg font-bold text-tibetan-red/80 font-serif">{t_ti.tibetanMemoryGame}</h3>
                        </>
                    ) : (
                        <h2 className="text-xl font-bold text-tibetan-red">{t.tibetanMemoryGame}</h2>
                    )}
                    <p className="font-semibold">{t.moves}: {moves}</p>
                 </div>
            </div>
             <div className="relative aspect-square max-w-md mx-auto">
                {isGameWon ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 sm:p-8 animate-fade-in bg-parchment/50 rounded-lg">
                        {isBilingualMode ? (
                            <>
                                <h3 className="text-2xl font-bold text-tibetan-blue">{t_en.congratulations}</h3>
                                <h4 className="text-xl font-bold text-tibetan-blue/80 font-serif">{t_ti.congratulations}</h4>
                            </>
                        ) : (
                            <h3 className="text-2xl font-bold text-tibetan-blue">{t.congratulations}</h3>
                        )}
                        <p>{t.game_complete_moves.replace('{moves}', moves.toString())}</p>
                        <Button onClick={initializeGame} className="mt-4">{t.playAgain}</Button>
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 sm:gap-4 h-full">
                        {cards.map(card => (
                            <div key={card.id} onClick={() => handleCardClick(card.id)} className="aspect-square [perspective:1000px] cursor-pointer group">
                                <div className={`relative w-full h-full transition-transform duration-500 [transform-style:preserve-3d] ${(card.isFlipped || card.isMatched) ? '[transform:rotateY(180deg)]' : ''}`}>
                                    {/* Front of card */}
                                    <div className="absolute w-full h-full bg-tibetan-blue rounded-lg [backface-visibility:hidden] flex items-center justify-center text-tibetan-gold text-2xl sm:text-4xl font-serif">
                                        ?
                                    </div>
                                    {/* Back of card */}
                                    <div className="absolute w-full h-full bg-white rounded-lg [transform:rotateY(180deg)] [backface-visibility:hidden] flex items-center justify-center text-xl sm:text-3xl font-serif text-tibetan-red border-2 border-tibetan-blue">
                                        {card.char}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </Card>
    );
};

const ArtEaselComponent: React.FC<{ language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ language, isBilingualMode, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const contextRef = useRef<CanvasRenderingContext2D | null>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [color, setColor] = useState('#000000');
    const colors = ['#A50104', '#003366', '#FFD700', '#F4B41A', '#000000', '#FFFFFF'];

    useEffect(() => {
        const canvas = canvasRef.current;
        if (canvas) {
            canvas.width = canvas.offsetWidth;
            canvas.height = canvas.offsetHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.lineCap = 'round';
                context.strokeStyle = color;
                context.lineWidth = 5;
                contextRef.current = context;
            }
        }
    }, []);

    useEffect(() => {
        if(contextRef.current) contextRef.current.strokeStyle = color;
    }, [color]);

    const startDrawing = ({ nativeEvent }: React.MouseEvent<HTMLCanvasElement>) => {
        const { offsetX, offsetY } = nativeEvent;
        contextRef.current?.beginPath();
        contextRef.current?.moveTo(offsetX, offsetY);
        setIsDrawing(true);
    };

    const stopDrawing = () => {
        contextRef.current?.closePath();
        setIsDrawing(false);
    };

    const draw = ({ nativeEvent }: React.MouseEvent<HTMLCanvasElement>) => {
        if (!isDrawing) return;
        const { offsetX, offsetY } = nativeEvent;
        contextRef.current?.lineTo(offsetX, offsetY);
        contextRef.current?.stroke();
    };

    const clearCanvas = () => {
        const canvas = canvasRef.current;
        if (canvas && contextRef.current) {
            contextRef.current.clearRect(0, 0, canvas.width, canvas.height);
        }
    };

    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <button onClick={onBack} className="text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
            </div>
            <div className="flex justify-center items-center gap-4 mb-4">
                 {isBilingualMode ? (
                    <div className="font-semibold text-center">
                        <p>{t_en.colors}:</p>
                        <p className="font-serif">{t_ti.colors}:</p>
                    </div>
                ) : (
                    <p className="font-semibold">{t.colors}:</p>
                )}
                {colors.map(c => (
                    <button key={c} style={{ backgroundColor: c }} onClick={() => setColor(c)} className={`w-8 h-8 rounded-full border-2 ${color === c ? 'border-black' : 'border-gray-300'}`}/>
                ))}
                 <Button onClick={clearCanvas} variant="secondary">{t.clear}</Button>
            </div>
            <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseUp={stopDrawing}
                onMouseMove={draw}
                onMouseLeave={stopDrawing}
                className="w-full h-96 bg-white border rounded-lg"
            />
        </Card>
    );
};

const ShapeExplorerComponent: React.FC<{ language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ language, isBilingualMode, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const shapes: { type: ShapeType, component: JSX.Element}[] = [
        { type: 'circle', component: <circle cx="50" cy="50" r="40" fill="#A50104" /> },
        { type: 'square', component: <rect x="10" y="10" width="80" height="80" fill="#003366" /> },
        { type: 'triangle', component: <polygon points="50,10 90,90 10,90" fill="#F4B41A" /> },
        { type: 'rectangle', component: <rect x="10" y="25" width="80" height="50" fill="#FFD700" /> },
    ];
    const [currentShape, setCurrentShape] = useState(shapes[0]);
    const [options, setOptions] = useState<ShapeType[]>([]);
    const [feedback, setFeedback] = useState('');

    const generateQuestion = useCallback(() => {
        const correctShape = shapes[Math.floor(Math.random() * shapes.length)];
        setCurrentShape(correctShape);
        
        const incorrectOptions = shapes.filter(s => s.type !== correctShape.type).map(s => s.type);
        const shuffledIncorrect = incorrectOptions.sort(() => 0.5 - Math.random()).slice(0, 2);
        
        const allOptions = [...shuffledIncorrect, correctShape.type].sort(() => 0.5 - Math.random());
        setOptions(allOptions);
        setFeedback('');
    }, []);

    useEffect(() => {
        generateQuestion();
    }, [generateQuestion]);

    const checkAnswer = (shape: ShapeType) => {
        if (shape === currentShape.type) {
            setFeedback(t.correct_exclamation);
            setTimeout(generateQuestion, 1000);
        } else {
            setFeedback(t.try_again);
        }
    };

    return (
        <Card>
            <button onClick={onBack} className="mb-4 text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
            <div className="text-center">
                 {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold mb-2">{t_en.what_shape_is_this}</h2>
                        <h3 className="text-xl font-bold font-serif text-gray-700 mb-4">{t_ti.what_shape_is_this}</h3>
                    </>
                ) : (
                    <h2 className="text-2xl font-bold mb-4">{t.what_shape_is_this}</h2>
                )}
                <svg viewBox="0 0 100 100" className="w-48 h-48 mx-auto mb-6">{currentShape.component}</svg>
                <div className="flex justify-center gap-4">
                    {options.map(opt => <Button key={opt} onClick={() => checkAnswer(opt)}>
                        {isBilingualMode ? (
                            <>
                                {t_en[opt as keyof typeof t_en]}
                                <span className="block font-serif font-normal text-sm">{t_ti[opt as keyof typeof t_ti]}</span>
                            </>
                        ) : t[opt]}
                        </Button>)}
                </div>
                {feedback && <p className={`mt-4 text-xl font-bold ${feedback === t.correct_exclamation ? 'text-green-600' : 'text-red-600'}`}>{feedback}</p>}
            </div>
        </Card>
    );
};

const tibetanNumerals = ['༠', '༡', '༢', '༣', '༤', '༥', '༦', '༧', '༨', '༩'];
const toTibetanNumeral = (n: number): string => {
    if (n < 0) return '-' + toTibetanNumeral(Math.abs(n));
    return n.toString().split('').map(digit => tibetanNumerals[parseInt(digit, 10)]).join('');
};
const gameConfig = {
    recognize: [{ maxNumber: 9, questions: 10 }],
    add: [{ opRange: 9, questions: 10 }],
    subtract: [{ opRange: 9, questions: 10 }],
    multiply: [{ opRange1: 5, opRange2: 5, questions: 10 }],
    divide: [{ maxDividend: 25, questions: 10 }]
};

const MathGamesComponent: React.FC<{ language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ language, isBilingualMode, onBack }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    type GameMode = 'menu' | 'learn' | 'recognize' | 'add' | 'subtract' | 'multiply' | 'divide';
    const [gameMode, setGameMode] = useState<GameMode>('menu');
    const [score, setScore] = useState(0);
    const [questionCount, setQuestionCount] = useState(0);
    const [currentQuestion, setCurrentQuestion] = useState<{ questionText: string; questionTextEn: string; options: number[]; correctAnswer: number; } | null>(null);
    const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
    const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);

    const generateQuestion = useCallback(() => {
        if (gameMode === 'menu' || gameMode === 'learn') return;
        let questionText = '', questionTextEn = '', correctAnswer = 0;
        const options: Set<number> = new Set();

        switch (gameMode) {
            case 'recognize':
                correctAnswer = Math.floor(Math.random() * 10);
                questionText = toTibetanNumeral(correctAnswer);
                questionTextEn = correctAnswer.toString();
                break;
            case 'add':
                const num1A = Math.floor(Math.random() * 10), num2A = Math.floor(Math.random() * 10);
                correctAnswer = num1A + num2A;
                questionText = `${toTibetanNumeral(num1A)} + ${toTibetanNumeral(num2A)}`;
                questionTextEn = `${num1A} + ${num2A}`;
                break;
            case 'subtract':
                const num1S = Math.floor(Math.random() * 10) + 5, num2S = Math.floor(Math.random() * (num1S + 1));
                correctAnswer = num1S - num2S;
                questionText = `${toTibetanNumeral(num1S)} - ${toTibetanNumeral(num2S)}`;
                questionTextEn = `${num1S} - ${num2S}`;
                break;
            case 'multiply':
                const num1M = Math.floor(Math.random() * 6), num2M = Math.floor(Math.random() * 6);
                correctAnswer = num1M * num2M;
                questionText = `${toTibetanNumeral(num1M)} × ${toTibetanNumeral(num2M)}`;
                questionTextEn = `${num1M} × ${num2M}`;
                break;
            case 'divide':
                const divisor = Math.floor(Math.random() * 4) + 2;
                const quotient = Math.floor(Math.random() * 5) + 1;
                const dividend = divisor * quotient;
                correctAnswer = quotient;
                questionText = `${toTibetanNumeral(dividend)} ÷ ${toTibetanNumeral(divisor)}`;
                questionTextEn = `${dividend} ÷ ${divisor}`;
                break;
        }

        options.add(correctAnswer);
        while (options.size < 4) options.add(Math.floor(Math.random() * (correctAnswer + 10)));
        
        setCurrentQuestion({ questionText, questionTextEn, options: Array.from(options).sort(() => Math.random() - 0.5), correctAnswer });
        setSelectedAnswer(null);
        setFeedback(null);
    }, [gameMode]);

    useEffect(() => {
        if (gameMode !== 'menu' && gameMode !== 'learn') generateQuestion();
    }, [gameMode, questionCount, generateQuestion]);

    const handleModeSelect = (mode: GameMode) => {
        setGameMode(mode);
        setScore(0);
        setQuestionCount(0);
    };

    const handleAnswer = (answer: number) => {
        if (feedback) return;
        setSelectedAnswer(answer);
        if (answer === currentQuestion?.correctAnswer) {
            setFeedback('correct');
            setScore(s => s + 1);
        } else {
            setFeedback('incorrect');
        }
    };

    const handleNext = () => {
        const totalQuestions = gameConfig[gameMode as keyof typeof gameConfig][0].questions;
        if (questionCount + 1 >= totalQuestions) {
            setCurrentQuestion(null);
        } else {
            setQuestionCount(c => c + 1);
        }
    };
    
    if (gameMode === 'menu') {
        return (
            <Card>
                <div className="flex justify-between items-center mb-4">
                    <button onClick={onBack} className="text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
                    <div className="text-right">
                        {isBilingualMode ? (
                            <>
                                <h2 className="text-xl font-bold text-tibetan-red">{t_en.mathGames}</h2>
                                <h3 className="text-lg font-bold text-tibetan-red/80 font-serif">{t_ti.mathGames}</h3>
                            </>
                        ) : (
                            <h2 className="text-xl font-bold text-tibetan-red">{t.mathGames}</h2>
                        )}
                    </div>
                </div>
                <div className="text-center mb-8">
                     <Button onClick={() => setGameMode('learn')} variant="secondary" className="w-full md:w-auto">{t.learnTheNumbers}</Button>
                </div>
                <div className="text-center">
                    <h3 className="text-lg font-semibold mb-4">{t.selectGameMode}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <Button onClick={() => handleModeSelect('recognize')}>{t.recognizeNumbers}</Button>
                        <Button onClick={() => handleModeSelect('add')}>{t.addition}</Button>
                        <Button onClick={() => handleModeSelect('subtract')}>{t.subtraction}</Button>
                        <Button onClick={() => handleModeSelect('multiply')}>{t.multiplication}</Button>
                        <Button onClick={() => handleModeSelect('divide')}>{t.division}</Button>
                    </div>
                </div>
            </Card>
        );
    }

     if (gameMode === 'learn') {
        return (
             <Card>
                 <div className="flex justify-between items-center mb-4">
                     <button onClick={() => setGameMode('menu')} className="text-tibetan-blue hover:underline">&larr; {t.selectGameMode}</button>
                 </div>
                 <div className="p-4 bg-tibetan-blue/5 rounded-lg">
                    <div className="mb-6">
                        <h3 className="text-lg font-semibold text-tibetan-blue text-center mb-3">{t.learnTheNumbers}</h3>
                        <div className="flex flex-wrap justify-center gap-2 text-center">
                            {Array.from({ length: 10 }, (_, i) => i).map(num => (
                                <div key={num} className="p-2 bg-white rounded-md shadow-sm w-16">
                                    <p className="text-3xl font-serif text-tibetan-red">{toTibetanNumeral(num)}</p>
                                    <p className="text-sm text-gray-600">{num}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-tibetan-blue text-center mb-3">{t.multiplicationFun}</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
                                <div key={num} className="p-3 bg-white rounded-md shadow-sm">
                                    <h4 className="font-bold text-center text-tibetan-red border-b pb-1 mb-2 font-serif">{toTibetanNumeral(num)}</h4>
                                    <div className="space-y-1 text-base text-gray-800">
                                        {Array.from({ length: 10 }, (_, j) => j + 1).map(multiplier => (
                                            isBilingualMode ? (
                                                <div key={multiplier} className="p-2 rounded-md even:bg-tibetan-saffron/20 odd:bg-transparent">
                                                    <p className="flex justify-between items-center font-serif text-tibetan-blue">
                                                        <span>{toTibetanNumeral(num)} × {toTibetanNumeral(multiplier)}</span>
                                                        <span className="text-lg font-bold text-tibetan-red">{toTibetanNumeral(num * multiplier)}</span>
                                                    </p>
                                                    <p className="flex justify-between items-center text-xs text-gray-500 font-sans -mt-1">
                                                        <span>{num} × {multiplier}</span>
                                                        <span className="font-semibold">{num * multiplier}</span>
                                                    </p>
                                                </div>
                                            ) : (
                                                <p key={multiplier} className="flex justify-between items-center font-serif p-2 rounded-md even:bg-tibetan-saffron/20 odd:bg-transparent text-tibetan-blue">
                                                    <span>{toTibetanNumeral(num)} × {toTibetanNumeral(multiplier)}</span>
                                                    <span className="text-lg font-bold text-tibetan-red">{toTibetanNumeral(num * multiplier)}</span>
                                                </p>
                                            )
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                 </div>
            </Card>
        );
    }
    
    if (!currentQuestion) {
        return (
            <Card className="text-center">
                 {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red mb-2">{t_en.congratulations}</h2>
                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif mb-4">{t_ti.congratulations}</h3>
                    </>
                ) : (
                    <h2 className="text-2xl font-bold text-tibetan-red mb-4">{t.congratulations}</h2>
                )}
                <p className="text-lg">{t.score}: {score}</p>
                <div className="mt-6 flex justify-center gap-4">
                    <Button onClick={() => setGameMode('menu')}>{t.playAgain}</Button>
                    <Button onClick={onBack} variant="secondary">{t.backToGames}</Button>
                </div>
            </Card>
        );
    }

    return (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <button onClick={() => setGameMode('menu')} className="text-tibetan-blue hover:underline">&larr; {t.backToGames}</button>
                <p className="font-semibold">{t.score}: {score}</p>
            </div>
            <div className="text-center">
                 {isBilingualMode ? (
                    <>
                        <p className="text-lg mb-1">{t_en[gameMode === 'recognize' ? 'what_number_is_this' : 'what_is_the_answer']}</p>
                        <p className="text-lg font-serif text-gray-600 mb-4">{t_ti[gameMode === 'recognize' ? 'what_number_is_this' : 'what_is_the_answer']}</p>
                        <p className="text-6xl font-serif mb-2">{currentQuestion.questionText}</p>
                        <p className="text-4xl text-gray-600 mb-6">{gameMode !== 'recognize' ? currentQuestion.questionTextEn : ' '}</p>
                    </>
                ) : (
                     <>
                        <p className="text-lg mb-4">{t[gameMode === 'recognize' ? 'what_number_is_this' : 'what_is_the_answer']}</p>
                        <p className="text-6xl font-serif mb-6">{currentQuestion.questionText}</p>
                    </>
                )}

                <div className="grid grid-cols-2 gap-4">
                    {currentQuestion.options.map(option => {
                         const isCorrect = option === currentQuestion.correctAnswer, isSelected = option === selectedAnswer;
                         let btnClass = "p-2 rounded-lg border-2 transition-colors ";
                         if (feedback) btnClass += isCorrect ? "bg-green-200 border-green-400" : (isSelected ? "bg-red-200 border-red-400" : "bg-white border-gray-300");
                         else btnClass += "bg-white border-gray-300 hover:bg-gray-100 cursor-pointer";
                         return <button key={option} onClick={() => handleAnswer(option)} disabled={!!feedback} className={btnClass}>
                            {isBilingualMode ? (
                                <div className="text-center leading-tight">
                                    <span className="block text-3xl font-serif">{toTibetanNumeral(option)}</span>
                                    <span className="block text-xl">{option}</span>
                                </div>
                            ) : (
                                <span className="text-3xl font-serif">{toTibetanNumeral(option)}</span>
                            )}
                         </button>
                    })}
                </div>
                {feedback && (
                    <div className="mt-4">
                        <div className={`font-bold text-xl ${feedback === 'correct' ? 'text-green-600' : 'text-red-600'}`}>
                            {isBilingualMode ? (
                                <>
                                    <p>{feedback === 'correct' ? t_en.correct_exclamation : `${t_en.incorrect} ${currentQuestion.correctAnswer}`}</p>
                                    <p className="font-serif mt-1">{feedback === 'correct' ? t_ti.correct_exclamation : `${t_ti.incorrect} ${toTibetanNumeral(currentQuestion.correctAnswer)}`}</p>
                                </>
                            ) : (
                                <p>{feedback === 'correct' ? t.correct_exclamation : `${t.incorrect} ${toTibetanNumeral(currentQuestion.correctAnswer)}`}</p>
                            )}
                        </div>
                        <Button onClick={handleNext} className="mt-4">{t.nextQuestion}</Button>
                    </div>
                )}
            </div>
        </Card>
    );
};

export const KidsPlayroomView: React.FC<KidsPlayroomProps> = ({ language, isBilingualMode }) => {
    const [activeView, setActiveView] = useState<PlayroomView>('menu');
    const [quizConfig, setQuizConfig] = useState<{ topic: string, content: string } | null>(null);
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    const handleStartQuiz = (topic: QuizTopic) => {
        let quizContent = '', quizTopic = '';
        if (topic === '5th_dalai_lama') {
            quizTopic = t.quizOn5thDalaiLama;
            quizContent = JSON.stringify(dalaiLamasData.find(d => d.id === 5));
        } else if (topic === '14th_dalai_lama') {
            quizTopic = t.quizOn14thDalaiLama;
            quizContent = JSON.stringify(dalaiLamasData.find(d => d.id === 14));
        } else if (topic === 'tibetan_kings') {
            quizTopic = t.quizOnTibetanKings;
            quizContent = JSON.stringify(kingsData.filter(k => k.id >= 33));
        }
        setQuizConfig({ topic: quizTopic, content: quizContent });
        setActiveView('quiz');
    };

    const games = [
        { id: 'quiz', titleKey: 'quizGames', descKey: 'quizGamesDesc' },
        { id: 'folktales', titleKey: 'readStories', descKey: 'folkTales_desc' },
        { id: 'memory_game', titleKey: 'tibetanMemoryGame', descKey: 'tibetanMemoryGame_desc' },
        { id: 'math_games', titleKey: 'mathGames', descKey: 'mathGames_desc' },
        { id: 'art_easel', titleKey: 'artEasel', descKey: 'artEasel_desc' },
        { id: 'shape_explorer', titleKey: 'shapeExplorer', descKey: 'shapeExplorer_desc' },
    ];

    const renderContent = () => {
        switch (activeView) {
            case 'quiz':
                return quizConfig ? <QuizComponent topic={quizConfig.topic} content={quizConfig.content} language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} /> : <QuizSelectionComponent language={language} isBilingualMode={isBilingualMode} onStartQuiz={handleStartQuiz} onBack={() => setActiveView('menu')} />;
            case 'folktales':
                return <FolkTalesComponent language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} />;
            case 'memory_game':
                return <MemoryGameComponent language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} />;
            case 'math_games':
                return <MathGamesComponent language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} />;
            case 'art_easel':
                return <ArtEaselComponent language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} />;
            case 'shape_explorer':
                return <ShapeExplorerComponent language={language} isBilingualMode={isBilingualMode} onBack={() => setActiveView('menu')} />;
            case 'menu':
            default:
                return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {games.map(game => (
                            <Card key={game.id} className="text-center transform hover:-translate-y-1 hover:scale-105 duration-300 cursor-pointer" onClick={() => setActiveView(game.id as PlayroomView)}>
                               {isBilingualMode ? (
                                    <>
                                        <h3 className="text-xl font-semibold text-tibetan-red">{t_en[game.titleKey as keyof typeof t_en]}</h3>
                                        <h4 className="text-lg font-semibold text-tibetan-red/80 font-serif">{t_ti[game.titleKey as keyof typeof t_ti]}</h4>
                                        <p className="mt-2 text-gray-600">{t_en[game.descKey as keyof typeof t_en]}</p>
                                        <p className="mt-1 text-gray-500 font-serif">{t_ti[game.descKey as keyof typeof t_ti]}</p>
                                    </>
                                ) : (
                                    <>
                                        <h3 className="text-xl font-semibold text-tibetan-red">{t[game.titleKey as keyof typeof t]}</h3>
                                        <p className="mt-2 text-gray-600">{t[game.descKey as keyof typeof t]}</p>
                                    </>
                                )}
                            </Card>
                        ))}
                    </div>
                );
        }
    };
    
    return (
        <div className="space-y-6">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.kidsPlayroom}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.kidsPlayroom}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.kidsPlayroom}</h1>
            )}
            <div className="animate-fade-in">{renderContent()}</div>
        </div>
    );
};