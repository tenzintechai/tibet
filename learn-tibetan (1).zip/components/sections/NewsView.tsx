import React from 'react';
import { Language, MediaOutlet } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';
import { mediaOutlets } from '../../data/news';

interface NewsViewProps {
    language: Language;
    isBilingualMode: boolean;
}

const getLocalizedContent = (item: MediaOutlet, field: keyof MediaOutlet, language: Language) => {
    switch (language) {
        case Language.TI: return item[`${field}_ti` as keyof MediaOutlet] || item[field];
        case Language.HI: return item[`${field}_hi` as keyof MediaOutlet] || item[field];
        default: return item[field];
    }
};

export const NewsView: React.FC<NewsViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    return (
        <div className="space-y-6">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.news}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.news}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.news}</h1>
            )}
            <div className="space-y-4">
                {mediaOutlets.map(outlet => (
                    <Card key={outlet.name}>
                        {isBilingualMode ? (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{outlet.name}</h2>
                                <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{outlet.name_ti}</h3>
                                <p className="mt-2 text-gray-700">{outlet.description}</p>
                                <p className="mt-1 text-gray-600 font-serif">{outlet.description_ti}</p>
                            </>
                        ) : (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{getLocalizedContent(outlet, 'name', language)}</h2>
                                <p className="mt-2 text-gray-700">{getLocalizedContent(outlet, 'description', language)}</p>
                            </>
                        )}
                        
                        {outlet.warning && (
                            <div className="mt-3 p-3 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800">
                                {isBilingualMode ? (
                                    <>
                                        <p><span className="font-bold">⚠️ Notice:</span> {outlet.warning}</p>
                                        <p className="font-serif"><span className="font-bold">⚠️ བརྡ་ཁྱབ།:</span> {outlet.warning_ti}</p>
                                    </>
                                ) : (
                                    <p><span className="font-bold">⚠️ {language === Language.TI ? 'བརྡ་ཁྱབ།' : 'Notice'}:</span> {getLocalizedContent(outlet, 'warning', language)}</p>
                                )}
                            </div>
                        )}
                        <a href={outlet.url} target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline mt-4 inline-block font-semibold">
                            {t.visitWebsite} &rarr;
                        </a>
                    </Card>
                ))}
            </div>
        </div>
    );
};