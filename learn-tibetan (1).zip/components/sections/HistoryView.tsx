import React, { useState } from 'react';
import { King, Language, HistoricalPeriod, DynasticRuler, PanchenLama } from '../../types';
import { translations } from '../../constants';
import { kingsData, dalaiLamasData, sinoTibetanRelationsData, fragmentationEraData, preImperialData, sakyaRulersData, phagmodrupaRulersData, rinpungpaRulersData, tsangpaDynastyRulersData, panchenLamasData } from '../../data/content';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { QuizComponent } from '../features/QuizComponent';

interface HistoryViewProps {
    language: Language;
    isBilingualMode: boolean;
}

type HistorySection = 'empire' | 'fragmentation' | 'sakya' | 'central_dynasties' | 'dalai-lamas';

const getKingContent = (king: King, field: keyof King, language: Language) => {
    switch (language) {
        case Language.TI: return king[`${field}_ti` as keyof King] || king[field];
        case Language.HI: return king[`${field}_hi` as keyof King] || king[field];
        default: return king[field];
    }
};

const getPeriodContent = (period: HistoricalPeriod, field: keyof HistoricalPeriod, language: Language) => {
    switch (language) {
        case Language.TI: return period[`${field}_ti` as keyof HistoricalPeriod] || period[field];
        case Language.HI: return period[`${field}_hi` as keyof HistoricalPeriod] || period[field];
        default: return period[field];
    }
};

const getRulerContent = (ruler: DynasticRuler, field: keyof DynasticRuler, language: Language) => {
    switch (language) {
        case Language.TI: return ruler[`${field}_ti` as keyof DynasticRuler] || ruler[field];
        case Language.HI: return ruler[`${field}_hi` as keyof DynasticRuler] || ruler[field];
        default: return ruler[field];
    }
};

const getPanchenLamaContent = (lama: PanchenLama, field: keyof PanchenLama, language: Language) => {
     switch (language) {
        case Language.TI: return lama[`${field}_ti` as keyof PanchenLama] || lama[field];
        case Language.HI: return lama[`${field}_hi` as keyof PanchenLama] || lama[field];
        default: return lama[field];
    }
};

const TimelineNav: React.FC<{
    sections: { id: HistorySection; label: string; description: string }[];
    activeSection: HistorySection;
    onSelect: (section: HistorySection) => void;
}> = ({ sections, activeSection, onSelect }) => {
    return (
        <div className="w-full overflow-x-auto pb-4">
            <div className="relative min-w-[640px] md:min-w-0 pt-8">
                <div className="absolute top-9 left-0 w-full h-1 bg-tibetan-blue/50 rounded-full" aria-hidden="true"></div>
                <div 
                    className="absolute top-9 left-0 h-1 bg-tibetan-red rounded-full transition-all duration-500 ease-in-out"
                    style={{ 
                        width: `calc(${sections.findIndex(s => s.id === activeSection)} * (100% / ${sections.length - 1}))`,
                    }}
                    aria-hidden="true"
                ></div>
                <div className="relative flex justify-between items-start">
                    {sections.map((section) => (
                        <div key={section.id} className="z-10 flex-1 flex flex-col items-center text-center px-2">
                            <button
                                onClick={() => onSelect(section.id)}
                                className={`w-5 h-5 rounded-full border-2 flex-shrink-0 transition-all duration-300 ${
                                    activeSection === section.id
                                        ? 'bg-tibetan-red border-white ring-2 ring-tibetan-red scale-125'
                                        : 'bg-parchment border-tibetan-blue hover:bg-tibetan-saffron'
                                }`}
                                aria-current={activeSection === section.id ? 'step' : undefined}
                                title={section.label}
                            />
                            <div className="mt-4">
                                <span className={`block text-xs sm:text-sm font-semibold transition-colors duration-300 ${
                                    activeSection === section.id ? 'text-tibetan-red' : 'text-tibetan-blue'
                                }`}>{section.label}</span>
                                <p className={`text-[11px] text-gray-600 mt-1`}>
                                    {section.description}
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export const HistoryView: React.FC<HistoryViewProps> = ({ language, isBilingualMode }) => {
    const [activeView, setActiveView] = useState<HistorySection>('empire');
    const [quizConfig, setQuizConfig] = useState<{ topic: string; content: string; } | null>(null);
    
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    const handleStartQuiz = () => {
        if (activeView === 'empire') {
            setQuizConfig({
                topic: t.tibetanEmpire,
                content: JSON.stringify(kingsData.map(king => ({
                    name: getKingContent(king, 'name', language),
                    achievements: getKingContent(king, 'achievements', language),
                })))
            });
        } else if (activeView === 'dalai-lamas') {
            setQuizConfig({
                topic: t.dalaiLamas,
                content: JSON.stringify(dalaiLamasData.map(dl => ({
                    name: language === Language.TI ? dl.name_ti : dl.name,
                    bio: language === Language.TI ? dl.bio_ti : dl.bio,
                })))
            });
        }
    };

    if (quizConfig) {
        return (
            <Card>
                <button onClick={() => setQuizConfig(null)} className="mb-4 text-tibetan-blue hover:underline">&larr; {t.backToHistory}</button>
                <h2 className="text-2xl font-bold text-tibetan-red mb-4">{t.quizOnTopic.replace('{topic}', quizConfig.topic)}</h2>
                <QuizComponent 
                    topic={quizConfig.topic} 
                    content={quizConfig.content} 
                    language={language} 
                    // FIX: Pass the isBilingualMode prop to the QuizComponent.
                    isBilingualMode={isBilingualMode}
                    onBack={() => setQuizConfig(null)} 
                />
            </Card>
        );
    }

    const TIMELINE_SECTIONS: { id: HistorySection; labelKey: keyof typeof t; descriptionKey: keyof typeof t }[] = [
        { id: 'empire', labelKey: 'tibetanEmpire', descriptionKey: 'tibetanEmpireDesc' },
        { id: 'fragmentation', labelKey: 'eraOfFragmentation', descriptionKey: 'eraOfFragmentationDesc' },
        { id: 'sakya', labelKey: 'sakyaPeriod', descriptionKey: 'sakyaPeriodDesc' },
        { id: 'central_dynasties', labelKey: 'centralDynasties', descriptionKey: 'centralDynastiesDesc' },
        { id: 'dalai-lamas', labelKey: 'dalaiLamas', descriptionKey: 'dalaiLamasDesc' },
    ];
    
    return (
        <div className="space-y-6">
             {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.history}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.history}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.history}</h1>
            )}

            <div className="border-b border-gray-300 pb-2">
                <TimelineNav
                    sections={TIMELINE_SECTIONS.map(s => ({
                        id: s.id,
                        label: t[s.labelKey],
                        description: t[s.descriptionKey]
                    }))}
                    activeSection={activeView}
                    onSelect={setActiveView}
                />
            </div>

            <div className="text-center pt-2">
                {(activeView === 'empire' || activeView === 'dalai-lamas') && (
                    <Button onClick={handleStartQuiz}>{t.startQuiz}</Button>
                )}
            </div>

            <div className="space-y-4 animate-fade-in">
                {activeView === 'empire' && (
                    <>
                        {preImperialData.map(item => (
                            <Card key={item.titleKey}>
                                {isBilingualMode ? (
                                     <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{t_en[item.titleKey as keyof typeof t_en]}</h2>
                                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti[item.titleKey as keyof typeof t_ti]}</h3>
                                        <p className="mt-2 text-gray-700">{t_en[item.contentKey as keyof typeof t_en]}</p>
                                        <p className="mt-1 text-gray-600 font-serif">{t_ti[item.contentKey as keyof typeof t_ti]}</p>
                                    </>
                                ) : (
                                    <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{t[item.titleKey as keyof typeof t]}</h2>
                                        <p className="mt-2 text-gray-700">{t[item.contentKey as keyof typeof t]}</p>
                                    </>
                                )}
                            </Card>
                        ))}
                        {kingsData.map(king => (
                            <Card key={king.id}>
                                {isBilingualMode ? (
                                    <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{king.id}. {king.name} <span className="text-lg font-normal text-gray-600">({king.reign})</span></h2>
                                        <h3 className="text-xl font-semibold text-gray-700 font-serif">{king.name_ti}</h3>
                                        
                                        <p className="mt-4 text-gray-700 leading-relaxed">{king.bio}</p>
                                        <p className="mt-2 text-gray-600 font-serif leading-relaxed">{king.bio_ti}</p>

                                        <p className="mt-4 font-semibold text-tibetan-blue">{t_en.culturalInfluence}:</p>
                                        <p className="italic text-gray-700">"{king.cultural_influence}"</p>
                                        <p className="italic text-gray-600 font-serif mt-1">"{king.cultural_influence_ti}"</p>
                                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <h3 className="font-semibold text-tibetan-blue">{t_en.achievements}:</h3>
                                                <ul className="list-disc list-inside text-gray-600 space-y-2">
                                                    {king.achievements.map((a, i) => <li key={i}>{a}<p className="text-gray-500 font-serif ml-4">{king.achievements_ti[i]}</p></li>)}
                                                </ul>
                                            </div>
                                            <div>
                                                <h3 className="font-semibold text-tibetan-blue">{t_en.challenges}:</h3>
                                                <ul className="list-disc list-inside text-gray-600 space-y-2">
                                                     {king.challenges.map((c, i) => <li key={i}>{c}<p className="text-gray-500 font-serif ml-4">{king.challenges_ti[i]}</p></li>)}
                                                </ul>
                                            </div>
                                        </div>
                                    </>
                                ) : (
                                     <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{king.id}. {getKingContent(king, 'name', language)} <span className="text-lg font-normal text-gray-600">({king.reign})</span></h2>
                                        {language === Language.TI && <h3 className="text-xl font-semibold text-gray-700">{king.tibetan_name}</h3>}

                                        <p className="mt-4 text-gray-700 leading-relaxed">{getKingContent(king, 'bio', language)}</p>

                                        <p className="mt-4 font-semibold text-tibetan-blue">{t.culturalInfluence}:</p>
                                        <p className="italic text-gray-700">"{getKingContent(king, 'cultural_influence', language)}"</p>
                                        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <h3 className="font-semibold text-tibetan-blue">{t.achievements}:</h3>
                                                <ul className="list-disc list-inside text-gray-600">
                                                    {(getKingContent(king, 'achievements', language) as string[]).map((a, i) => <li key={i}>{a}</li>)}
                                                </ul>
                                            </div>
                                            <div>
                                                <h3 className="font-semibold text-tibetan-blue">{t.challenges}:</h3>
                                                <ul className="list-disc list-inside text-gray-600">
                                                    {(getKingContent(king, 'challenges', language) as string[]).map((c, i) => <li key={i}>{c}</li>)}
                                                </ul>
                                            </div>
                                        </div>
                                    </>
                                )}
                            </Card>
                        ))}
                    </>
                )}

                {activeView === 'fragmentation' && fragmentationEraData.map(period => (
                     <Card key={period.id}>
                        {isBilingualMode ? (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{period.period}</h2>
                                <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{period.period_ti}</h3>
                                <p className="mt-2 text-gray-700">{period.summary}</p>
                                <p className="mt-1 text-gray-600 font-serif">{period.summary_ti}</p>
                                <div className="mt-4">
                                    <h3 className="font-semibold text-tibetan-blue">{t_en.keyEvents}:</h3>
                                    <ul className="list-disc list-inside text-gray-600 space-y-2 mt-1">
                                        {period.key_events.map((e, i) => <li key={i}>{e}<p className="text-gray-500 font-serif ml-4">{period.key_events_ti[i]}</p></li>)}
                                    </ul>
                                </div>
                            </>
                        ) : (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{getPeriodContent(period, 'period', language)}</h2>
                                <p className="mt-2 text-gray-700">{getPeriodContent(period, 'summary', language)}</p>
                                 <div className="mt-4">
                                    <h3 className="font-semibold text-tibetan-blue">{t.keyEvents}:</h3>
                                    <ul className="list-disc list-inside text-gray-600">
                                        {(getPeriodContent(period, 'key_events', language) as string[]).map((e, i) => <li key={i}>{e}</li>)}
                                    </ul>
                                </div>
                            </>
                        )}
                    </Card>
                ))}
                
                {activeView === 'sakya' && sakyaRulersData.map(ruler => (
                    <Card key={ruler.id}>
                        <h2 className="text-2xl font-bold text-tibetan-red">{getRulerContent(ruler, 'name', language)}</h2>
                        <p className="text-lg text-gray-600">{ruler.reign}</p>
                        <p className="mt-2 text-gray-700">{getRulerContent(ruler, 'bio', language)}</p>
                        {ruler.notes && (
                            <p className="mt-2 text-sm italic text-gray-500">{t.notes}: {getRulerContent(ruler, 'notes', language)}</p>
                        )}
                    </Card>
                ))}

                {activeView === 'central_dynasties' && (
                    <div className="space-y-6">
                        <div>
                            <h2 className="text-3xl font-bold text-tibetan-blue border-b pb-2 mb-4">{t.phagmodrupaDynasty}</h2>
                            {phagmodrupaRulersData.map(ruler => (
                                <Card key={ruler.id} className="mb-4">
                                    <h3 className="text-2xl font-bold text-tibetan-red">{getRulerContent(ruler, 'name', language)}</h3>
                                    <p className="text-lg text-gray-600">{ruler.reign}</p>
                                    <p className="mt-2 text-gray-700">{getRulerContent(ruler, 'bio', language)}</p>
                                    {ruler.notes && <p className="mt-2 text-sm italic text-gray-500">{t.notes}: {getRulerContent(ruler, 'notes', language)}</p>}
                                </Card>
                            ))}
                        </div>
                         <div>
                            <h2 className="text-3xl font-bold text-tibetan-blue border-b pb-2 mb-4">{t.rinpungpaDynasty}</h2>
                            {rinpungpaRulersData.map(ruler => (
                                <Card key={ruler.id} className="mb-4">
                                    <h3 className="text-2xl font-bold text-tibetan-red">{getRulerContent(ruler, 'name', language)}</h3>
                                    <p className="text-lg text-gray-600">{ruler.reign}</p>
                                    <p className="mt-2 text-gray-700">{getRulerContent(ruler, 'bio', language)}</p>
                                </Card>
                            ))}
                        </div>
                        <div>
                            <h2 className="text-3xl font-bold text-tibetan-blue border-b pb-2 mb-4">{t.tsangpaDynasty}</h2>
                            {tsangpaDynastyRulersData.map(ruler => (
                                 <Card key={ruler.id} className="mb-4">
                                    <h3 className="text-2xl font-bold text-tibetan-red">{getRulerContent(ruler, 'name', language)}</h3>
                                    <p className="text-lg text-gray-600">{ruler.reign}</p>
                                    <p className="mt-2 text-gray-700">{getRulerContent(ruler, 'bio', language)}</p>
                                </Card>
                            ))}
                        </div>
                    </div>
                )}


                {activeView === 'dalai-lamas' && (
                    <div className="space-y-4">
                        {dalaiLamasData.map(dl => (
                             <Card key={dl.id} className="p-0 overflow-hidden">
                                <img src={dl.imageUrl} alt={language === Language.TI ? dl.name_ti : dl.name} className="w-full h-64 object-cover" />
                                <div className="p-4">
                                    {isBilingualMode ? (
                                        <>
                                            <h2 className="text-2xl font-bold text-tibetan-red">{dl.id}. {dl.name}</h2>
                                            <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{dl.name_ti}</h3>
                                            <p className="text-lg text-gray-600">{dl.reign}</p>
                                            <p className="mt-2 text-gray-700">{dl.bio}</p>
                                            <p className="mt-1 text-gray-600 font-serif">{dl.bio_ti}</p>
                                            <p className="mt-4 font-semibold text-tibetan-blue">{t_en.teachingsSummary}:</p>
                                            <p className="italic text-gray-700">"{dl.teachings_summary}"</p>
                                            <p className="mt-1 font-semibold text-tibetan-blue/80 font-serif">{t_ti.teachingsSummary}:</p>
                                            <p className="italic text-gray-600 font-serif">"{dl.teachings_summary_ti}"</p>
                                        </>
                                    ) : (
                                        <>
                                            <h2 className="text-2xl font-bold text-tibetan-red">{dl.id}. {language === Language.TI ? dl.name_ti : dl.name}</h2>
                                            {language === Language.TI && <h3 className="text-xl font-semibold text-gray-700">{dl.tibetan_name}</h3>}
                                            <p className="text-lg text-gray-600">{dl.reign}</p>
                                            <p className="mt-2 text-gray-700">{language === Language.TI ? dl.bio_ti : dl.bio}</p>
                                            <p className="mt-4 font-semibold text-tibetan-blue">{t.teachingsSummary}:</p>
                                            <p className="italic text-gray-700">"{language === Language.TI ? dl.teachings_summary_ti : dl.teachings_summary}"</p>
                                        </>
                                    )}
                                </div>
                            </Card>
                        ))}

                        <div className="mt-8 pt-6 border-t-2 border-dashed border-tibetan-blue">
                             <div className="text-center mb-6">
                                {isBilingualMode ? (
                                    <>
                                        <h2 className="text-3xl font-bold text-tibetan-blue">{t_en.panchenLamas}</h2>
                                        <h3 className="text-2xl font-bold text-tibetan-blue/80 font-serif">{t_ti.panchenLamas}</h3>
                                    </>
                                ) : (
                                    <h2 className="text-3xl font-bold text-tibetan-blue">{t.panchenLamas}</h2>
                                )}
                            </div>
                            <div className="space-y-4">
                                {panchenLamasData.map(lama => (
                                    <Card key={lama.id}>
                                        {isBilingualMode ? (
                                            <>
                                                <h2 className="text-2xl font-bold text-tibetan-red">{lama.id}. {lama.name}</h2>
                                                <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{lama.name_ti}</h3>
                                                <p className="text-lg text-gray-600">{lama.lifespan}</p>
                                                <p className="mt-2 text-gray-700">{lama.bio}</p>
                                                <p className="mt-1 text-gray-600 font-serif">{lama.bio_ti}</p>
                                            </>
                                        ) : (
                                            <>
                                                <h2 className="text-2xl font-bold text-tibetan-red">{lama.id}. {getPanchenLamaContent(lama, 'name', language)}</h2>
                                                {language === Language.TI && <h3 className="text-xl font-semibold text-gray-700">{lama.tibetan_name}</h3>}
                                                <p className="text-lg text-gray-600">{lama.lifespan}</p>
                                                <p className="mt-2 text-gray-700">{getPanchenLamaContent(lama, 'bio', language)}</p>
                                            </>
                                        )}
                                    </Card>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};