import React, { useState } from 'react';
import { Department, Language } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';
import { departmentsData } from '../../data/government';

interface GovernmentViewProps {
    language: Language;
    isBilingualMode: boolean;
}

const getLocalizedDuties = (dept: Department, language: Language): string[] => {
    switch (language) {
        case Language.TI: return dept.duties_ti;
        case Language.HI: return dept.duties_hi;
        default: return dept.duties;
    }
}

export const GovernmentView: React.FC<GovernmentViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const [expandedDept, setExpandedDept] = useState<string | null>(null);

    const toggleDepartment = (nameKey: string) => {
        setExpandedDept(prev => (prev === nameKey ? null : nameKey));
    };

    return (
        <div className="space-y-6">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.government}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.government}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.government}</h1>
            )}
            <Card>
                <img src="https://picsum.photos/800/300?random=6" alt="CTA building" className="w-full h-64 object-cover rounded-t-lg" />
                 <div className="p-4">
                    {isBilingualMode ? (
                        <>
                            <h2 className="text-2xl font-bold text-tibetan-red">{t_en.ctaTitle}</h2>
                            <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.ctaTitle}</h3>
                            <p className="mt-2 text-lg text-gray-700">{t_en.ctaDesc1}</p>
                            <p className="mt-1 text-gray-600 font-serif">{t_ti.ctaDesc1}</p>
                            <p className="mt-4 text-gray-700">{t_en.ctaDesc2}</p>
                            <p className="mt-1 text-gray-600 font-serif">{t_ti.ctaDesc2}</p>
                        </>
                    ) : (
                         <>
                            <h2 className="text-2xl font-bold text-tibetan-red">{t.ctaTitle}</h2>
                            <p className="mt-2 text-lg text-gray-700">{t.ctaDesc1}</p>
                            <p className="mt-4 text-gray-700">{t.ctaDesc2}</p>
                        </>
                    )}
                    
                    <ul className="list-disc list-inside mt-2 space-y-1 text-gray-700">
                         {isBilingualMode ? (
                            <>
                                <li><strong>{t_en.legislature.split(':')[0]}:</strong> {t_en.legislature.split(':')[1]}<p className="text-gray-600 font-serif ml-4">{t_ti.legislature}</p></li>
                                <li><strong>{t_en.executive.split(':')[0]}:</strong> {t_en.executive.split(':')[1]}<p className="text-gray-600 font-serif ml-4">{t_ti.executive}</p></li>
                                <li><strong>{t_en.judiciary.split(':')[0]}:</strong> {t_en.judiciary.split(':')[1]}<p className="text-gray-600 font-serif ml-4">{t_ti.judiciary}</p></li>
                            </>
                        ) : (
                            <>
                                <li><strong>{t.legislature.split(':')[0]}:</strong> {t.legislature.split(':')[1]}</li>
                                <li><strong>{t.executive.split(':')[0]}:</strong> {t.executive.split(':')[1]}</li>
                                <li><strong>{t.judiciary.split(':')[0]}:</strong> {t.judiciary.split(':')[1]}</li>
                            </>
                        )}
                    </ul>
                     {isBilingualMode ? (
                        <>
                            <p className="mt-4 text-gray-700">{t_en.ctaAdministers}</p>
                            <p className="mt-1 text-gray-600 font-serif">{t_ti.ctaAdministers}</p>
                        </>
                    ) : (
                        <p className="mt-4 text-gray-700">{t.ctaAdministers}</p>
                    )}
                    <a href="https://tibet.net/" target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline mt-4 inline-block">{t.visitCtaSite}</a>
                    
                    <div className="mt-8 pt-6 border-t">
                        {isBilingualMode ? (
                            <>
                                <h3 className="text-2xl font-bold text-tibetan-blue mb-4">{t_en.majorDepartments}</h3>
                                <h4 className="text-xl font-bold text-tibetan-blue/80 font-serif mb-4">{t_ti.majorDepartments}</h4>
                            </>
                        ) : (
                            <h3 className="text-2xl font-bold text-tibetan-blue mb-4">{t.majorDepartments}</h3>
                        )}
                        <div className="space-y-4">
                            {departmentsData.map(dept => (
                                <div key={dept.nameKey} className="border rounded-lg overflow-hidden transition-all duration-300">
                                    <button
                                        onClick={() => toggleDepartment(dept.nameKey)}
                                        className="w-full text-left p-4 bg-gray-50 hover:bg-gray-100 focus:outline-none flex justify-between items-center"
                                        aria-expanded={expandedDept === dept.nameKey}
                                        aria-controls={`dept-details-${dept.nameKey}`}
                                    >
                                        <div className="flex items-center">
                                            <img src={dept.logoUrl} alt={`${t[dept.nameKey as keyof typeof t]} logo`} className="w-12 h-12 mr-4 object-contain" />
                                            <div>
                                                <h4 className="font-bold text-lg text-tibetan-red">{t[dept.nameKey as keyof typeof t]}</h4>
                                                <p className="text-gray-600">{dept.phone}</p>
                                            </div>
                                        </div>
                                        <span className={`transform transition-transform duration-300 ${expandedDept === dept.nameKey ? 'rotate-180' : ''}`}>
                                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                                            </svg>
                                        </span>
                                    </button>
                                    {expandedDept === dept.nameKey && (
                                        <div id={`dept-details-${dept.nameKey}`} className="p-4 bg-white animate-fade-in">
                                             <img src={dept.imageUrl} alt={t[dept.nameKey as keyof typeof t]} className="w-full h-48 object-cover rounded-lg mb-4" />
                                             {isBilingualMode ? (
                                                <>
                                                    <h5 className="font-semibold text-tibetan-blue mb-2">{t_en.dutiesAndResponsibilities}</h5>
                                                    <h6 className="font-semibold text-tibetan-blue/80 font-serif mb-2">{t_ti.dutiesAndResponsibilities}</h6>
                                                </>
                                            ) : (
                                                <h5 className="font-semibold text-tibetan-blue mb-2">{t.dutiesAndResponsibilities}</h5>
                                            )}
                                            <ul className="list-disc list-inside space-y-3 text-gray-700">
                                                {isBilingualMode 
                                                    ? dept.duties.map((duty, index) => <li key={index}>{duty}<p className="text-gray-500 font-serif ml-4 mt-1">{dept.duties_ti[index]}</p></li>)
                                                    : getLocalizedDuties(dept, language).map((duty, index) => <li key={index}>{duty}</li>)
                                                }
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                 </div>
            </Card>
        </div>
    );
};