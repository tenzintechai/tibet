import React from 'react';
import { useNavigate } from 'react-router-dom';
import { translations } from '../../constants';
import { Language } from '../../types';
import { Card } from '../ui/Card';

interface HomeViewProps {
    language: Language;
    isBilingualMode: boolean;
}

const sections = [
    { nameKey: 'history', path: '#/history' },
    { nameKey: 'culture', path: '#/culture' },
    { nameKey: 'religion', path: '#/religion' },
    { nameKey: 'language', path: '#/language' },
    { nameKey: 'medicine', path: '#/medicine' },
    { nameKey: 'kidsPlayroom', path: '#/kids' },
];

export const HomeView: React.FC<HomeViewProps> = ({ language, isBilingualMode }) => {
    const navigate = useNavigate();
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const heroImageUrl = "https://www.dalailama.com/assets/images/pages/cl/90th-birthday-logo-2025-green-fb.jpg";

    return (
        <div className="space-y-8 animate-fade-in">
            <Card className="p-0 overflow-hidden">
                <div className="relative text-center">
                    <img src={heroImageUrl} alt="Year of Compassion" className="w-full h-auto object-cover" />
                    <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center p-4">
                        {isBilingualMode ? (
                            <>
                                <h1 className="text-4xl md:text-5xl font-bold text-white font-serif">{t_en.welcome}</h1>
                                <h2 className="text-2xl md:text-3xl font-bold text-gray-200 font-serif mt-2">{t_ti.welcome}</h2>
                                <p className="mt-4 text-lg text-gray-200 max-w-2xl">{t_en.welcome_desc}</p>
                                <p className="mt-2 text-gray-300 font-serif max-w-2xl">{t_ti.welcome_desc}</p>
                            </>
                        ) : (
                            <>
                                <h1 className="text-4xl md:text-5xl font-bold text-white font-serif">{t.welcome}</h1>
                                <p className="mt-4 text-lg text-gray-200 max-w-2xl">{t.welcome_desc}</p>
                            </>
                        )}
                    </div>
                </div>
            </Card>

            <div>
                 {isBilingualMode ? (
                    <div className="text-center mb-6">
                        <h2 className="text-3xl font-bold text-tibetan-blue">{t_en.explore}</h2>
                        <h3 className="text-2xl font-bold text-tibetan-blue/80 font-serif">{t_ti.explore}</h3>
                    </div>
                ) : (
                    <h2 className="text-3xl font-bold text-tibetan-blue mb-6 text-center">{t.explore}</h2>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {sections.map(section => (
                        <div key={section.nameKey} onClick={() => navigate(section.path.substring(1))} className="cursor-pointer">
                            <Card className="text-center transform hover:-translate-y-1 hover:scale-105 duration-300 h-full">
                                {isBilingualMode ? (
                                    <>
                                        <h3 className="text-xl font-semibold text-tibetan-red">{t_en[section.nameKey as keyof typeof t_en]}</h3>
                                        <h4 className="text-lg font-semibold text-tibetan-red/80 font-serif">{t_ti[section.nameKey as keyof typeof t_ti]}</h4>
                                    </>
                                ) : (
                                    <h3 className="text-xl font-semibold text-tibetan-red">{t[section.nameKey as keyof typeof t]}</h3>
                                )}
                            </Card>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};