
import React, { useState, useEffect } from 'react';
import { Language } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';

const alphabet = ['ཀ', 'ཁ', 'ག', 'ང', 'ཅ', 'ཆ', 'ཇ', 'ཉ', 'ཏ', 'ཐ', 'ད', 'ན', 'པ', 'ཕ', 'བ', 'མ', 'ཙ', 'ཚ', 'ཛ', 'ཝ', 'ཞ', 'ཟ', 'འ', 'ཡ', 'ར', 'ལ', 'ཤ', 'ས', 'ཧ', 'ཨ'];
const numerals = ['༠', '༡', '༢', '༣', '༤', '༥', '༦', '༧', '༨', '༩'];

const languageTopics = [
    { titleKey: 'lang_origin_title', contentKey: 'lang_origin_desc' },
    { titleKey: 'lang_vowels_title', contentKey: 'lang_vowels_desc' },
    { titleKey: 'lang_styles_title', contentKey: 'lang_styles_desc' , isPreformatted: true},
    { titleKey: 'lang_sanskrit_title', contentKey: 'lang_sanskrit_desc' },
];

const SpeakerIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clipRule="evenodd" />
    </svg>
);

interface LanguageViewProps {
    language: Language;
    isBilingualMode: boolean;
}

export const LanguageView: React.FC<LanguageViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

    useEffect(() => {
        if ('speechSynthesis' in window) {
            const loadVoices = () => {
                setVoices(window.speechSynthesis.getVoices());
            };
            loadVoices();
            window.speechSynthesis.onvoiceschanged = loadVoices;
            return () => {
                window.speechSynthesis.onvoiceschanged = null;
            };
        }
    }, []);

    const speak = (character: string) => {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(character);
            utterance.lang = 'bo-CN';
            utterance.rate = 0.7;

            const tibetanVoice = voices.find(voice => voice.lang.startsWith('bo'));
            if (tibetanVoice) {
                utterance.voice = tibetanVoice;
            } else {
                console.warn("Tibetan TTS voice not found. Using browser default for 'bo-CN'.");
            }
            
            window.speechSynthesis.speak(utterance);
        } else {
            alert('Text-to-speech is not supported by your browser.');
        }
    };

    const renderBilingualText = (enKey: keyof typeof t_en, tiKey: keyof typeof t_ti, isPreformatted = false) => (
        <>
            <p className={`${isPreformatted ? 'whitespace-pre-line' : ''} text-gray-700`}>{t_en[enKey]}</p>
            <p className={`${isPreformatted ? 'whitespace-pre-line' : ''} text-gray-600 font-serif mt-2`}>{t_ti[tiKey]}</p>
        </>
    );

    const renderSingleLanguageText = (key: keyof typeof t, isPreformatted = false) => (
        <p className={`${isPreformatted ? 'whitespace-pre-line' : ''} text-gray-700`}>{t[key]}</p>
    );

    return (
        <div className="space-y-6">
             {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.language}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.language}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.language}</h1>
            )}

            <Card>
                {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t_en.lang_alphabet_title}</h2>
                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.lang_alphabet_title}</h3>
                        {renderBilingualText('lang_alphabet_desc', 'lang_alphabet_desc')}
                    </>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t.lang_alphabet_title}</h2>
                        {renderSingleLanguageText('lang_alphabet_desc')}
                    </>
                )}
                <div className="mt-4 flex flex-wrap gap-4 text-3xl font-serif">
                    {alphabet.map(char => (
                        <div key={char} className="p-3 bg-white rounded-md shadow-sm flex items-center space-x-3">
                           <span>{char}</span>
                            <button 
                                onClick={() => speak(char)} 
                                className="text-gray-400 hover:text-tibetan-blue transition-colors" 
                                aria-label={`Pronounce ${char}`}
                            >
                                <SpeakerIcon />
                            </button>
                        </div>
                    ))}
                </div>
            </Card>

            {languageTopics.map(topic => (
                 <React.Fragment key={topic.titleKey}>
                    <Card>
                        {isBilingualMode ? (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{t_en[topic.titleKey as keyof typeof t_en]}</h2>
                                <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti[topic.titleKey as keyof typeof t_ti]}</h3>
                                <div className="mt-2">{renderBilingualText(topic.contentKey as keyof typeof t_en, topic.contentKey as keyof typeof t_ti, topic.isPreformatted)}</div>
                            </>
                        ) : (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{t[topic.titleKey as keyof typeof t]}</h2>
                                <div className="mt-2">{renderSingleLanguageText(topic.contentKey as keyof typeof t, topic.isPreformatted)}</div>
                            </>
                        )}
                    </Card>
                    {topic.titleKey === 'lang_origin_title' && (
                        <Card className="flex flex-col p-0 overflow-hidden">
                            <img src="https://picsum.photos/800/300?random=11" alt={t.thonmi_sambhota_title} className="w-full h-56 object-cover" />
                            <div className="p-6">
                                {isBilingualMode ? (
                                    <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{t_en.thonmi_sambhota_title}</h2>
                                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.thonmi_sambhota_title}</h3>
                                        <div className="mt-2">{renderBilingualText('thonmi_sambhota_bio' as keyof typeof t_en, 'thonmi_sambhota_bio' as keyof typeof t_ti)}</div>
                                    </>
                                ) : (
                                    <>
                                        <h2 className="text-2xl font-bold text-tibetan-red">{t.thonmi_sambhota_title}</h2>
                                        <div className="mt-2">{renderSingleLanguageText('thonmi_sambhota_bio' as keyof typeof t)}</div>
                                    </>
                                )}
                            </div>
                        </Card>
                    )}
                 </React.Fragment>
            ))}

            <Card>
                {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t_en.lang_numerals_title}</h2>
                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.lang_numerals_title}</h3>
                        {renderBilingualText('lang_numerals_desc', 'lang_numerals_desc')}
                    </>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t.lang_numerals_title}</h2>
                        {renderSingleLanguageText('lang_numerals_desc')}
                    </>
                )}
                <div className="mt-4 flex flex-wrap gap-4 text-4xl font-serif">
                    {numerals.map((char, index) => (
                        <div key={char} className="p-3 bg-white rounded-md shadow-sm text-center">
                           <span>{char}</span>
                           <p className="text-sm text-gray-500 mt-1">{index}</p>
                        </div>
                    ))}
                </div>
            </Card>

            <Card>
                 {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t_en.dictionariesTranslation}</h2>
                        <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti.dictionariesTranslation}</h3>
                        <div className="mt-2">{renderBilingualText('dictionariesTranslationDesc', 'dictionariesTranslationDesc')}</div>
                    </>
                ) : (
                    <>
                        <h2 className="text-2xl font-bold text-tibetan-red">{t.dictionariesTranslation}</h2>
                        <div className="mt-2">{renderSingleLanguageText('dictionariesTranslationDesc')}</div>
                    </>
                )}
                <ul className="list-disc list-inside mt-2 space-y-1">
                    <li><a href="https://monlam.ai/" target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline">MonlamAI Tibetan Dictionary</a></li>
                    <li><a href="https://www.bing.com/translator" target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline">Microsoft Translator (includes Tibetan)</a></li>
                    <li><a href="https://chat.openai.com/" target="_blank" rel="noopener noreferrer" className="text-tibetan-blue hover:underline">AI Translation by ChatGPT</a></li>
                </ul>
            </Card>
        </div>
    );
};
