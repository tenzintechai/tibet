import React from 'react';
import { ContentSection, Language } from '../../types';
import { translations } from '../../constants';
import { cultureData } from '../../data/content';
import { Card } from '../ui/Card';

interface CultureViewProps {
    language: Language;
    isBilingualMode: boolean;
}

const getLocalizedContent = (item: ContentSection, field: 'title' | 'description', language: Language) => {
    switch (language) {
        case Language.TI: return item[`${field}_ti`];
        case Language.HI: return item[`${field}_hi`];
        default: return item[field];
    }
};

export const CultureView: React.FC<CultureViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    return (
        <div className="space-y-6">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.culture}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.culture}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.culture}</h1>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {cultureData.map(item => (
                    <Card key={item.title} className="flex flex-col">
                        <img src={item.imageUrl} alt={getLocalizedContent(item, 'title', language)} className="w-full h-48 object-cover rounded-t-lg" />
                        <div className="p-4 flex-1 flex flex-col">
                            {isBilingualMode ? (
                                <>
                                    <h2 className="text-2xl font-bold text-tibetan-red">{item.title}</h2>
                                    <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{item.title_ti}</h3>
                                    <p className="mt-2 text-gray-700 flex-1">{item.description}</p>
                                    <p className="mt-1 text-gray-600 font-serif flex-1">{item.description_ti}</p>
                                </>
                            ) : (
                                <>
                                    <h2 className="text-2xl font-bold text-tibetan-red">{getLocalizedContent(item, 'title', language)}</h2>
                                    <p className="mt-2 text-gray-700 flex-1">{getLocalizedContent(item, 'description', language)}</p>
                                </>
                            )}
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};