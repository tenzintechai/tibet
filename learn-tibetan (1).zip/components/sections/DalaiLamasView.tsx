
import React from 'react';
import { Language } from '../../types';
import { translations } from '../../constants';
import { dalaiLamasData } from '../../data/content';
import { Card } from '../ui/Card';

interface DalaiLamasViewProps {
    language: Language;
    isBilingualMode: boolean;
}

export const DalaiLamasView: React.FC<DalaiLamasViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];
    const isTibetan = language === Language.TI;

    return (
        <div className="space-y-6">
             {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.dalaiLamas}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.dalaiLamas}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.dalaiLamas}</h1>
            )}

            <div className="space-y-4 animate-fade-in">
                {dalaiLamasData.map(dl => (
                     <Card key={dl.id} className="p-0 overflow-hidden">
                        <img src={dl.imageUrl} alt={isTibetan ? dl.name_ti : dl.name} className="w-full h-64 object-cover" />
                        <div className="p-4">
                            {isBilingualMode ? (
                                <>
                                    <h2 className="text-2xl font-bold text-tibetan-red">{dl.id}. {dl.name}</h2>
                                    <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{dl.name_ti}</h3>
                                    <p className="text-lg text-gray-600">{dl.reign}</p>
                                    <p className="mt-2 text-gray-700">{dl.bio}</p>
                                    <p className="mt-1 text-gray-600 font-serif">{dl.bio_ti}</p>
                                    <p className="mt-4 font-semibold text-tibetan-blue">{t_en.teachingsSummary}:</p>
                                    <p className="italic text-gray-700">"{dl.teachings_summary}"</p>
                                    <p className="mt-1 font-semibold text-tibetan-blue/80 font-serif">{t_ti.teachingsSummary}:</p>
                                    <p className="italic text-gray-600 font-serif">"{dl.teachings_summary_ti}"</p>
                                </>
                            ) : (
                                <>
                                    <h2 className="text-2xl font-bold text-tibetan-red">{dl.id}. {isTibetan ? dl.name_ti : dl.name}</h2>
                                    {isTibetan && <h3 className="text-xl font-semibold text-gray-700">{dl.tibetan_name}</h3>}
                                    <p className="text-lg text-gray-600">{dl.reign}</p>
                                    <p className="mt-2 text-gray-700">{isTibetan ? dl.bio_ti : dl.bio}</p>
                                    <p className="mt-4 font-semibold text-tibetan-blue">{t.teachingsSummary}:</p>
                                    <p className="italic text-gray-700">"{isTibetan ? dl.teachings_summary_ti : dl.teachings_summary}"</p>
                                </>
                            )}
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};