
import React from 'react';
import { Language } from '../../types';
import { translations } from '../../constants';
import { Card } from '../ui/Card';
import { religionSchoolsData } from '../../data/content';

interface ReligionViewProps {
    language: Language;
    isBilingualMode: boolean;
}

export const ReligionView: React.FC<ReligionViewProps> = ({ language, isBilingualMode }) => {
    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    return (
        <div className="space-y-6">
            {isBilingualMode ? (
                <div>
                    <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t_en.religion}</h1>
                    <h2 className="text-3xl font-bold text-tibetan-blue/80 font-serif">{t_ti.religion}</h2>
                </div>
            ) : (
                <h1 className="text-4xl font-bold text-tibetan-blue font-serif">{t.religion}</h1>
            )}
            
            {isBilingualMode ? (
                <div className="text-lg">
                    <p className="text-gray-700">{t_en.religion_intro}</p>
                    <p className="text-gray-600 font-serif mt-2">{t_ti.religion_intro}</p>
                </div>
            ) : (
                <p className="text-lg text-gray-700">{t.religion_intro}</p>
            )}

            <div className="space-y-4">
                {religionSchoolsData.map(school => (
                    <Card key={school.nameKey}>
                        {isBilingualMode ? (
                            <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{t_en[school.nameKey as keyof typeof t_en]}</h2>
                                <h3 className="text-xl font-bold text-tibetan-red/80 font-serif">{t_ti[school.nameKey as keyof typeof t_ti]}</h3>
                                <p className="mt-2 text-gray-700">{t_en[school.descriptionKey as keyof typeof t_en]}</p>
                                <p className="mt-1 text-gray-600 font-serif">{t_ti[school.descriptionKey as keyof typeof t_ti]}</p>
                            </>
                        ) : (
                             <>
                                <h2 className="text-2xl font-bold text-tibetan-red">{t[school.nameKey as keyof typeof t]}</h2>
                                <p className="mt-2 text-gray-700">{t[school.descriptionKey as keyof typeof t]}</p>
                            </>
                        )}
                    </Card>
                ))}
            </div>
        </div>
    );
};
