import React, { useState } from 'react';
import { Language, QuizQuestion } from '../../types';
import { translations } from '../../constants';
import { Button } from '../ui/Button';
import { generateQuiz } from '../../services/geminiService';
import { Spinner } from '../ui/Spinner';

export const QuizComponent: React.FC<{ topic: string; content: string; language: Language; isBilingualMode: boolean; onBack: () => void; }> = ({ topic, content, language, isBilingualMode, onBack }) => {
    const [questions, setQuestions] = useState<QuizQuestion[] | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [score, setScore] = useState(0);

    const t = translations[language];
    const t_en = translations[Language.EN];
    const t_ti = translations[Language.TI];

    React.useEffect(() => {
        const fetchQuiz = async () => {
            setIsLoading(true);
            setError(null);
            const quizData = await generateQuiz(topic, content);
            if (quizData) {
                setQuestions(quizData);
            } else {
                setError("Failed to generate quiz. The API key might be missing or invalid.");
            }
            setIsLoading(false);
        };
        fetchQuiz();
    }, [topic, content]);

    const handleAnswerSubmit = () => {
        setIsSubmitted(true);
        if (selectedAnswer === questions![currentQuestionIndex].correctAnswer) {
            setScore(s => s + 1);
        }
    };
    
    const handleNextQuestion = () => {
        setIsSubmitted(false);
        setSelectedAnswer(null);
        setCurrentQuestionIndex(i => i + 1);
    };
    
    const handleRestart = () => {
        setQuestions(null);
        setCurrentQuestionIndex(0);
        setSelectedAnswer(null);
        setIsSubmitted(false);
        setScore(0);
        // Refetch quiz
         const fetchQuiz = async () => {
            setIsLoading(true);
            setError(null);
            const quizData = await generateQuiz(topic, content);
            if (quizData) {
                setQuestions(quizData);
            } else {
                setError("Failed to generate quiz. The API key might be missing or invalid.");
            }
            setIsLoading(false);
        };
        fetchQuiz();
    }

    if (isLoading) return <Spinner text={t.loading} />;
    if (error) return <p className="text-red-600">{error}</p>;
    if (!questions || questions.length === 0) return <p>No quiz available.</p>;

    if (currentQuestionIndex >= questions.length) {
        return (
            <div className="text-center">
                 {isBilingualMode ? (
                    <>
                        <h2 className="text-2xl font-bold">{t_en.quizComplete}</h2>
                        <h3 className="text-xl font-bold font-serif">{t_ti.quizComplete}</h3>
                    </>
                ) : (
                    <h2 className="text-2xl font-bold">{t.quizComplete}</h2>
                )}
                <p className="text-xl mt-4">
                    {t.yourScore.replace('{score}', score.toString()).replace('{total}', questions.length.toString())}
                </p>
                <Button onClick={handleRestart} className="mt-6">{t.playAgain}</Button>
            </div>
        );
    }

    const currentQuestion = questions[currentQuestionIndex];

    return (
        <div>
            <h3 className="text-xl font-semibold mb-4">{currentQuestionIndex + 1}. {currentQuestion.question}</h3>
            <div className="space-y-3">
                {currentQuestion.options.map((option, index) => {
                    const isCorrect = option === currentQuestion.correctAnswer;
                    const isSelected = option === selectedAnswer;
                    let buttonClass = "w-full text-left p-3 rounded-lg border-2 transition-colors ";
                    if (isSubmitted) {
                        if (isCorrect) buttonClass += "bg-green-200 border-green-400";
                        else if (isSelected) buttonClass += "bg-red-200 border-red-400";
                        else buttonClass += "bg-white border-gray-300";
                    } else {
                         buttonClass += isSelected ? "bg-blue-100 border-blue-400" : "bg-white border-gray-300 hover:bg-gray-100";
                    }
                    return <button key={index} onClick={() => !isSubmitted && setSelectedAnswer(option)} disabled={isSubmitted} className={buttonClass}>{option}</button>
                })}
            </div>

            {isSubmitted && (
                <div className="mt-4 p-3 rounded-lg bg-gray-100">
                    {selectedAnswer === currentQuestion.correctAnswer ? (
                         <p className="font-bold text-green-700">{t.correct}</p>
                    ) : (
                         <p className="font-bold text-red-700">{t.incorrect} {currentQuestion.correctAnswer}</p>
                    )}
                </div>
            )}

            <div className="mt-6 flex justify-between items-center">
                <p className="text-sm text-gray-600">{t.score}: {score}</p>
                {isSubmitted ? (
                    <Button onClick={handleNextQuestion}>
                        {currentQuestionIndex === questions.length - 1 ? t.finish : t.nextQuestion}
                    </Button>
                ) : (
                    <Button onClick={handleAnswerSubmit} disabled={!selectedAnswer}>{t.submit}</Button>
                )}
            </div>
        </div>
    );
};