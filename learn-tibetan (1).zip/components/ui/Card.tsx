import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
    children: React.ReactNode;
}

export const Card: React.FC<CardProps> = ({ children, className = '', ...props }) => {
    return (
        <div
            className={`bg-white/50 backdrop-blur-sm border border-gray-200 rounded-lg shadow-md p-4 transition-all duration-300 hover:shadow-xl ${className}`}
            {...props}
        >
            {children}
        </div>
    );
};