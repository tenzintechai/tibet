
import React from 'react';

interface SpinnerProps {
    text: string;
}

export const Spinner: React.FC<SpinnerProps> = ({ text }) => {
    return (
        <div className="flex flex-col items-center justify-center p-8">
            <div className="w-12 h-12 border-4 border-tibetan-blue border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 text-lg text-tibetan-blue font-semibold">{text}</p>
        </div>
    );
};
