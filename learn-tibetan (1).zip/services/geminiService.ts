
import { GoogleGenAI, Type } from "@google/genai";
import { QuizQuestion } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this example, we'll alert the user and disable API features.
  // The key is expected to be in the environment.
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateQuiz = async (topic: string, content: string): Promise<QuizQuestion[] | null> => {
    if (!process.env.API_KEY) return null;
    try {
        const prompt = `Based on the following text about "${topic}", generate a JSON array of 3 multiple-choice quiz questions. Each question should have a "question" string, an "options" array of 4 strings, and a "correctAnswer" string that is one of the options.

        Text:
        ---
        ${content}
        ---`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            question: { type: Type.STRING },
                            options: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING }
                            },
                            correctAnswer: { type: Type.STRING }
                        },
                        required: ["question", "options", "correctAnswer"]
                    }
                }
            }
        });

        const jsonText = response.text;
        const quizData = JSON.parse(jsonText);
        return quizData as QuizQuestion[];

    } catch (error) {
        console.error("Error generating quiz:", error);
        return null;
    }
};

export const generateStory = async (prompt: string): Promise<string | null> => {
    if (!process.env.API_KEY) return null;
    try {
        const fullPrompt = `You are a storyteller for young children. Write a very short and simple Tibetan-style folk tale based on the following idea: "${prompt}". The story should be easy for a 5-year-old to understand and must have a simple, positive moral at the end. Keep the story to about 3-4 short paragraphs.`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: fullPrompt,
        });

        return response.text;

    } catch (error) {
        console.error("Error generating story:", error);
        return null;
    }
};