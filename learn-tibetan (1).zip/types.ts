export enum Language {
    EN = 'en',
    TI = 'ti',
    HI = 'hi',
}

export interface King {
    id: number;
    name: string;
    name_ti: string;
    name_hi: string;
    tibetan_name: string;
    reign: string;
    bio: string;
    bio_ti: string;
    bio_hi: string;
    achievements: string[];
    achievements_ti: string[];
    achievements_hi: string[];
    challenges: string[];
    challenges_ti: string[];
    challenges_hi: string[];
    cultural_influence: string;
    cultural_influence_ti: string;
    cultural_influence_hi: string;
}

export interface DalaiLama {
    id: number;
    name: string;
    name_ti: string;
    name_hi: string;
    tibetan_name: string;
    reign: string;
    bio: string;
    bio_ti: string;
    bio_hi: string;
    teachings_summary: string;
    teachings_summary_ti: string;
    teachings_summary_hi: string;
    imageUrl: string;
}

export interface PanchenLama {
    id: number;
    name: string;
    name_ti: string;
    name_hi: string;
    tibetan_name: string;
    lifespan: string;
    bio: string;
    bio_ti: string;
    bio_hi: string;
}

export interface DynasticRuler {
    id: number;
    name: string;
    name_ti: string;
    name_hi: string;
    reign: string;
    bio: string;
    bio_ti: string;
    bio_hi: string;
    notes?: string;
    notes_ti?: string;
    notes_hi?: string;
}


export interface ContentSection {
    title: string;
    title_ti: string;
    title_hi: string;
    description: string;
    description_ti: string;
    description_hi: string;
    imageUrl: string;
}

export interface ReligionSchool {
    nameKey: string;
    descriptionKey: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}

export interface Department {
    nameKey: string;
    phone: string;
    logoUrl: string;
    imageUrl: string;
    duties: string[];
    duties_ti: string[];
    duties_hi: string[];
}

export interface MediaOutlet {
    name: string;
    name_ti: string;
    name_hi: string;
    url: string;
    description: string;
    description_ti: string;
    description_hi: string;
    warning?: string;
    warning_ti?: string;
    warning_hi?: string;
}

export interface MedicineTopic {
    titleKey: string;
    imageUrl: string;
    contentKey: string;
}

export interface FolkTale {
  id: string;
  title: string;
  title_ti: string;
  title_hi: string;
  story: string;
  story_ti: string;
  story_hi: string;
  moral: string;
  moral_ti: string;
  moral_hi: string;
}

export interface HistoricalPeriod {
    id: number;
    period: string;
    period_ti: string;
    period_hi: string;
    summary: string;
    summary_ti: string;
    summary_hi: string;
    key_events: string[];
    key_events_ti: string[];
    key_events_hi: string[];
}

export interface InfoCardData {
  titleKey: string;
  contentKey: string;
}

export type MathOperator = '+' | '-' | '×' | '÷';

export interface MathProblem {
  num1: number;
  num2: number;
  operator: MathOperator;
  answer: number;
}

export type ShapeType = 'circle' | 'square' | 'triangle' | 'rectangle';