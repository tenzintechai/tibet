
import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/layout/Sidebar';
import { HomeView } from './components/sections/HomeView';
import { HistoryView } from './components/sections/HistoryView';
import { CultureView } from './components/sections/CultureView';
import { ReligionView } from './components/sections/ReligionView';
import { LanguageView } from './components/sections/LanguageView';
import { MedicineView } from './components/sections/MedicineView';
import { NewsView } from './components/sections/NewsView';
import { GovernmentView } from './components/sections/GovernmentView';
import { KidsPlayroomView } from './components/sections/KidsPlayroomView';
import { Language } from './types';

const App: React.FC = () => {
    const [isSidebarOpen, setSidebarOpen] = useState(true);
    const [language, setLanguage] = useState<Language>(Language.EN);
    const [isBilingualMode, setBilingualMode] = useState(false);

    return (
        <HashRouter>
            <div className="flex h-screen bg-parchment text-gray-800">
                <Sidebar 
                    isOpen={isSidebarOpen} 
                    setOpen={setSidebarOpen} 
                    language={language} 
                    setLanguage={setLanguage}
                    isBilingualMode={isBilingualMode}
                    setBilingualMode={setBilingualMode}
                />
                <main className={`flex-1 overflow-y-auto transition-all duration-300 ${isSidebarOpen ? 'ml-64' : 'ml-16'}`}>
                    <div className="p-4 md:p-8">
                        <Routes>
                            <Route path="/" element={<HomeView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/history" element={<HistoryView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/culture" element={<CultureView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/religion" element={<ReligionView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/language" element={<LanguageView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/medicine" element={<MedicineView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/news" element={<NewsView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/government" element={<GovernmentView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="/kids" element={<KidsPlayroomView language={language} isBilingualMode={isBilingualMode} />} />
                            <Route path="*" element={<Navigate to="/" />} />
                        </Routes>
                    </div>
                </main>
            </div>
        </HashRouter>
    );
};

export default App;
